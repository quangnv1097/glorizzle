@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === Dong goi APP DUNG thanh file .exe ===

set "PY="
py -3 --version >nul 2>&1 && set "PY=py -3"
if not defined PY (
  python --version >nul 2>&1 && set "PY=python"
)
if defined PY goto run

echo.
echo Khong tu tim thay Python trong PATH.
echo Hay dan duong dan day du toi python.exe ma Visual Studio dang dung.
echo Cach lay duong dan: trong Visual Studio chay  import sys; print(sys.executable)
set /p "PYPATH=Duong dan python.exe: "
set "PYPATH=%PYPATH:"=%"
if not exist "%PYPATH%" (
  echo Duong dan khong dung.
  pause
  exit /b 1
)
set PY="%PYPATH%"

:run
echo Dang dung: %PY%
%PY% -m pip install --upgrade pip
%PY% -m pip install -r requirements.txt pyinstaller
if errorlevel 1 (
  echo LOI khi cai thu vien.
  pause
  exit /b 1
)
set "UPD="
set /p "UPD=Dia chi thu muc dat ban cap nhat (vd https://example.com/appdung/ , de trong neu chua co): "
%PY% tools\chuan_bi_build.py "%UPD%"
if errorlevel 1 (
  echo LOI khi chuan bi ma app.
  pause
  exit /b 1
)
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --collect-all pdfplumber --collect-all pdfminer --collect-all pypdfium2 --collect-all openpyxl --add-data "app_code;app_code" --name APP_DUNG launcher.py
if errorlevel 1 (
  echo LOI khi dong goi.
  pause
  exit /b 1
)
echo.
echo Xong! File gui cho nguoi khac: dist\APP_DUNG.exe  (chi can gui MOT LAN; cac lan sau dung phat_hanh.bat)
pause
