@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY="
py -3 --version >nul 2>&1 && set "PY=py -3"
if not defined PY (
  python --version >nul 2>&1 && set "PY=python"
)
if not defined PY (
  echo Khong tim thay Python trong PATH. Hay cai Python tu python.org hoac mo app_dung.py bang Visual Studio.
  pause
  exit /b 1
)
%PY% -m pip install -q -r requirements.txt
%PY% app_dung.py
