# -*- coding: utf-8 -*-
"""Chuẩn bị thư mục app_code (mã app đi kèm trong .exe). Gọi từ build_exe.bat:  python tools/chuan_bi_build.py [địa chỉ thư mục cập nhật]"""
import json
import os
import shutil
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXCLUDE_DIRS = {"tools", "__pycache__", "phat_hanh", "dist", "build", "app_code"}
EXCLUDE_FILES = {"launcher.py", "build_exe.bat", "chay_app.bat", "phat_hanh.bat", "APP_DUNG.spec"}


def main():
    url = sys.argv[1].strip() if len(sys.argv) > 1 else ""
    dest = os.path.join(ROOT, "app_code")
    shutil.rmtree(dest, ignore_errors=True)
    n = 0
    for dirpath, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for f in files:
            if f in EXCLUDE_FILES or f.endswith((".pyc", ".zip", ".bak", ".exe")):
                continue
            src = os.path.join(dirpath, f)
            out = os.path.join(dest, os.path.relpath(src, ROOT))
            os.makedirs(os.path.dirname(out), exist_ok=True)
            shutil.copy2(src, out)
            n += 1
    if url:
        base = url if url.endswith("/") else url + "/"
        with open(os.path.join(dest, "update_config.json"), "w", encoding="utf-8") as f:
            json.dump({"manifest_url": base + "version.json"}, f, indent=2)
    print("Da chuan bi app_code: %d file%s" % (n, ", dia chi cap nhat: " + url if url else " (chua cau hinh dia chi cap nhat)"))


if __name__ == "__main__":
    main()
