# -*- coding: utf-8 -*-
"""
Công cụ DÀNH CHO NGƯỜI PHÁT TRIỂN: tạo lại file builtin_rules.py (quy tắc tích hợp sẵn trong app)
từ sheet "Thao Tac" của file Excel/macro.

    python tools/cap_nhat_quy_tac.py "TH_check_TP (Tools).xlsm"

Người dùng cuối không cần chạy file này: quy tắc đã nằm sẵn trong app.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

import dung_engine as eng  # noqa: E402

HEADER = '''# -*- coding: utf-8 -*-
"""
Quy tắc TÍCH HỢP SẴN trong app (người dùng không phải nạp/chỉnh).

CONGDUNG : (từ khóa trong tên sản phẩm / tên sheet, nội dung công dụng điền vào ô B32)
CHECKS   : (ô Có/Không, các từ khóa cách nhau dấu phẩy; có từ khóa trong tên SP | công dụng |
            tên thành phần thì ô được tích "Có")

Tạo tự động từ sheet "Thao Tac" bằng tools/cap_nhat_quy_tac.py. Có thể sửa tay trực tiếp.
"""

'''


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    rules = eng.load_rules_xlsx(sys.argv[1])
    out = [HEADER, "CONGDUNG = [\n"]
    for k, v in rules.congdung:
        out.append("    (%r, %r),\n" % (k, v))
    out.append("]\n\nCHECKS = [\n")
    for c, kw in rules.checks:
        out.append("    (%r, %r),\n" % (c, kw))
    out.append("]\n")
    path = os.path.join(ROOT, "builtin_rules.py")
    with open(path, "w", encoding="utf-8") as f:
        f.write("".join(out))
    print("Đã ghi %s: %s" % (path, rules.summary()))
    return 0


if __name__ == "__main__":
    sys.exit(main())
