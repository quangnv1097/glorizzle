# -*- coding: utf-8 -*-
"""
Tạo GÓI PHÁT HÀNH bản cập nhật mã app (không đụng tới file .exe).

  python tools/phat_hanh.py --url-goc https://example.com/appdung/ --ghi-chu "Thêm tính năng X"

Kết quả trong thư mục phat_hanh/ (đặt cả 2 file lên địa chỉ --url-goc, ghi đè version.json cũ):
  APP_DUNG_code_v<NN>.zip   gói mã app (vài trăm KB)
  version.json              thông tin bản mới + mã SHA-256 để máy khách kiểm tra
Số phiên bản lấy từ version.py (APP_VERSION) - tăng số này trước mỗi lần phát hành.

Kiểm tra thêm: nếu mã dùng thư viện chưa có trong bộ chạy (launcher.py) thì báo cần build lại .exe.
"""
import argparse
import ast
import glob
import hashlib
import json
import os
import re
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXCLUDE_DIRS = {"tools", "__pycache__", "phat_hanh", "dist", "build", "build_code", "app_code"}
EXCLUDE_FILES = {"launcher.py", "build_exe.bat", "chay_app.bat", "phat_hanh.bat"}


def read_version():
    with open(os.path.join(ROOT, "version.py"), encoding="utf-8") as f:
        txt = f.read()
    return (int(re.search(r"APP_VERSION\s*=\s*(\d+)", txt).group(1)),
            int(re.search(r"MIN_LAUNCHER\s*=\s*(\d+)", txt).group(1)))


def imports_of(path):
    mods = set()
    for n in ast.walk(ast.parse(open(path, encoding="utf-8").read())):
        if isinstance(n, ast.Import):
            mods.update(a.name for a in n.names)
        elif isinstance(n, ast.ImportFrom) and n.module and n.level == 0:
            mods.add(n.module)
            if n.module == "tkinter":
                mods.update("tkinter." + a.name for a in n.names)
    return mods


def missing_in_launcher():
    own = {os.path.basename(f)[:-3] for f in glob.glob(os.path.join(ROOT, "*.py"))}
    need = set()
    for f in glob.glob(os.path.join(ROOT, "*.py")):
        if os.path.basename(f) != "launcher.py":
            need |= {m for m in imports_of(f) if m.split(".")[0] not in own}
    have = imports_of(os.path.join(ROOT, "launcher.py"))
    return sorted(m for m in need if not any(h == m or h.startswith(m + ".") for h in have))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url-goc", required=True, help="địa chỉ thư mục chứa 2 file phát hành, vd https://.../appdung/")
    ap.add_argument("--ghi-chu", default="", help="ghi chú ngắn hiện cho người dùng")
    ap.add_argument("--out", default=os.path.join(ROOT, "phat_hanh"))
    a = ap.parse_args()
    ver, min_launcher = read_version()
    miss = [m for m in missing_in_launcher()]
    if miss:
        print("CẢNH BÁO: mã app dùng thư viện chưa có trong launcher.py: %s" % ", ".join(miss))
        print("          -> thêm vào launcher.py, build lại APP_DUNG.exe, rồi tăng MIN_LAUNCHER trong version.py.")
    os.makedirs(a.out, exist_ok=True)
    name = "APP_DUNG_code_v%d.zip" % ver
    zpath = os.path.join(a.out, name)
    n = 0
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for dirpath, dirs, files in os.walk(ROOT):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            for f in files:
                if f in EXCLUDE_FILES or f == "update_config.json" or f.endswith((".pyc", ".zip", ".bak")):
                    continue
                full = os.path.join(dirpath, f)
                z.write(full, os.path.relpath(full, ROOT).replace("\\", "/"))
                n += 1
    base = a.url_goc if a.url_goc.endswith("/") else a.url_goc + "/"
    with zipfile.ZipFile(zpath, "a", zipfile.ZIP_DEFLATED) as z:        # địa chỉ cập nhật luôn khớp --url-goc
        z.writestr("update_config.json", json.dumps({"manifest_url": base + "version.json"}, indent=2))
    sha = hashlib.sha256(open(zpath, "rb").read()).hexdigest()
    manifest = {"version": ver, "url": base + name, "sha256": sha, "notes": a.ghi_chu, "min_launcher": min_launcher}
    with open(os.path.join(a.out, "version.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    print("Đã tạo bản phát hành v%d: %d file, %d KB" % (ver, n, os.path.getsize(zpath) // 1024))
    print("Đặt 2 file trong %s lên %s" % (a.out, base))


if __name__ == "__main__":
    sys.exit(main())
