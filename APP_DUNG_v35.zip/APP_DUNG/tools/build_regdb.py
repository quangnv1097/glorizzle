# -*- coding: utf-8 -*-
"""
CÔNG CỤ CHO NGƯỜI PHÁT TRIỂN: tạo kho quy định regdb.json từ
  - file "Annexes of the ASEAN Cosmetic Directive" (PDF đầy đủ, có Annex II, III, IV Part 1, VI, VII)
  - bảng "Tong hop check thanh phan.xlsx" (bảng tự lập của người dùng)

    python tools/build_regdb.py annexes.pdf "Tong hop check thanh phan.xlsx"

Người dùng cuối KHÔNG cần chạy file này: regdb.json đã nằm sẵn trong app. Khi có bản Annex mới, chạy lại
để cập nhật kho. Cần: pip install pdfplumber openpyxl
"""
import json
import os
import re
import sys
import warnings

warnings.simplefilter("ignore")
import pdfplumber                                  # noqa: E402
from openpyxl import load_workbook                 # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CAS_RE = re.compile(r"\b\d{2,7}-\d{2}-\d\b")
REF_RE = re.compile(r"^\d{1,4}[a-z]{0,2}$|^A\d{1,4}[a-z]?$")


def lines_of(pg, tol=3):
    ws = pg.extract_words(x_tolerance=1.5, y_tolerance=2)
    out = []
    for w in sorted(ws, key=lambda w: (w["top"], w["x0"])):
        if out and abs(out[-1][0]["top"] - w["top"]) <= tol:
            out[-1].append(w)
        else:
            out.append([w])
    return [sorted(l, key=lambda w: w["x0"]) for l in out]


def find_pages(pdf):
    """Khoảng trang của từng Annex dựa vào dòng đầu mỗi trang."""
    cur, rng = None, {}
    for i, pg in enumerate(pdf.pages, start=1):
        t = (pg.extract_text() or "").strip().splitlines()
        h = t[0].strip() if t else ""
        m = re.match(r"(?i)annex\s+([ivx]+)", h)
        tag = m.group(1).upper() if m else None
        if tag and tag != cur:
            cur = tag
            rng.setdefault(tag, [i, i])
        if tag:
            rng[tag][1] = i
    return rng


# ---------------------------------------------------------------- Annex II
def parse_annex2(pdf, p0, p1):
    raw = []
    for pn in range(p0, p1 + 1):
        pg = pdf.pages[pn - 1]
        L = lines_of(pg)
        start = None
        for i, l in enumerate(L):
            ts = [w["text"] for w in l]
            if "Substances" in ts and "CAS" in ts:
                start = i + 1
                break
        if start is None:
            continue
        body = [l for l in L[start:] if l[0]["top"] < pg.height - 60]
        groups, prev = [], None
        for l in body:
            if prev is not None and l[0]["top"] - prev > 14:
                groups.append([])
            if not groups:
                groups.append([])
            groups[-1].append(l)
            prev = l[0]["top"]
        for g in groups:
            name, cas, ref = [], [], []
            for l in g:
                nm = [w["text"] for w in l if w["x1"] < 400]
                cs = [w["text"] for w in l if 400 <= w["x0"] < 490]
                rf = [w["text"] for w in l if w["x0"] >= 490]
                if nm:
                    name.append(" ".join(nm))
                if cs:
                    cas.append(" ".join(cs))
                if rf:
                    ref.append("".join(rf))
            raw.append({"page": pn, "name": " ".join(name).strip(), "cas": " ".join(cas), "ref": "".join(ref)})
    merged, i = [], 0
    while i < len(raw):
        g = dict(raw[i])
        if i + 1 < len(raw):
            n = raw[i + 1]
            if g["name"] and not g["ref"] and n["ref"] and not n["name"] and n["page"] == g["page"]:
                g["ref"], g["cas"] = n["ref"], g["cas"] + " " + n["cas"]
                i += 1
        merged.append(g)
        i += 1
    out, last = [], None
    for g in merged:
        ok = g["name"] and re.fullmatch(r"A?\d{1,4}", g["ref"])
        if ok:
            last = {"annex": "II", "ref": g["ref"], "names": [g["name"]], "cas": CAS_RE.findall(g["cas"].replace(" ", "")) or CAS_RE.findall(g["cas"]),
                    "text": g["name"]}
            out.append(last)
        elif last is not None and g["page"] < p1 - 2:        # dòng lẻ: danh sách CAS kéo dài của mục trước
            last["cas"] += [c for c in CAS_RE.findall(g["cas"] + " " + g["name"]) if c not in last["cas"]]
    return out


# ---------------------------------------------------------------- Annex III
def parse_annex3(pdf, p0, p1):
    entries, cur = [], None
    for pn in range(p0, p1 + 1):
        pg = pdf.pages[pn - 1]
        L = lines_of(pg)
        start, bounds = 0, [125, 295, 420, 550, 670]
        for i, l in enumerate(L):
            ts = [w["text"] for w in l]
            if ts[:6] == ["A", "B", "C", "D", "E", "F"]:
                start = i + 1
                cen = [(w["x0"] + w["x1"]) / 2.0 for w in l[:6]]      # ranh giới cột theo tiêu đề A..F của CHÍNH trang này
                bounds = [(cen[k] + cen[k + 1]) / 2.0 for k in range(5)]
                bounds[0] = min(bounds[0], 125)
                break
        for l in [x for x in L[start:] if x[0]["top"] < pg.height - 45]:
            cols = {"A": [], "B": [], "C": [], "D": [], "E": [], "F": []}
            for w in l:
                x = w["x0"]
                k = "ABCDEF"[sum(1 for b in bounds if x >= b)]
                cols[k].append(w)
            atxt = " ".join(w["text"] for w in cols["A"])
            refw = [w["text"] for w in cols["A"] if REF_RE.match(w["text"]) and w["x0"] < 110]
            if refw and not atxt.lower().startswith(("see", "acd", "eu")):
                cur = {"annex": "III", "ref": refw[0], "page": pn, "B": [], "C": [], "D": [], "E": [], "F": []}
                entries.append(cur)
            if cur is None:
                continue
            for k in "BCDEF":
                if cols[k]:
                    cur[k].append(" ".join(w["text"] for w in cols[k]))
    out = []
    for e in entries:
        B = e["B"]
        cas = sorted(set(CAS_RE.findall(" ".join(B))))
        names = []
        for ln in B:
            t = re.sub(r"(?i)\bcas\s*no\.?\s*[\d\-/ ,;]*", "", ln).strip(" ;,")
            if len(t) >= 3 and not CAS_RE.fullmatch(t):
                names.append(t)
        joined = [" ".join(names[i:i + 2]) for i in range(len(names) - 1)]
        out.append({"annex": "III", "ref": e["ref"], "page": e["page"], "names": names + joined, "cas": cas,
                    "field": "\n".join(e["C"]), "max": "\n".join(e["D"]), "other": "\n".join(e["E"]),
                    "warn": "\n".join(e["F"]), "text": "\n".join(B)})
    return out


# ---------------------------------------------------------------- Annex VI / VII
def parse_table5(pdf, p0, p1, bounds, annex):
    """5 cột a-e: tham chiếu | chất | nồng độ tối đa | giới hạn | cảnh báo. bounds = 4 mốc x."""
    entries, cur = [], None
    for pn in range(p0, p1 + 1):
        pg = pdf.pages[pn - 1]
        L = lines_of(pg)
        start = None
        for i, l in enumerate(L):
            ts = [w["text"] for w in l]
            if ts[:5] == ["a", "b", "c", "d", "e"]:
                start = i + 1
                break
        if start is None:
            continue
        for l in [x for x in L[start:] if x[0]["top"] < pg.height - 40]:
            cols = {k: [] for k in "ABCDE"}
            for w in l:
                x = w["x0"]
                k = "A" if x < bounds[0] else "B" if x < bounds[1] else "C" if x < bounds[2] else "D" if x < bounds[3] else "E"
                cols[k].append(w["text"])
            a = " ".join(cols["A"])
            if re.fullmatch(r"A?\d{1,3}[a-z]?", a):
                cur = {"annex": annex, "ref": a, "page": pn, "B": [], "C": [], "D": [], "E": []}
                entries.append(cur)
            if cur is None:
                continue
            for k in "BCDE":
                if cols[k]:
                    cur[k].append(" ".join(cols[k]))
    out = []
    for e in entries:
        B = " ".join(e["B"])
        names = [n.strip(" ,;") for n in re.split(r"\s{0}(?:/|\band\b(?=\s+its\b)|;)", B) if len(n.strip()) > 2]
        for ln in e["B"]:                      # mỗi DÒNG của ô tên là một tên gọi riêng (vd 'Oxybenzone' / 'Benzophenone-3')
            t = re.sub(r"(?i)\bcas\s*no\.?[\s\d\-/,;]*", "", ln).strip(" ,;()")
            if len(t) >= 4 and t not in names and not CAS_RE.fullmatch(t):
                names.append(t)
        out.append({"annex": annex, "ref": e["ref"], "page": e["page"], "names": [B] + names, "cas": sorted(set(CAS_RE.findall(B))),
                    "max": "\n".join(e["C"]), "other": "\n".join(e["D"]), "warn": "\n".join(e["E"]), "text": B})
    return out


# ---------------------------------------------------------------- Annex IV
def parse_annex4(pdf, p0, p1):
    out, cur = [], None
    for pn in range(p0, p1 + 1):
        pg = pdf.pages[pn - 1]
        L = lines_of(pg)
        start = 0
        for i, l in enumerate(L):
            if [w["text"] for w in l][:4] == ["1", "2", "3", "4"]:
                start = i + 2
        for l in [x for x in L[start:] if x[0]["top"] < pg.height - 40]:
            first = [w for w in l if w["x0"] < 165]
            m = re.match(r"^(\d{5})(?::\d)?$", first[0]["text"]) if first else None
            if m:
                tail = " ".join(w["text"] for w in first[1:])
                field = [("1" if 230 < w["x0"] < 265 else "2" if 265 <= w["x0"] < 300 else "3" if 300 <= w["x0"] < 335 else "4")
                         for w in l if w["text"] == "X" and 225 < w["x0"] < 380]
                cur = {"annex": "IV", "ref": first[0]["text"], "page": pn, "names": ["CI " + m.group(1)], "cas": [],
                       "field": field[0] if field else "", "other": "", "text": " ".join(w["text"] for w in l if w["x0"] < 230)}
                out.append(cur)
            if cur is not None:
                oth = " ".join(w["text"] for w in l if w["x0"] >= 380)
                if oth:
                    cur["other"] = (cur["other"] + " " + oth).strip()
    return out


# ---------------------------------------------------------------- Bảng tổng hợp của người dùng
def parse_master(path):
    ws = load_workbook(path, read_only=True).worksheets[0]
    try:
        ws.reset_dimensions()
    except Exception:
        pass
    rows = [tuple(r) + (None,) * (5 - len(r)) for r in ws.iter_rows(values_only=True)]
    notes = [str(c) for c in rows[0] if c]
    items = []
    for a, b, *_ in rows[1:]:
        if a and str(a).strip():
            items.append({"name": str(a).strip(), "status": (str(b).strip() if b is not None else "")})
    return items, notes


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    pdf = pdfplumber.open(sys.argv[1])
    rng = find_pages(pdf)
    print("khoảng trang:", rng)
    db = {"version": "", "entries": [], "master": [], "master_notes": []}
    first = (pdf.pages[0].extract_text() or "")
    m = re.search(r"Version No\.?:?\s*(\d{4}-\d+,?\s*\d+\w*\s+\w+\s+\d{4})", first.replace("\n", " "))
    db["version"] = m.group(1).strip() if m else ""
    db["entries"] += parse_annex2(pdf, rng["II"][0] + 1, rng["II"][1])
    db["entries"] += parse_annex3(pdf, rng["III"][0] + 1, rng["III"][1])
    db["entries"] += parse_annex4(pdf, rng["IV"][0], rng["IV"][1])
    db["entries"] += parse_table5(pdf, rng["VI"][0], rng["VI"][1], (110, 322, 478, 592), "VI")
    db["entries"] += parse_table5(pdf, rng["VII"][0], rng["VII"][1], (125, 375, 452, 620), "VII")
    db["master"], db["master_notes"] = parse_master(sys.argv[2])
    counts = {}
    for e in db["entries"]:
        counts[e["annex"]] = counts.get(e["annex"], 0) + 1
    print("phiên bản:", db["version"], "| số mục:", counts, "| bảng của bạn:", len(db["master"]))
    out = os.path.join(ROOT, "regdb.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, separators=(",", ":"))
    print("đã ghi", out, round(os.path.getsize(out) / 1024), "KB")
    return 0


if __name__ == "__main__":
    sys.exit(main())
