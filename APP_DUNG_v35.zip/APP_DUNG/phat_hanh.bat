@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === Tao goi cap nhat (khong can build lai .exe) ===
set "PY="
py -3 --version >nul 2>&1 && set "PY=py -3"
if not defined PY (
  python --version >nul 2>&1 && set "PY=python"
)
if not defined PY (
  echo Khong tim thay Python trong PATH.
  pause
  exit /b 1
)
set /p "URL=Dia chi thu muc dat 2 file phat hanh (vd https://example.com/appdung/): "
set /p "NOTE=Ghi chu ngan cho nguoi dung (co the de trong): "
%PY% tools\phat_hanh.py --url-goc "%URL%" --ghi-chu "%NOTE%"
echo.
echo Hay tai 2 file trong thu muc phat_hanh len dia chi tren (ghi de version.json cu).
pause
