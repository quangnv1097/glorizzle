# -*- coding: utf-8 -*-
"""
Bộ chạy APP DỰNG (đóng gói thành APP_DUNG.exe, chỉ cần gửi khách MỘT LẦN).

Mỗi lần mở: chọn mã app mới nhất trong số
   - bản đi kèm trong file .exe   (thư mục app_code)
   - bản đã tải về qua "Cập nhật"  (%LOCALAPPDATA%\\APP_DUNG\\code\\vNN)
rồi chạy. Bản tải về lỗi ngay lúc khởi động thì bị đánh dấu hỏng và tự quay về bản đi kèm.
Danh sách import bên dưới KHÔNG dùng trực tiếp - chỉ để PyInstaller đóng gói sẵn mọi thư viện mà mã app cần.
"""
import json
import os
import re
import sys
import traceback

LAUNCHER_API = 2

# ---- thư viện cho mã app (đừng xóa; thêm vào đây khi mã app dùng thư viện mới rồi build lại .exe)
import csv, datetime, html, io, queue, shutil, subprocess, tempfile, threading, unicodedata, warnings   # noqa: E401,F401
import hashlib, time, urllib.request, zipfile, xml.etree.ElementTree                                       # noqa: E401,F401
import bisect, difflib                                                                                # noqa: E401,F401
import PIL, PIL.Image, PIL.ImageDraw                                                                   # noqa: E401,F401  (đi kèm pdfplumber)
import tkinter, tkinter.filedialog, tkinter.messagebox, tkinter.simpledialog, tkinter.ttk              # noqa: E401,F401
import openpyxl, openpyxl.styles, openpyxl.styles.colors, openpyxl.utils, openpyxl.utils.datetime     # noqa: E401,F401
import pdfplumber                                                                                      # noqa: F401
try:                                                                                                   # đọc file .xls (tuỳ chọn)
    import xlrd                                                                                        # noqa: F401
except ImportError:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))


def _home():
    env = os.environ.get("APP_DUNG_HOME")
    if env:
        return env
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
    return os.path.join(base, "APP_DUNG")


def _bundled_dir():
    env = os.environ.get("APP_DUNG_BUNDLED")                    # dùng khi thử nghiệm
    if env:
        return env
    return os.path.join(getattr(sys, "_MEIPASS", HERE), "app_code")


def _read_version(d):
    try:
        with open(os.path.join(d, "version.py"), encoding="utf-8") as f:
            m = re.search(r"APP_VERSION\s*=\s*(\d+)", f.read())
        return int(m.group(1)) if m else 0
    except Exception:
        return 0


def _load_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def choose_dirs():
    """Danh sách thư mục mã thử lần lượt: bản tải về (nếu mới hơn bản đi kèm và chưa bị đánh dấu hỏng), rồi bản đi kèm."""
    bundled = _bundled_dir()
    out = []
    root = _home()
    cur = _load_json(os.path.join(root, "current.json"), {})
    d = os.path.join(root, "code", str(cur.get("dir", "")))
    if cur.get("dir") and os.path.isfile(os.path.join(d, "app_dung.py")):
        v = _read_version(d)
        bad = [int(x) for x in _load_json(os.path.join(root, "bad.json"), [])]
        if v > _read_version(bundled) and v not in bad:
            out.append(d)
    out.append(bundled)
    return out


def _mark_bad(d):
    root = _home()
    v = _read_version(d)
    bad = _load_json(os.path.join(root, "bad.json"), [])
    if v and v not in bad:
        bad.append(v)
        try:
            with open(os.path.join(root, "bad.json"), "w", encoding="utf-8") as f:
                json.dump(bad, f)
        except OSError:
            pass


def _purge(d):
    """Gỡ các module đã nạp từ thư mục d (để thử lại bằng thư mục khác)."""
    d = os.path.normcase(os.path.abspath(d))
    for name, mod in list(sys.modules.items()):
        f = getattr(mod, "__file__", None)
        if f and os.path.normcase(os.path.abspath(f)).startswith(d):
            del sys.modules[name]
    sys.path[:] = [p for p in sys.path if os.path.normcase(os.path.abspath(p)) != d]


def _log_error(text):
    try:
        os.makedirs(_home(), exist_ok=True)
        with open(os.path.join(_home(), "launcher_error.log"), "a", encoding="utf-8") as f:
            f.write(text + "\n")
    except OSError:
        pass


def main():
    os.environ["APP_DUNG_LAUNCHER"] = str(LAUNCHER_API)
    dirs = choose_dirs()
    last_err = ""
    for i, d in enumerate(dirs):
        sys.path.insert(0, d)
        try:
            import app_dung
            app = app_dung.Launcher()
        except Exception:
            last_err = traceback.format_exc()
            _log_error("Lỗi khi khởi động mã tại %s:\n%s" % (d, last_err))
            _purge(d)
            if i < len(dirs) - 1:
                _mark_bad(d)                       # bản tải về hỏng -> lần sau không dùng nữa
            continue
        app.mainloop()
        return
    try:
        import tkinter.messagebox as mb
        root = tkinter.Tk()
        root.withdraw()
        mb.showerror("APP DỰNG không khởi động được", last_err[-1500:] or "Không rõ lỗi")
    except Exception:
        pass


if __name__ == "__main__":
    main()
