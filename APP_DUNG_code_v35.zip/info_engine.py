# -*- coding: utf-8 -*-
"""
"Thay đổi các Info": cập nhật hàng loạt thông tin cố định trong nhiều file Form dựng mẫu.
Logic port từ form VBA `frmUpdateInfo`:
  - Chỉ ghi các trường có nhập; để trống = giữ nguyên giá trị trong file.
  - Số điện thoại, ngày ký ghi dạng TEXT (giữ số 0 đầu), giống việc thêm dấu ' trong VBA.
  - Sheet 1  : thông tin công ty chịu trách nhiệm (kể cả Fax I43) / người đại diện / công ty nhập khẩu (Fax I50) / người ký
  - Sheet 2  : nhà sản xuất (dòng 3: B tên, C địa chỉ, D số điện thoại)
  - Sheet 3  : đơn vị đóng gói (dòng 3: B tên, C địa chỉ, D số điện thoại)
Sửa trực tiếp XML của .xlsx/.xlsm nên giữ nguyên định dạng, data validation, macro, các sheet khác.
"""
import os
import re
import shutil
import tempfile
import warnings
import zipfile
import xml.etree.ElementTree as ET

from openpyxl import load_workbook

from xlsx_core import clean_text, count_sheets, set_cell_text, sheet_path_by_index

# (khóa, nhãn, [(chỉ số sheet từ 0, ô)], nhóm)
FIELDS = [
    ("co_name", "Tên công ty (và công ty nhập khẩu)", [(0, "B42"), (0, "B49")], "chung"),
    ("rep_name", "Họ tên người đại diện / người ký", [(0, "B46"), (0, "B54")], "chung"),
    ("rep_title", "Chức vụ ở công ty", [(0, "I47")], "chung"),
    ("rep_phone", "Điện thoại người đại diện", [(0, "I46")], "chung"),
    ("email", "Email", [(0, "B47")], "chung"),
    ("co_phone", "Số điện thoại công ty (và công ty nhập khẩu)", [(0, "B43"), (0, "B50")], "chung"),
    ("co_fax", "Fax công ty (và công ty nhập khẩu)", [(0, "I43"), (0, "I50")], "chung"),
    ("co_address", "Địa chỉ công ty (và công ty nhập khẩu)", [(0, "I42"), (0, "I49")], "chung"),
    ("sign_date", "Ngày ký (dd/mm/yyyy)", [(0, "I53")], "chung"),
    ("nsx_name", "Tên công ty sản xuất", [(1, "B3")], "nsx"),
    ("nsx_address", "Địa chỉ", [(1, "C3")], "nsx"),
    ("nsx_phone", "Số điện thoại", [(1, "D3")], "nsx"),
    ("nsx_fax", "Fax", [(1, "E3")], "nsx"),
    ("dg_name", "Tên đơn vị đóng gói", [(2, "B3")], "dg"),
    ("dg_address", "Địa chỉ", [(2, "C3")], "dg"),
    ("dg_phone", "Số điện thoại", [(2, "D3")], "dg"),
    ("dg_fax", "Fax", [(2, "E3")], "dg"),
]
FIELD_BY_KEY = {f[0]: f for f in FIELDS}
GROUP_TITLES = {
    "chung": "Thông tin chung (sheet 1)",
    "nsx": "Nhà sản xuất (sheet 2)",
    "dg": "Đơn vị đóng gói (sheet 3)",
}
SUPPORTED = (".xlsx", ".xlsm")
DATE_RE = re.compile(r"^\d{1,2}/\d{1,2}/\d{4}$")


def targets_text(key):
    return ", ".join(ref for _s, ref in FIELD_BY_KEY[key][2])


def clean_values(values):
    """Bỏ khoảng trắng thừa; trường trống bị loại (giữ nguyên trong file)."""
    out = {}
    for k, v in (values or {}).items():
        if k in FIELD_BY_KEY:
            v = clean_text(v).strip()
            if v:
                out[k] = v
    return out


def validate(values):
    """Trả về danh sách cảnh báo (không chặn)."""
    warns = []
    d = values.get("sign_date")
    if d and not DATE_RE.match(d):
        warns.append("Ngày ký '%s' không đúng dạng dd/mm/yyyy." % d)
    em = values.get("email")
    if em and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", em):
        warns.append("Email '%s' có vẻ chưa đúng định dạng." % em)
    return warns


def build_plan(values):
    """{chỉ số sheet: {ô: nội dung}}"""
    plan = {}
    for key, v in clean_values(values).items():
        for si, ref in FIELD_BY_KEY[key][2]:
            plan.setdefault(si, {})[ref] = v
    return plan


def _cell_values(path, plan):
    """Đọc lại giá trị các ô trong plan (để kiểm tra sau khi ghi)."""
    out = {}
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            for si, cells in plan.items():
                ws = wb.worksheets[si]
                try:
                    ws.reset_dimensions()
                except Exception:
                    pass
                for ref in cells:
                    m = re.fullmatch(r"([A-Z]+)(\d+)", ref)
                    col = 0
                    for ch in m.group(1):
                        col = col * 26 + ord(ch) - 64
                    row = int(m.group(2))
                    got = None
                    for r in ws.iter_rows(min_row=row, max_row=row, min_col=col, max_col=col,
                                          values_only=True):
                        got = r[0] if r else None
                    out[(si, ref)] = clean_text(got) if got is not None else ""
        finally:
            wb.close()
    return out


def read_info(path):
    """Đọc giá trị hiện có của các trường (lấy ô đầu tiên của mỗi trường)."""
    plan = {}
    for key, _label, targets, _g in FIELDS:
        si, ref = targets[0]
        plan.setdefault(si, {})[ref] = ""
    with zipfile.ZipFile(path) as z:
        n = count_sheets(z)
    plan = {si: c for si, c in plan.items() if si < n}
    vals = _cell_values(path, plan)
    return {key: vals.get(targets[0], "").strip() for key, _l, targets, _g in FIELDS}


def update_file(path, values, make_backup=True):
    """Cập nhật 1 file. Trả về (số_ô_đã_ghi, [cảnh_báo]). Ném lỗi nếu không ghi được."""
    if not path.lower().endswith(SUPPORTED):
        raise ValueError("định dạng không hỗ trợ (hãy lưu sang .xlsx): %s" % os.path.splitext(path)[1])
    plan = build_plan(values)
    if not plan:
        return 0, ["không có trường nào được nhập"]
    notes = []
    with zipfile.ZipFile(path) as zin:
        n_sheets = count_sheets(zin)
        if n_sheets < 1:
            raise ValueError("file không có sheet nào")
        names = {0: "sheet 1", 1: "sheet 2 (nhà sản xuất)", 2: "sheet 3 (đơn vị đóng gói)"}
        for si in list(plan):
            if si >= n_sheets:
                notes.append("không có %s nên bỏ qua phần này" % names.get(si, "sheet %d" % (si + 1)))
                del plan[si]
        if not plan:
            raise ValueError("file thiếu sheet cần cập nhật")
        patched = {}
        for si, cells in plan.items():
            sp = sheet_path_by_index(zin, si)
            xml = zin.read(sp).decode("utf-8")
            for ref, val in cells.items():
                xml = set_cell_text(xml, ref, val)
            ET.fromstring(xml.encode("utf-8"))               # đảm bảo XML hợp lệ
            patched[sp] = xml.encode("utf-8")

        fd, tmp = tempfile.mkstemp(suffix=os.path.splitext(path)[1], dir=os.path.dirname(path) or ".")
        os.close(fd)
        try:
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
                for item in zin.infolist():
                    data = patched.get(item.filename)
                    zout.writestr(item, data if data is not None else zin.read(item.filename))
        except Exception:
            os.remove(tmp)
            raise

    try:
        got = _cell_values(tmp, plan)
        for si, cells in plan.items():
            for ref, val in cells.items():
                if got.get((si, ref), "") != clean_text(val):
                    raise ValueError("kiểm tra sau khi ghi không khớp ở ô %s (sheet %d)" % (ref, si + 1))
        if make_backup:
            bak = path + ".bak"
            if not os.path.exists(bak):
                shutil.copy2(path, bak)
        os.replace(tmp, path)
    except Exception:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise
    return sum(len(c) for c in plan.values()), notes
