# -*- coding: utf-8 -*-
"""
Suy ra LOẠI SẢN PHẨM (ô Có/Không sheet 1) từ DANH SÁCH THÀNH PHẦN.

Hai nguồn:
  1) ASEAN Annex III (regdb.json, cột "field" = loại sản phẩm được phép dùng chất đó).
     Chất CHỈ được phép trong MỘT loại sản phẩm (vd chất nhuộm oxy hóa chỉ dùng cho thuốc nhuộm tóc,
     fluoride chỉ dùng cho sản phẩm răng miệng) thì có mặt chất đó = sản phẩm thuộc loại đó.
     Chất được phép ở nhiều loại (vd H2O2: tóc, da, móng, răng; NaOH: gần như mọi loại) thì bỏ qua.
     Chất chỉ dùng cho TÓC nhưng nhiều loại tóc (vd Resorcinol: thuốc nhuộm + dầu gội) -> chỉ tích I13.
  2) Danh sách tự soạn (MARKERS) cho chất app không khớp được tên với Annex hoặc không có trong Annex
     (vd Toluene-2,5-diamine sulfate, Cysteamine HCl, Aluminum chlorohydrate).
  3) Luật phân xử (vd Thioglycolate: muối Ca/K/Sr hoặc đi cùng Ca(OH)2 -> tẩy lông I11; còn lại -> uốn tóc I15).

Kết quả: (tập dòng nên tích "Có", danh sách lý do để ghi nhật ký).
"""

import re

# ---------------------------------------------------------------------------
# Loại sản phẩm -> ô Có/Không của Form dựng mẫu (đối chiếu nhãn cột B sheet 1)
# ---------------------------------------------------------------------------
ROW = {
    "hairdye": 14,     # Nhuộm và tẩy màu tóc
    "wave": 15,        # Uốn tóc, duỗi tóc, giữ nếp tóc
    "depil": 11,       # Sản phẩm tẩy lông
    "antiper": 12,     # Khử mùi và chống mùi
    "oral": 23,        # Chăm sóc răng và miệng
    "nail": 24,        # Chăm sóc và tô điểm móng
    "tan": 27,         # Làm sạm da không cần tắm nắng
    "hair": 13,        # Sản phẩm chăm sóc tóc (nhóm cha)
}
HAIR_KINDS = {"hairdye", "wave", "hairother"}

# Nhận diện loại sản phẩm trong chữ của cột "field" Annex III
_FIELD_TAGS = [
    ("hairdye", r"hair\s*dye|hair\s*colou?r|bleach"),          # chất nhuộm / tẩy màu tóc
    ("wave", r"waving|straighten|hair\s*setting"),
    ("depil", r"depilator"),
    ("oral", r"oral|tooth|mouth|dental"),
    ("nail", r"\bnail"),
    ("antiper", r"perspirant|deodorant"),
    ("tan", r"tanning"),
    ("hairother", r"hair|shampoo|scalp"),
]
_FIELD_RX = [(t, re.compile(p, re.I)) for t, p in _FIELD_TAGS]
# phần sau các chữ này là loại TRỪ RA / CẤM, không phải loại được dùng
_NEG = re.compile(r"\b(?:except|exception|excluding|other than|prohibited|not permitted|not to be used|shall not|must not)\b.*", re.I | re.S)


def field_tags(field):
    """Tập loại sản phẩm được phép dùng chất này theo cột field. Đoạn không nêu loại cụ thể nào
    (vd 'Other products', 'Face products', 'Rinse-off products only') -> 'generic' (dùng được nhiều loại)."""
    tags = set()
    for part in re.split(r"\(\s*[a-z]\s*\)|(?:^|\n)\s*[a-z]\)|•", field or ""):
        part = _NEG.sub("", part).strip(" .,;:\n")
        if not part or re.fullmatch(r"[\d.\s()]*", part):
            continue
        found = {t for t, rx in _FIELD_RX if rx.search(part)}
        if found & {"hairdye", "wave"}:
            found.discard("hairother")
        tags |= found or {"generic"}
    return tags


# ---------------------------------------------------------------------------
# Danh sách tự soạn: chất -> loại sản phẩm (dùng khi Annex không khớp tên / không có trong Annex)
# ---------------------------------------------------------------------------
MARKERS = [
    ("hairdye", r"persulfate|persulphate|phenylenediamine|toluene-2,5-diamine|diaminophenoxyethanol|amino-2-hydroxytoluene|aminocresol"
                r"|hydroxybenzomorpholine|diaminopyrazole|diaminopyridine|hydroxyindole|1-naphthol"
                r"|(?<![a-z-])(?<!phenylethyl )2-methylresorcinol|[mpo]-aminophenol|\bhc (?:yellow|red|blue|violet|orange|brown|green)"
                r"|basic (?:red|blue|yellow|brown|violet|orange)\b|disperse (?:black|blue|violet|red)|lawsonia|henna"),
    ("wave", r"cysteamine|thiolactic|mercaptopropionic|glyceryl thioglycolate|ammonium thioglycolate|ethanolamine thioglycolate"),
    ("depil", r"(?:calcium|potassium|strontium) thioglycolate|strontium sulfide|barium sulfide"),
    ("antiper", r"alumin(?:i)?um (?:zirconium |sesqui)?chlorohydr|aluminum chloride|alumin(?:i)?um chloride|aluminium zirconium"),
    ("oral", r"fluoride|monofluorophosphate|hydroxyapatite"),
    ("tan", r"dihydroxyacetone|erythrulose"),
    ("nail", r"nitrocellulose|tosylamide/formaldehyde|trimethyl pentanyl diisobutyrate"),
]
_MARKER_RX = [(t, re.compile(p, re.I)) for t, p in MARKERS]
# Chất bị Annex coi là "chỉ 1 loại" nhưng thực tế không đủ để kết luận loại sản phẩm -> không dùng Annex cho chất này
ANNEX_SKIP = re.compile(r"dihydroxyacetone|dihydroxy-\s*2-propanone|hydrogen peroxide|titanium dioxide|zinc oxide"
                        r"|formaldehyde|hydroquinone|mequinol|toluene\b|benzene, methyl", re.I)

_THIO = re.compile(r"thioglycol", re.I)
_DEPIL_HINT = re.compile(r"calcium hydroxide|strontium hydroxide|(?:calcium|potassium|strontium) thioglycolate", re.I)


def _annex_kind(db, name):
    """Loại sản phẩm suy ra từ Annex III cho 1 tên thành phần: 'hairdye' | 'wave' | ... | 'hair' | None."""
    if db is None or ANNEX_SKIP.search(name):
        return None, ""
    try:
        hits, _master, _how = db.lookup(name)
    except Exception:
        return None, ""
    for e in hits:
        if e.get("annex") != "III":
            continue
        tags = field_tags(e.get("field") or "")
        if not tags or "generic" in tags:
            continue
        ref = "Annex III/%s" % e.get("ref", "")
        if len(tags) == 1:
            t = next(iter(tags))
            return ("hair" if t == "hairother" else t), ref
        if tags <= HAIR_KINDS:                 # chỉ dùng cho tóc nhưng nhiều loại tóc -> chỉ chắc là SP tóc
            return "hair", ref
    return None, ""


def infer(ingredients, db=None):
    """ingredients: [(tên, hàm lượng, ...)] -> (set dòng cần tích, [lý do])."""
    if db is None:
        try:
            import reg_engine
            db = reg_engine.get_db()
        except Exception:
            db = None
    names = [str(it[0]).strip() for it in ingredients if it and it[0] is not None and str(it[0]).strip()]
    all_text = " | ".join(names)
    rows, why = set(), []

    def add(kind, name, src):
        if kind not in ROW:
            return
        r = ROW[kind]
        if r not in rows:
            rows.add(r)
            why.append("I%d theo thành phần %s (%s)" % (r, name, src))

    for name in names:
        if _THIO.search(name):              # thioglycolate: uốn tóc hay tẩy lông?
            add("depil" if _DEPIL_HINT.search(all_text) else "wave", name, "thioglycolate")
            continue
        kind, src = None, ""
        for t, rx in _MARKER_RX:
            if rx.search(name):
                kind, src = t, "danh sách chất đặc trưng"
                break
        if not kind:
            kind, src = _annex_kind(db, name)
        if kind:
            add(kind, name, src)
    if rows & {ROW["hairdye"], ROW["wave"]} and ROW["hair"] not in rows:
        rows.add(ROW["hair"])
        why.append("I13 vì đã tích loại sản phẩm tóc (I14/I15)")
    return rows, why
