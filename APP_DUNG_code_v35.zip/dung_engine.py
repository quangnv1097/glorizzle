# -*- coding: utf-8 -*-
"""
Engine "Dựng BTP": từ file BTP (nhiều sheet sản phẩm) + file Form dựng mẫu (template)
-> mỗi sheet sản phẩm thành 1 file Excel dựng sẵn.

Logic port từ macro VBA `Dung_promax` (file TH_check_TP (Tools).xlsm):
  - Chỉ lấy sheet có tên bắt đầu bằng số, bỏ sheet tổng hợp (Tong hop / TH).
  - Tên sản phẩm = ô A2 của sheet (bỏ số thứ tự đứng đầu) -> I2 của template.
  - Công dụng -> B32: tra theo bảng "Thao Tac" A:B (khớp từ khóa trước, fuzzy sau, ngưỡng 0.55).
  - Thành phần: cột C, D, E của sheet BTP -> sheet 4 (cột B, C, D), STT ở cột A.
  - Tích Có/Không I4:I30: ô trống -> "Không"; nếu từ khóa (cột E "Thao Tac") xuất hiện trong
    tên SP | công dụng | tên thành phần -> "Có".

File kết quả được tạo bằng cách sửa trực tiếp XML của template nên giữ nguyên toàn bộ
định dạng, data validation, các sheet khác (không cần cài Excel).
"""

import json
import os
import re
import shutil
import tempfile
import unicodedata
import warnings
import xml.etree.ElementTree as ET
import zipfile
from datetime import date, datetime

from openpyxl import load_workbook

import name_clean
from openpyxl.utils.datetime import to_excel

from xlsx_core import (FORM_ROWS, clean_text, count_sheets, read_form, sheet_path_by_index,
                       write_changes)

FUZZY_THRESHOLD = 0.55
ING_FIRST_ROW = 5            # dòng đầu của bảng thành phần ở sheet 4
ING_CLEAR_LAST_ROW = 1000    # macro xóa A5:D1000 trước khi ghi
ING_SHEET_INDEX = 3          # sheet thứ 4 (đếm từ 0)
CHECK_FIRST, CHECK_LAST = 4, 30
CONGDUNG_ROW = 32

CHECK_ROWS = {r for k, r in FORM_ROWS if k == "check"}


# ----------------------------------------------------------------------------
# Hàm xử lý chuỗi (port từ VBA)
# ----------------------------------------------------------------------------
def remove_number_prefix(raw):
    """Bỏ số thứ tự đứng đầu tên: '1. abc', '3.1 - abc' -> 'abc'."""
    raw = (raw or "").strip()
    if not raw:
        return ""
    arr = raw.split(" ")
    for i, part in enumerate(arr):
        part = part.strip()
        is_prefix = False
        if part == "-":
            is_prefix = True
        elif re.search(r"[0-9]", part):
            if all(c in "0123456789.-" for c in part):
                is_prefix = True
        if not is_prefix:
            return " ".join(arr[i:]).strip()
    return raw


def _unaccent(s):
    s = s.replace("Đ", "D").replace("đ", "d")
    return "".join(c for c in unicodedata.normalize("NFD", s)
                   if unicodedata.category(c) != "Mn")


_INVISIBLE = {0x200B: None, 0x200C: None, 0x200D: None, 0xFEFF: None}


def strip_invisible(s):
    """DungGop.StripInvisible: bỏ ký tự ẩn (zero-width, BOM), NBSP/tab/xuống dòng -> dấu cách, gộp khoảng trắng."""
    s = str(s or "").translate(_INVISIBLE)
    for ch in ("\xa0", "\t", "\n", "\r"):
        s = s.replace(ch, " ")
    return re.sub(r" +", " ", s).strip()


def clean_product_name(raw):
    """DungGop.CleanProductName: bỏ ký tự ẩn + số thứ tự đầu tên (kể cả dạng dính liền '2.HINCE', '3.1. X')."""
    s = strip_invisible(raw)
    if not s:
        return ""
    i = 1
    while i <= len(s) and (("0" <= s[i - 1] <= "9") or s[i - 1] == "."):
        i += 1
    if 1 < i <= len(s) and s[i - 2] == ".":
        s = s[i - 1:].strip()
    return remove_number_prefix(s)


def extract_shade(raw):
    """DungGop.ExtractShade / gop: sau khi làm sạch tên, lấy từ ĐẦU TIÊN có chữ số đến hết tên.
    Vd '1. hince NU BLUR TINT 13 SPICE ( B62B5-BAD3 )' -> '13 SPICE ( B62B5-BAD3 )';
       '30. hince ... BALM TP007 ODD ROSE' -> 'TP007 ODD ROSE'. Không có từ nào chứa số -> ''."""
    cleaned = clean_product_name(raw)
    if not cleaned:
        return ""
    words = cleaned.split(" ")
    for i, w in enumerate(words):
        if re.search(r"[0-9]", w):
            return " ".join(words[i:]).strip()
    return ""


def is_summary_sheet(name):
    """Sheet tổng hợp cần bỏ qua: 'Tong hop', 'TH', '1. TH', 'TH - ...'."""
    u = _unaccent(name.strip()).upper()
    if re.search(r"TONG.*HOP", u):
        return True
    if u == "TH":
        return True
    if (re.match(r"^TH [^A-Z0-9]", u) or u.endswith(" TH")
            or re.search(r" TH [^A-Z0-9]", u)
            or u.endswith((".TH", "-TH", "_TH"))):
        return True
    return False


def is_product_sheet(name):
    name = name.strip()
    return bool(re.match(r"[0-9]", name)) and not is_summary_sheet(name)


def safe_file_part(text):
    for ch in '/\\:*?"<>|[]':
        text = text.replace(ch, "_")
    return text.strip()


def clean_string(s):
    s = s.lower().replace("-", " ").replace("_", " ").replace("/", " ")
    res = "".join(ch for ch in s if ("a" <= ch <= "z") or ("0" <= ch <= "9") or ch == " ")
    return " ".join(res.split())


def levenshtein(s, t):
    n, m = len(s), len(t)
    if n == 0:
        return m
    if m == 0:
        return n
    prev = list(range(m + 1))
    for i in range(1, n + 1):
        cur = [i] + [0] * m
        for j in range(1, m + 1):
            cost = 0 if s[i - 1] == t[j - 1] else 1
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
        prev = cur
    return prev[m]


def fuzzy_score(source, target):
    """Tỉ lệ số từ của `source` khớp (hoặc gần khớp) với các từ của `target`."""
    s, t = clean_string(source), clean_string(target)
    if not s or not t:
        return 0.0
    sw, tw = s.split(" "), t.split(" ")
    matched_count = 0
    for sword in sw:
        if not sword:
            continue
        for tword in tw:
            if sword == tword:
                matched_count += 1
                break
            if len(sword) >= 3 and len(tword) >= 3:
                maxd = 2 if len(sword) > 6 else 1
                if levenshtein(sword, tword) <= maxd:
                    matched_count += 1
                    break
    return matched_count / len(sw) if sw else 0.0


# ----------------------------------------------------------------------------
# Bảng quy tắc: công dụng + từ khóa tích Có/Không
# ----------------------------------------------------------------------------
class Rules:
    """congdung: list[(từ khóa tên SP, nội dung công dụng)]  (khóa không phân biệt hoa/thường)
       checks : list[(ô I.., chuỗi từ khóa cách nhau dấu phẩy)]"""

    def __init__(self, congdung=None, checks=None, source=""):
        self.congdung = list(congdung or [])
        self.checks = list(checks or [])
        self.source = source

    def to_json(self):
        return {"congdung": self.congdung, "checks": self.checks, "source": self.source}

    @classmethod
    def from_json(cls, d):
        return cls([tuple(x) for x in d.get("congdung", [])],
                   [tuple(x) for x in d.get("checks", [])], d.get("source", ""))

    def summary(self):
        return "%d công dụng, %d quy tắc từ khóa" % (len(self.congdung), len(self.checks))


def load_rules_xlsx(path, sheet_name="Thao Tac", first_row=36, last_row=100):
    """Đọc bảng quy tắc từ sheet 'Thao Tac' (giống macro): A:B công dụng, D:E từ khóa."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            ws = None
            for w in wb.worksheets:
                if _unaccent(w.title).strip().lower().replace(" ", "") == sheet_name.lower().replace(" ", ""):
                    ws = w
                    break
            if ws is None:
                raise ValueError("Không thấy sheet '%s' trong file này." % sheet_name)
            try:
                ws.reset_dimensions()
            except Exception:
                pass
            rows = list(ws.iter_rows(min_row=first_row, max_row=last_row,
                                     min_col=1, max_col=5, values_only=True))
        finally:
            wb.close()
    congdung, checks = [], []
    seen_cd, seen_cell = set(), set()
    for row in rows:
        row = tuple(row) + (None,) * (5 - len(row))
        key = clean_text(row[0]).strip()
        if key and key.casefold() not in seen_cd:
            seen_cd.add(key.casefold())
            congdung.append((key, clean_text(row[1])))
        cell = clean_text(row[3]).strip()
        kw = clean_text(row[4]).strip()
        if cell and kw and cell.casefold() not in seen_cell:
            seen_cell.add(cell.casefold())
            checks.append((cell, kw))
    return Rules(congdung, checks, os.path.abspath(path))


def match_congdung(prod_clean, sheet_name, congdung):
    """Trả về (nội dung, khóa khớp, điểm). Giống macro: khóa nằm trong tên -> khớp ngay,
    nếu không thì chấm fuzzy, lấy điểm cao nhất, cần >= 0.55."""
    best_key, best_val, max_score = "", "", 0.0
    pn, sn = prod_clean.casefold(), sheet_name.casefold()
    for key, val in congdung:
        k = key.casefold()
        if k in pn or k in sn:
            return val, key, 1.0
        for src in (prod_clean, sheet_name):
            sc = fuzzy_score(src, key)
            if sc > max_score:
                max_score, best_key, best_val = sc, key, val
    if max_score >= FUZZY_THRESHOLD:
        return best_val, best_key, max_score
    return "", "", max_score


def match_congdung_multi(pairs, congdung):
    """pairs = [(tên sản phẩm đã làm sạch, tên sheet), ...]. Lấy kết quả điểm cao nhất
    trong các sheet (giống GopDung: chấm tất cả sheet của nhóm, lấy tên khớp nhất)."""
    best = ("", "", 0.0)
    for prod, sheet_name in pairs:
        val, key, score = match_congdung(prod, sheet_name, congdung)
        if key and score > best[2]:
            best = (val, key, score)
        elif not best[1] and score > best[2]:
            best = ("", "", score)
    return best


# ----------------------------------------------------------------------------
# Công dụng lẻ từ file ngoài: bảng "Tên sản phẩm | Công dụng" do người dùng nạp
# ----------------------------------------------------------------------------
EXT_MIN_SCORE = 0.85


def _hdr_kind(v):
    t = clean_string(_unaccent(clean_text(v))) if v is not None else ""
    if not t:
        return ""
    if "cong dung" in t or t in ("use", "uses", "usage", "intended use", "purpose"):
        return "cd"
    if "product" in t or "ten san pham" in t or t in ("ten", "name", "san pham"):
        return "name"
    return ""


def load_congdung_file(path):
    """Đọc file công dụng lẻ (.xlsx/.xlsm): mỗi dòng một sản phẩm -> list[(tên sản phẩm, công dụng)].
    Tự tìm dòng tiêu đề có cột 'PRODUCT NAME' / 'Tên sản phẩm' và 'Công dụng…'; không thấy thì lấy cột B = tên, cột C = công dụng
    (hoặc A = tên, B = công dụng nếu file chỉ có hai cột). Quét mọi sheet, bỏ dòng trống, tên trùng lấy dòng đầu."""
    if os.path.splitext(path)[1].lower() not in (".xlsx", ".xlsm"):
        raise ValueError("File công dụng cần là .xlsx / .xlsm")
    out, seen = [], set()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            for ws in wb.worksheets:
                try:
                    ws.reset_dimensions()
                except Exception:
                    pass
                rows = [tuple(r) for r in ws.iter_rows(min_col=1, max_col=8, values_only=True)]
                ncol, ccol, start = None, None, 0
                for i, r in enumerate(rows[:15]):
                    kinds = [_hdr_kind(v) for v in r]
                    if "cd" in kinds and "name" in kinds:
                        ncol, ccol, start = kinds.index("name"), kinds.index("cd"), i + 1
                        break
                if ncol is None:
                    width = max((sum(1 for v in r if v not in (None, "")) for r in rows), default=0)
                    ncol, ccol = (1, 2) if width >= 3 else (0, 1)
                for r in rows[start:]:
                    r = r + (None,) * 8
                    name = clean_text(r[ncol]).strip() if r[ncol] is not None else ""
                    cd = clean_text(r[ccol]).strip() if r[ccol] is not None else ""
                    if not name or not cd:
                        continue
                    k = clean_string(name)
                    if not k or k in seen:
                        continue
                    seen.add(k)
                    out.append((name, cd))
        finally:
            wb.close()
    if not out:
        raise ValueError("Không thấy dòng 'tên sản phẩm - công dụng' nào trong file")
    return out


def match_external_congdung(names, entries):
    """names: các tên cần dò (tên sản phẩm, tên sheet, tên gốc của nhóm...). entries: list[(tên SP, công dụng)] từ file ngoài.
    Khớp CHẶT hơn quy tắc tích hợp (vì khóa ở đây là tên sản phẩm đầy đủ): trùng tên sau khi làm sạch = 1.0;
    tên trong file nằm trọn trong tên cần dò (từ 3 từ trở lên) = 0.95; còn lại điểm fuzzy hai chiều (tối thiểu cả hai) >= 0.85.
    Trả về (công dụng, tên khớp trong file, điểm) - ('', '', điểm cao nhất) nếu không khớp."""
    best = ("", "", 0.0, 0)
    cleaned = [clean_string(n) for n in names if n]
    for key, val in entries:
        ck = clean_string(key)
        if not ck:
            continue
        for cn in cleaned:
            if not cn:
                continue
            if cn == ck:
                sc = 1.0
            elif len(ck.split()) >= 3 and (" " + ck + " ") in (" " + cn + " "):
                sc = 0.95
            else:
                sc = min(fuzzy_score(cn, ck), fuzzy_score(ck, cn))
            if sc > best[2] or (sc == best[2] and len(ck) > best[3]):
                best = (val, key, sc, len(ck))
    if best[2] >= EXT_MIN_SCORE:
        return best[0], best[1], best[2]
    return "", "", best[2]


# ----------------------------------------------------------------------------
# Đọc file BTP
# ----------------------------------------------------------------------------
class BtpSheet:
    def __init__(self, name, rows, tab_color=""):
        self.name = name.strip()
        self.rows = rows            # list các tuple (A, B, C, D, E, F)
        self.tab_color = tab_color  # khóa màu tab sheet ("" = không tô màu), xem read_tab_colors

    @property
    def product_raw(self):
        raw = ""
        for k in (1, 0):                      # ô A2 (như macro), sheet chỉ có 1 dòng thì lấy A1
            if len(self.rows) > k and self.rows[k][0] is not None:
                raw = clean_text(self.rows[k][0]).strip()
                if raw:
                    break
        return raw or self.name

    @property
    def product(self):
        return clean_product_name(self.product_raw) or self.name

    @staticmethod
    def _split(name, pct, third):
        """Tên dạng 'Glycerin 5%' và ô hàm lượng trống -> tách '5' sang ô hàm lượng."""
        n2, p2 = name_clean.split_name_pct(name)
        if p2 and (pct is None or str(pct).strip() == ""):
            return (n2, p2, third)
        return (name, pct, third)

    @staticmethod
    def _is_full_list(r):
        """Dòng ghi cả chuỗi thành phần (vd '成份:WATER,ETHANOLAMINE,THIOGLYCOLIC ACID,...' hoặc
        'Ingredients: Water, Glycerin, ...') nằm dưới bảng: có dấu ':' + từ 3 dấu phẩy trở lên và
        ô hàm lượng trống -> không phải 1 thành phần, bỏ qua."""
        name = clean_text(r[2]) if r[2] is not None else ""
        pct = r[3]
        if pct is not None and str(pct).strip() != "":
            return False
        return (":" in name or "\uff1a" in name) and (name.count(",") + name.count("\uff0c")) >= 3

    def _data_rows(self):
        """Các dòng 1..dòng cuối có dữ liệu ở cột C (bỏ dòng chuỗi thành phần đầy đủ)."""
        last = 0
        for i, r in enumerate(self.rows, start=1):
            if r[2] is not None and r[2] != "" and not self._is_full_list(r):
                last = i
        return [r for r in self.rows[:last] if not self._is_full_list(r)]

    @property
    def ingredients(self):
        """Các dòng 1..dòng cuối có dữ liệu ở cột C -> list (C, D, E)."""
        return [self._split(name_clean.clean_name(r[2]), r[3], r[4]) for r in self._data_rows()]

    @property
    def ingredients_f(self):
        """Như `ingredients` nhưng cột thứ ba lấy từ cột F (tên dạng/màu) - dùng cho gộp theo nhóm."""
        out = []
        for r in self._data_rows():
            n, d, f = self._split(name_clean.clean_name(r[2]), r[3], r[5])
            code = shade_code(r[0]) if (r[0] is not None and str(r[0]).strip()) else ""
            out.append((n, d, code or f))
        return out


_THEME_RGB = ["FFFFFF", "000000", "E7E6E6", "44546A", "4472C4", "ED7D31", "A5A5A5", "FFC000", "5B9BD5", "70AD47"]
_TAB_RE = re.compile(r"<tabColor\b([^>]*)/?>")


def read_tab_colors(path):
    """Màu tab của từng sheet (theo thứ tự trong workbook) -> list khóa màu; '' nếu sheet không tô màu.
    Khóa: 'rgb:RRGGBB' | 'theme:<n>:<tint>' | 'indexed:<n>'. File .xls không đọc được màu -> toàn ''."""
    if os.path.splitext(path)[1].lower() not in (".xlsx", ".xlsm"):
        return None
    out = []
    try:
        with zipfile.ZipFile(path) as z:
            for i in range(count_sheets(z)):
                key = ""
                try:
                    head = z.read(sheet_path_by_index(z, i))[:6000].decode("utf-8", "ignore")
                    m = _TAB_RE.search(head)
                    if m:
                        at = dict(re.findall(r'(\w+)="([^"]*)"', m.group(1)))
                        if "rgb" in at:
                            key = "rgb:" + at["rgb"][-6:].upper()
                        elif "theme" in at:
                            key = "theme:%s:%s" % (at["theme"], at.get("tint", "0"))
                        elif "indexed" in at:
                            key = "indexed:" + at["indexed"]
                except Exception:
                    key = ""
                out.append(key)
    except Exception:
        return None
    return out


def tab_color_hex(key):
    """Khóa màu tab -> '#RRGGBB' để tô trên giao diện ('' nếu không có / không đoán được)."""
    if not key:
        return ""
    try:
        kind, *rest = key.split(":")
        if kind == "rgb":
            return "#" + rest[0]
        if kind == "theme":
            base = _THEME_RGB[int(rest[0]) % len(_THEME_RGB)]
            tint = float(rest[1]) if len(rest) > 1 else 0.0
            ch = [int(base[i:i + 2], 16) for i in (0, 2, 4)]
            ch = [c * (1 + tint) if tint < 0 else c + (255 - c) * tint for c in ch]
            return "#%02X%02X%02X" % tuple(max(0, min(255, int(round(c)))) for c in ch)
        if kind == "indexed":
            from openpyxl.styles.colors import COLOR_INDEX
            v = COLOR_INDEX[int(rest[0])]
            return "#" + v[-6:]
    except Exception:
        return ""
    return ""


def read_btp(path):
    """Đọc toàn bộ sheet của file BTP (.xlsx/.xlsm/.xls). Trả về list[BtpSheet]."""
    sheets = _read_btp_rows(path)
    colors = read_tab_colors(path)
    if colors and len(colors) == len(sheets):
        for sh, c in zip(sheets, colors):
            sh.tab_color = c
    return sheets


def _read_btp_rows(path):
    ext = os.path.splitext(path)[1].lower()
    sheets = []
    if ext == ".xls":
        try:
            import xlrd
        except ImportError:
            raise ValueError("File .xls cần thư viện xlrd (pip install xlrd) "
                             "hoặc hãy lưu file BTP sang .xlsx.")
        book = xlrd.open_workbook(path)
        for sh in book.sheets():
            rows = []
            for r in range(sh.nrows):
                vals = sh.row_values(r)[:6]
                vals = [None if v == "" else v for v in vals] + [None] * (6 - len(vals))
                rows.append(tuple(vals))
            sheets.append(BtpSheet(sh.name, rows))
        return sheets
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            for ws in wb.worksheets:
                try:
                    ws.reset_dimensions()
                except Exception:
                    pass
                rows = []
                for r in ws.iter_rows(min_col=1, max_col=6, values_only=True):
                    r = tuple(r)[:6]
                    rows.append(r + (None,) * (6 - len(r)))
                sheets.append(BtpSheet(ws.title, rows))
        finally:
            wb.close()
    return sheets


def product_sheets(sheets):
    return [s for s in sheets if is_product_sheet(s.name)]


# ----------------------------------------------------------------------------
# Ghi thành phần vào sheet 4 (sửa trực tiếp XML)
# ----------------------------------------------------------------------------
def _col_index(letters):
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n


def _append_items(xml, tag, items):
    m = re.search(r'<%s count="(\d+)"([^>]*)>' % tag, xml)
    if not m:
        raise ValueError("styles.xml không có thẻ <%s>" % tag)
    base = int(m.group(1))
    xml = xml[:m.start()] + '<%s count="%d"%s>' % (tag, base + len(items), m.group(2)) + xml[m.end():]
    end = xml.index("</%s>" % tag, m.start())
    return xml[:end] + "".join(items) + xml[end:], base


_BORDER = ('<border><left style="thin">%s</left><right style="thin">%s</right>'
           '<top style="thin"><color auto="1"/></top><bottom style="thin"><color auto="1"/></bottom>'
           '<diagonal/></border>')
_BLACK = '<color auto="1"/>'
_GREEN = '<color rgb="FF339966"/>'


def _add_ingredient_styles(styles_xml, ncols=4):
    """Thêm font Times New Roman 13, 3 kiểu viền (viền dọc bên trong màu xanh lá) và style ô cho cột A..D (hoặc A..E khi
    ncols=5, như DungGop). Chỉ THÊM vào cuối nên không ảnh hưởng style hiện có."""
    styles_xml, font_id = _append_items(
        styles_xml, "fonts",
        ['<font><sz val="13"/><color theme="1"/><name val="Times New Roman"/><family val="1"/></font>'])
    styles_xml, b0 = _append_items(styles_xml, "borders", [
        _BORDER % (_BLACK, _GREEN),     # cột A: trái đen, phải xanh
        _BORDER % (_GREEN, _GREEN),     # cột B, C
        _BORDER % (_GREEN, _BLACK),     # cột D: trái xanh, phải đen
    ])
    center = '<alignment horizontal="center" vertical="center"/>'
    left = '<alignment vertical="center"/>'

    def xf(border, align):
        return ('<xf numFmtId="0" fontId="%d" fillId="0" borderId="%d" xfId="0" applyFont="1" '
                'applyBorder="1" applyAlignment="1">%s</xf>' % (font_id, border, align))

    if ncols >= 5:                       # A trái đen/phải xanh; B..D xanh hai bên; E trái xanh/phải đen
        styles_xml, x0 = _append_items(styles_xml, "cellXfs", [
            xf(b0, center), xf(b0 + 1, left), xf(b0 + 1, center), xf(b0 + 1, center), xf(b0 + 2, center)])
        return styles_xml, {"A": x0, "B": x0 + 1, "C": x0 + 2, "D": x0 + 3, "E": x0 + 4}
    styles_xml, x0 = _append_items(styles_xml, "cellXfs", [
        xf(b0, center), xf(b0 + 1, left), xf(b0 + 1, center), xf(b0 + 2, center)])
    return styles_xml, {"A": x0, "B": x0 + 1, "C": x0 + 2, "D": x0 + 3}


def _cell_xml(ref, style, value):
    s = ' s="%d"' % style
    if value is None or value == "":
        return '<c r="%s"%s/>' % (ref, s)
    if isinstance(value, bool):
        return '<c r="%s"%s t="b"><v>%d</v></c>' % (ref, s, int(value))
    if isinstance(value, (datetime, date)):
        value = to_excel(value)
    if isinstance(value, (int, float)):
        if isinstance(value, float) and (value != value or value in (float("inf"), float("-inf"))):
            return '<c r="%s"%s/>' % (ref, s)
        return '<c r="%s"%s><v>%s</v></c>' % (ref, s, repr(value))
    txt = clean_text(value)
    if txt == "":
        return '<c r="%s"%s/>' % (ref, s)
    esc = txt.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return '<c r="%s"%s t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (ref, s, esc)


_ROW_RE = re.compile(r"<row\b([^>]*?)(?:/>|>(.*?)</row>)", re.S)
_CELL_RE = re.compile(r'<c\s+r="([A-Z]+)(\d+)"([^>]*?)(?:/>|>.*?</c>)', re.S)


COL_MIN_W = (5.0, 30.0, 20.0, 14.0, 18.0)     # DungGop.AutoFitIngredientTable: độ rộng tối thiểu / tối đa của A..E
COL_MAX_W = (8.0, 60.0, 25.0, 40.0, 45.0)
CLEAR_ROW_5COL = 5000                          # DungGop.MAX_CLEAR_ROW


def _autofit_widths(ingredients, ncols):
    """Ước lượng 'AutoFit' của Excel cho font Times New Roman 13 rồi kẹp trong [min, max] của DungGop."""
    widths = {}
    for c in range(ncols):
        longest = len(str(len(ingredients))) if c == 0 else 0
        if c > 0:
            for it in ingredients:
                v = it[c - 1] if c - 1 < len(it) else None
                if v is None:
                    continue
                t = clean_text(v if not isinstance(v, float) else repr(v))
                longest = max(longest, max((len(x) for x in t.split("\n")), default=0))
        w = longest * 1.18 + 2.0
        widths[c + 1] = round(max(COL_MIN_W[c], min(COL_MAX_W[c], w)), 2)
    return widths


def _set_col_widths(xml, widths):
    """Đặt độ rộng các cột (số thứ tự cột -> độ rộng) trong <cols>, giữ nguyên style của cột."""
    m = re.search(r"<cols>(.*?)</cols>", xml, re.S)
    cols = []
    if m:
        for cm in re.finditer(r"<col\b([^>]*?)/>", m.group(1)):
            cols.append(dict(re.findall(r'(\w+)="([^"]*)"', cm.group(1))))
    out = []
    for a in cols:
        lo, hi = int(a["min"]), int(a["max"])
        pieces, cur = [], lo
        for c in sorted(widths):
            if lo <= c <= hi:
                if cur < c:
                    pieces.append((cur, c - 1, None))
                pieces.append((c, c, widths[c]))
                cur = c + 1
        if not pieces:
            out.append(a)
            continue
        if cur <= hi:
            pieces.append((cur, hi, None))
        for l, h, w in pieces:
            b = dict(a)
            b["min"], b["max"] = str(l), str(h)
            if w is not None:
                b["width"], b["customWidth"] = "%.2f" % w, "1"
                b.pop("bestFit", None)
            out.append(b)
    covered = set()
    for b in out:
        covered.update(range(int(b["min"]), min(int(b["max"]), 60) + 1))
    for c, w in widths.items():
        if c not in covered:
            out.append({"min": str(c), "max": str(c), "width": "%.2f" % w, "customWidth": "1"})
    out.sort(key=lambda b: int(b["min"]))
    order = ("min", "max", "width", "style", "hidden", "bestFit", "customWidth", "phonetic", "outlineLevel", "collapsed")
    xml_cols = "<cols>" + "".join(
        "<col " + " ".join('%s="%s"' % (k, b[k]) for k in order if k in b) + "/>" for b in out) + "</cols>"
    if m:
        return xml[:m.start()] + xml_cols + xml[m.end():]
    sd = xml.index("<sheetData")
    return xml[:sd] + xml_cols + xml[sd:]


def _patch_sheet4(sheet_xml, ingredients, styles, first_row=ING_FIRST_ROW, ncols=4):
    m = re.search(r"<sheetData\s*/>|<sheetData>(.*?)</sheetData>", sheet_xml, re.S)
    if not m:
        raise ValueError("Sheet 4 không có <sheetData>")
    inner = m.group(1) or ""
    rows = {}
    for rm in _ROW_RE.finditer(inner):
        attrs, body = rm.group(1), rm.group(2) or ""
        num = int(re.search(r'\br="(\d+)"', attrs).group(1))
        cells = {}
        for cm in _CELL_RE.finditer(body):
            cells[cm.group(1)] = (cm.group(0), cm.group(3))
        rows[num] = [attrs, {c: v[0] for c, v in cells.items()}, {c: v[1] for c, v in cells.items()}]

    # 1. xóa nội dung A..D (A..E với 5 cột) từ dòng 5 đến 1000 / 5000 (giữ định dạng ô như ClearContents)
    letters_all = "ABCDE"[:ncols]
    clear_last = CLEAR_ROW_5COL if ncols >= 5 else ING_CLEAR_LAST_ROW
    for num, (attrs, cells, cattrs) in rows.items():
        if first_row <= num <= clear_last:
            for col in letters_all:
                if col in cells:
                    a = re.sub(r'\s+t="[^"]*"', "", cattrs[col])
                    cells[col] = '<c r="%s%d"%s/>' % (col, num, a)

    # 2. ghi thành phần
    for k, item in enumerate(ingredients, start=1):
        name, content, func = item[0], item[1], item[2]
        num = first_row - 1 + k
        if num not in rows:
            rows[num] = [' r="%d"' % num, {}, {}]
        vals = {"A": k, "B": name, "C": content, "D": func, "E": (item[3] if len(item) > 3 else None)}
        for col in letters_all:
            rows[num][1][col] = _cell_xml("%s%d" % (col, num), styles[col], vals[col])
        rows[num][0] = re.sub(r'\s+spans="[^"]*"', "", rows[num][0])

    # 3. ghép lại theo thứ tự dòng / cột
    out = []
    for num in sorted(rows):
        attrs, cells, _ = rows[num]
        if num >= first_row:
            attrs = re.sub(r'\s+spans="[^"]*"', "", attrs)
        body = "".join(cells[c] for c in sorted(cells, key=_col_index))
        out.append("<row%s>%s</row>" % (attrs, body) if body else "<row%s/>" % attrs)
    new_data = "<sheetData>%s</sheetData>" % "".join(out)
    xml = sheet_xml[:m.start()] + new_data + sheet_xml[m.end():]

    # 4. cập nhật <dimension>
    dm = re.search(r'<dimension ref="([A-Z]+)(\d+):([A-Z]+)(\d+)"\s*/>', xml)
    if dm:
        last_row = max(int(dm.group(4)), first_row - 1 + len(ingredients))
        last_col = max(_col_index(dm.group(3)), ncols)
        letters = ""
        n = last_col
        while n:
            n, rem = divmod(n - 1, 26)
            letters = chr(65 + rem) + letters
        xml = xml[:dm.start()] + '<dimension ref="%s%s:%s%d"/>' % (
            dm.group(1), dm.group(2), letters, last_row) + xml[dm.end():]
    return xml


def write_ingredients(path, ingredients, ncols=4):
    """Ghi danh sách thành phần [(tên, hàm lượng, ghi chú[, dạng/màu]), ...] vào sheet 4 của file `path`.
    ncols=5 (chế độ DungGop): thêm cột E 'Dạng hoặc màu', kẻ khung A:E và tự giãn độ rộng cột A:E."""
    with zipfile.ZipFile(path) as zin:
        sheet_path = sheet_path_by_index(zin, ING_SHEET_INDEX)
        sheet_xml = zin.read(sheet_path).decode("utf-8")
        styles_xml = zin.read("xl/styles.xml").decode("utf-8")
        styles_xml, styles = _add_ingredient_styles(styles_xml, ncols)
        sheet_xml = _patch_sheet4(sheet_xml, ingredients, styles, ncols=ncols)
        if ncols >= 5 and ingredients:
            sheet_xml = _set_col_widths(sheet_xml, _autofit_widths(ingredients, ncols))
        ET.fromstring(sheet_xml.encode("utf-8"))
        ET.fromstring(styles_xml.encode("utf-8"))

        fd, tmp = tempfile.mkstemp(suffix=".xlsx", dir=os.path.dirname(path) or ".")
        os.close(fd)
        try:
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
                for item in zin.infolist():
                    if item.filename == sheet_path:
                        data = sheet_xml.encode("utf-8")
                    elif item.filename == "xl/styles.xml":
                        data = styles_xml.encode("utf-8")
                    else:
                        data = zin.read(item.filename)
                    zout.writestr(item, data)
        except Exception:
            os.remove(tmp)
            raise
    os.replace(tmp, path)


# ----------------------------------------------------------------------------
# Dựng file
# ----------------------------------------------------------------------------
MODE_EACH, MODE_MERGE, MODE_GROUP = "each", "merge", "group"


class Options:
    def __init__(self, fill_name=True, fill_ingredients=True, fill_congdung=True,
                 fill_checks=True, no_overwrite=True, mode=MODE_EACH, brand="",
                 group_name="", default_congdung="", only_restricted_pct=False, single_as_each=True,
                 info_by_sheet=None, info_label_by_sheet=None, external_congdung=None,
                 fill_notes=True, note_index=None):
        self.fill_notes = fill_notes          # điền ghi chú (cột D sheet 4) theo bảng ghi chú cho ô cột E của BTP còn trống
        self.note_index = note_index          # None = dùng bảng ghi chú đã lưu của người dùng
        self.fill_name = fill_name
        self.fill_ingredients = fill_ingredients
        self.fill_congdung = fill_congdung
        self.fill_checks = fill_checks
        self.no_overwrite = no_overwrite
        self.mode = mode                      # each | merge | group
        self.brand = brand                    # chế độ group: nhãn hàng (B2) + tên gốc file
        self.group_name = group_name          # chế độ group: tên sản phẩm chung (I2)
        self.default_congdung = default_congdung   # dùng khi không khớp được công dụng
        self.only_restricted_pct = only_restricted_pct   # chỉ giữ % cho chất giới hạn/cấm/chưa xác định
        self.single_as_each = single_as_each      # chế độ gộp nhóm: sheet không có sheet cùng thành phần -> dựng riêng
        self.external_congdung = external_congdung or []   # [(tên SP, công dụng)] từ file ngoài; có thì dò trước, không khớp mới dùng quy tắc tích hợp
        self.info_by_sheet = info_by_sheet or {}          # {tên sheet: {khóa trường info: giá trị}} - info theo nhóm (None/{} = không điền)
        self.info_label_by_sheet = info_label_by_sheet or {}   # {tên sheet: tên nhóm info} chỉ để báo trong nhật ký


class Result:
    def __init__(self, sheet):
        self.sheet = sheet
        self.path = ""
        self.product = ""
        self.congdung_key = ""
        self.congdung_score = 0.0
        self.congdung_default = False
        self.congdung_src = ""    # 'file' = từ file công dụng ngoài, 'rules' = quy tắc tích hợp
        self.ticked = []        # các ô I.. được tích "Có" theo từ khóa
        self.n_ingredients = 0
        self.members = []       # tên các sheet được dựng vào file này
        self.info_label = ""    # tên nhóm info đã áp dụng ('' = không điền info)
        self.info_cells = 0     # số ô info đã ghi
        self.notes_filled = 0   # số ô ghi chú (cột D sheet 4) điền theo Bảng Ghi chú
        self.check_reasons = [] # lý do tích Có theo thành phần / ghi chú (ghi nhật ký)
        self.warnings = []
        self.error = ""


def check_template(path):
    """Kiểm tra template: mở được, có >= 4 sheet. Trả về dict giá trị gốc các ô I và B32."""
    with zipfile.ZipFile(path) as z:
        sheet_path_by_index(z, ING_SHEET_INDEX)      # báo lỗi nếu thiếu sheet
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            ws = wb.worksheets[0]
            raw = {}
            for r, row in enumerate(ws.iter_rows(min_row=1, max_row=38, min_col=1, max_col=9,
                                                 values_only=True), start=1):
                row = tuple(row) + (None,) * (9 - len(row))
                raw[r] = row
        finally:
            wb.close()
    info = {"I": {}, "B32": clean_text(raw.get(CONGDUNG_ROW, (None,) * 9)[1])}
    for r in range(CHECK_FIRST, 38):
        v = raw.get(r, (None,) * 9)[8]
        info["I"][r] = clean_text(v).strip() if v is not None else ""
    # mục "Dạng trình bày": dòng 'Dạng đơn lẻ' và 'Một nhóm các màu' (tìm theo nhãn ở cột B; mặc định 33 / 34)
    pres = {"single": 33, "group": 34}
    for r in range(33, 38):
        lab = _unaccent(clean_text(raw.get(r, (None,) * 9)[1])).upper()
        if "NHOM CAC MAU" in lab or "RANGE OF COLOUR" in lab or "RANGE OF COLOR" in lab:
            pres["group"] = r
        elif "DON LE" in lab or "SINGLE PRODUCT" in lab:
            pres["single"] = r
    info["PRES"] = pres
    return info


def unique_path(folder, base, ext=".xlsx", enabled=True):
    path = os.path.join(folder, base + ext)
    if not enabled:
        return path
    n = 1
    while os.path.exists(path):
        n += 1
        path = os.path.join(folder, "%s (%d)%s" % (base, n, ext))
    return path


def _parse_cell_row(ref):
    m = re.fullmatch(r"\s*[Ii](\d+)\s*", ref or "")
    return int(m.group(1)) if m else None


YES_TEXT = "Có"
CI_RE = re.compile(r"(?<![A-Z0-9])CI\s*\d")
MAX_VARIANTS_LEN = 500       # giới hạn ô B3 (Danh sách dạng/màu) trong form


def safe_num(v):
    """Giống SafeCDbl: đổi 'a,b' thành số; không phải số -> None."""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    t = clean_text(v).strip().replace(",", ".")
    if not t:
        return None
    try:
        return float(t)
    except ValueError:
        return None


def merge_ingredients(sheets):
    """Gộp thành phần của nhiều sheet (Dung_Custom): trùng tên (không phân biệt hoa/thường)
    thì cộng dồn hàm lượng, giữ thứ tự xuất hiện đầu tiên và ghi chú ở lần đầu.
    Khác macro: thành phần không có số nào ở mọi sheet thì để trống thay vì ghi 0."""
    od = {}
    for sh in sheets:
        for c, d, e in sh.ingredients:
            name = clean_text(c).strip()
            if not name:
                continue
            val = safe_num(d)
            key = name.casefold()
            if key in od:
                if val is not None:
                    od[key][1] = (od[key][1] or 0.0) + val
            else:
                od[key] = [name, val, clean_text(e).strip()]
    return [(n, round(v, 10) if v is not None else None, f) for n, v, f in od.values()]


_UNUSED_GOPSANPHAM_NOTE = """Phiên bản trước dùng dấu vân tay của GopSanPham; DungGop dùng logic gop_2 (xem group_signature)."""
# (cũ) macro GopSanPham: xóa tên màu + CI (kể cả phần chữ đứng trước "(CI 77891)"), chữ thường, '-' và '/' thành
# khoảng trắng, chỉ giữ a-z 0-9 và khoảng trắng; mỗi tên chỉ tính một lần; sắp xếp rồi nối bằng '|'.
# KHÁC macro một điểm: phần chữ đứng trước "(CI ...)" được phép chứa chữ số, để xóa luôn cả tên màu như "YELLOW 6 LAKE(CI 15985)"
# và "BLUE 1 LAKE(CI 42090)" (macro gốc chỉ xóa "LAKE(CI ...)" nên còn sót "yellow 6", "blue 1" làm các sheet chỉ khác màu bị tách nhóm).
_GOP_CI = re.compile(r"([a-zA-Z0-9\s]+)?\(?\s*CI\s?\d+(\s?\([^)]+\))?\)?", re.I)
_GOP_CLEAN = re.compile(r"[^a-z0-9 ]")


def _gop_clean(raw):
    s = _GOP_CI.sub("", clean_text(raw))
    s = s.lower().replace("\xa0", " ").replace("-", " ").replace("/", " ")
    s = _GOP_CLEAN.sub("", s)
    return " ".join(s.split())


def group_signature(sheet):
    """DungGop.GetFingerprint (logic gop_2): đọc cột C (nguyên văn, bỏ khoảng trắng đầu cuối), BỎ dòng có 'CI ' hoặc '(CI'
    (chất tạo màu), IN HOA, sắp xếp (giữ cả tên trùng) rồi nối bằng '|'. Sheet không có thành phần nào -> '#single#<tên sheet>'
    (tự thành một nhóm riêng)."""
    names = []
    for r in sheet._data_rows():           # bỏ dòng chuỗi thành phần đầy đủ ('成份:WATER,...')
        v = r[2]
        txt = "" if v is None else str(v).strip()
        if txt:
            up = txt.upper()
            if "CI " not in up and "(CI" not in up:
                names.append(up)
    return "|".join(sorted(names)) if names else "#single#" + sheet.name


def shade_code(name):
    """Mã màu / dạng tách từ tên sản phẩm (macro gop_2): quét từ phải sang trái, lấy từ ký tự đứng ngay trước cụm chữ số
    cuối cùng tới hết chuỗi. Vd '3. hince RAW GLOW GEL TINT R039 ROSELLE' -> 'R039 ROSELLE'.
    Khác macro một điểm: số thập phân như '7.4' được giữ nguyên ('7.4' thay vì '.4')."""
    name = clean_text(name).strip()
    found, start = False, 0
    for k in range(len(name), 0, -1):
        ch = name[k - 1]
        if "0" <= ch <= "9":
            found = True
        elif found and ch in ".," and k > 1 and "0" <= name[k - 2] <= "9":
            continue                    # số thập phân (7.4, 10,1): giữ nguyên cả số (macro gốc chỉ lấy '.4')
        elif found:
            start = k
            break
    if found and start == 0:
        start = 1
    return name[start - 1:].strip() if start > 0 else ""


def group_sheets(sheets):
    """Nhóm các sheet có cùng thành phần (không tính chất tạo màu). Giữ thứ tự xuất hiện."""
    groups = {}
    for sh in sheets:
        groups.setdefault(group_signature(sh), []).append(sh)
    return list(groups.values())


def _all_data_text(prod, b32, ingredients):
    hay = [prod.lower(), b32.lower()]
    for item in ingredients:
        name = item[0]
        hay.append(clean_text(name).lower() if name is not None else "")
    return " | ".join(hay)


def _extra_rules():
    import builtin_rules as br
    comp = lambda lst: [(_parse_cell_row(c), re.compile(p, re.I)) for c, p in lst]
    conv = lambda lst: [(_parse_cell_row(c), [_parse_cell_row(x) for x in xs]) for c, xs in lst]
    return (comp(getattr(br, "NOTE_CHECKS", [])),
            conv(getattr(br, "PARENT_CHECKS", [])), conv(getattr(br, "EXCLUDE_IF", [])))


def _apply_extra_checks(final, res, ingredients):
    """Bổ sung sau khi tích theo từ khóa:
       1) tích theo DANH SÁCH THÀNH PHẦN (loai_sp.infer: chất chỉ được phép trong một loại sản phẩm theo
          ASEAN Annex III + danh sách chất đặc trưng, vd p-Phenylenediamine -> I14 nhuộm tóc,
          Thioglycolic acid -> I15 uốn tóc, Sodium fluoride -> I23 răng miệng) và theo ghi chú thành phần
          (vd 'Hair colorant' -> I14);
       2) bỏ tích ô loại trừ (vd I4 'Kem dùng trên da' khi SP là thuốc nhuộm / uốn tóc) - chỉ bỏ ô
          do app tự tích, không đụng ô template đã để sẵn 'Có';
       3) có ô con thì tích ô nhóm cha (I14..I19 -> I13 'Sản phẩm chăm sóc tóc')."""
    note_rules, parents, excludes = _extra_rules()

    def tick(row):
        if row in final:
            final[row] = True
            if row not in res.ticked:
                res.ticked.append(row)

    try:
        import loai_sp
        rows, why = loai_sp.infer(ingredients)
    except Exception as ex:
        rows, why = set(), []
        res.warnings.append("Không suy được loại sản phẩm từ thành phần: %s" % ex)
    for row in sorted(rows):
        tick(row)
    res.check_reasons.extend(why)
    for item in ingredients:
        note = clean_text(item[2]) if len(item) > 2 and item[2] is not None else ""
        for row, rx in note_rules:
            if note and rx.search(note):
                if row not in res.ticked:
                    res.check_reasons.append("I%d theo ghi chú '%s' của %s" % (row, note, clean_text(item[0])))
                tick(row)
    for row, triggers in excludes:
        if row in res.ticked and any(final.get(t) for t in triggers):
            final[row] = False
            res.ticked.remove(row)
    for row, kids in parents:
        if any(final.get(k) for k in kids):
            tick(row)


def build_core(label, prod, pairs, ingredients, base_name, template_path, template_info,
               out_dir, rules, opts, extra=None, members=None, ncols=4):
    """Dựng 1 file kết quả. pairs: [(tên SP, tên sheet)] dùng để khớp công dụng;
    ingredients: [(tên, hàm lượng, ghi chú)]; extra: {ô sheet 1: nội dung} ghi thêm."""
    res = Result(label)
    res.product = prod
    res.members = list(members or [label])
    res.n_ingredients = len(ingredients)
    changes = {}

    if opts.fill_name:
        changes["I2"] = prod
    for ref, val in (extra or {}).items():
        changes[ref] = val

    b32 = template_info["B32"]
    if opts.fill_congdung:
        val, key, score = "", "", 0.0
        if getattr(opts, "external_congdung", None):
            names = [prod] + [p for pr, sn in pairs for p in (pr, sn)]
            val, key, score = match_external_congdung(names, opts.external_congdung)
            if key:
                res.congdung_src = "file"
            else:
                res.warnings.append("Không thấy '%s' trong file công dụng ngoài (điểm cao nhất %.2f) - dùng quy tắc tích hợp" % (prod, score))
        if not key:
            val, key, score2 = match_congdung_multi(pairs, rules.congdung)
            score = score2 if key else max(score, score2)
            if key:
                res.congdung_src = "rules"
        res.congdung_key, res.congdung_score = key, score
        if not key and opts.default_congdung:
            val, res.congdung_default = opts.default_congdung, True
        b32 = val
        changes[CONGDUNG_ROW] = val

    res.notes_filled = 0   # điền ghi chú trước để bước tích Có/Không dùng được ghi chú (vd 'Hair colorant')
    if opts.fill_ingredients and getattr(opts, "fill_notes", True):
        import note_engine
        idx = opts.note_index if getattr(opts, "note_index", None) is not None else note_engine.get_index()
        if len(idx):
            ingredients, res.notes_filled = note_engine.fill_notes(ingredients, idx)

    if opts.fill_checks:
        raw = template_info["I"]
        final = {r: (raw.get(r, "") == YES_TEXT) for r in range(CHECK_FIRST, CHECK_LAST + 1)}
        all_data = _all_data_text(prod, b32, ingredients)
        for cell, kwlist in rules.checks:
            row = _parse_cell_row(cell)
            if row is None or row not in CHECK_ROWS:
                res.warnings.append("Quy tắc bỏ qua (ô '%s' không phải ô Có/Không)" % cell)
                continue
            for kw in kwlist.split(","):
                kw = kw.strip().lower()
                if kw and kw in all_data:
                    final[row] = True
                    if row not in res.ticked:
                        res.ticked.append(row)
                    break
        _apply_extra_checks(final, res, ingredients)
        for r in range(CHECK_FIRST, CHECK_LAST + 1):
            if raw.get(r, "") == "" or final[r] != (raw.get(r, "") == YES_TEXT):
                changes[r] = final[r]
        for r in res.ticked:
            if r > CHECK_LAST:
                changes[r] = True

    if getattr(opts, "only_restricted_pct", False):
        import reg_engine
        ingredients = [(it[0], it[1] if reg_engine.needs_pct(clean_text(it[0])) else None) + tuple(it[2:]) for it in ingredients]

    max_base = max(20, 240 - len(os.path.join(out_dir, "")) - 12)
    final_path = unique_path(out_dir, base_name[:max_base].rstrip(), enabled=opts.no_overwrite)

    fd, tmp = tempfile.mkstemp(suffix=".xlsx", dir=out_dir)
    os.close(fd)
    try:
        shutil.copyfile(template_path, tmp)
        if changes:
            write_changes(tmp, changes, max_len=None)
        if opts.fill_ingredients:
            write_ingredients(tmp, ingredients, ncols=ncols)
        _apply_group_info(tmp, res, opts)
        os.replace(tmp, final_path)
    except Exception:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise
    res.path = final_path
    return res


INFO_SRC_GOP, INFO_SRC_COLOR = "gop", "color"


def info_groups(sheets, source=INFO_SRC_GOP):
    """Chia các sheet đã chọn thành nhóm để mỗi nhóm có một bảng info riêng.
    source 'gop'  : theo nhóm gộp (cùng bộ thành phần, như 'Gộp theo nhóm'); sheet không có sheet cùng thành phần
                    dồn chung nhóm 'Sheet riêng'.
    source 'color': theo màu tab sheet trong file BTP (macro gop tô cùng màu cho cùng nhóm); sheet không tô màu dồn chung
                    nhóm 'Không màu'.
    Trả về list dict {gid, label, members:[tên sheet], color:'#RRGGBB' hoặc ''}; gid ổn định để lưu bảng info."""
    out = []
    if source == INFO_SRC_COLOR:
        by = {}
        for sh in sheets:
            by.setdefault(getattr(sh, "tab_color", "") or "", []).append(sh)
        seq = 0
        none = None
        for key, mem in by.items():
            if not key:
                none = {"gid": "none", "label": "Không màu", "members": [m.name for m in mem], "color": ""}
                continue
            seq += 1
            out.append({"gid": "color:" + key, "label": "Màu %d" % seq, "members": [m.name for m in mem],
                        "color": tab_color_hex(key)})
        if none:
            out.append(none)
        return out
    seq, singles = 0, []
    for grp in group_sheets(sheets):
        if len(grp) == 1:
            singles.append(grp[0].name)
            continue
        seq += 1
        out.append({"gid": "N%d" % seq, "label": "N%d" % seq, "members": [m.name for m in grp], "color": ""})
    if singles:
        out.append({"gid": "single", "label": "Sheet riêng", "members": singles, "color": ""})
    return out


def _apply_group_info(path, res, opts):
    """Điền info của nhóm (công ty, nhà sản xuất, đơn vị đóng gói...) cho file vừa dựng.
    Nhóm lấy theo sheet đầu tiên của file; file gộp nhiều nhóm info khác nhau -> báo cảnh báo."""
    table = getattr(opts, "info_by_sheet", None)
    if not table:
        return
    import info_engine
    first = res.members[0] if res.members else res.sheet
    vals = info_engine.clean_values(table.get(first) or {})
    labels = {opts.info_label_by_sheet.get(m, "") for m in res.members}
    if len(labels) > 1:
        res.warnings.append("File gộp sheet thuộc %d nhóm info khác nhau (%s) - dùng info của nhóm '%s'" % (
            len(labels), ", ".join(sorted(x for x in labels if x)), opts.info_label_by_sheet.get(first, "")))
    if not vals:
        res.warnings.append("Nhóm info '%s' chưa nhập thông tin nào - bỏ qua phần Info" % opts.info_label_by_sheet.get(first, ""))
        return
    try:
        n, notes = info_engine.update_file(path, vals, make_backup=False)
    except Exception as ex:
        res.warnings.append("Không điền được info: %s" % ex)
        return
    res.info_label = opts.info_label_by_sheet.get(first, "")
    res.info_cells = n
    for w in info_engine.validate(vals) + notes:
        res.warnings.append("Info: " + w)


def build_one(sheet, template_path, template_info, out_dir, rules, opts):
    """Chế độ 'mỗi sheet một file'."""
    prod = sheet.product
    base = "%s - %s" % (sheet.name, safe_file_part(prod))
    return build_core(sheet.name, prod, [(prod, sheet.name)], sheet.ingredients, base,
                      template_path, template_info, out_dir, rules, opts)


def build_merge(sheets, template_path, template_info, out_dir, rules, opts):
    """Chế độ 'gộp các sheet đã chọn thành MỘT file' (Dung_Custom)."""
    joined = safe_file_part("_".join(s.name for s in sheets))
    prods = []
    for sh in sheets:
        p = sh.product
        if p and p.casefold() not in " - ".join(prods).casefold():
            prods.append(p)
    prod = " - ".join(prods)
    base = "%s - %s" % (joined, safe_file_part(prod) or "KetQuaGop")
    if len(os.path.join(out_dir, base + ".xlsx")) > 240:
        base = "Gop_Excel_" + datetime.now().strftime("%y%m%d_%H%M%S")
    res = build_core(joined, prod, [(sh.product, sh.name) for sh in sheets], merge_ingredients(sheets),
                     base, template_path, template_info, out_dir, rules, opts,
                     members=[sh.name for sh in sheets])
    return res


def sheet_list_text(names, max_len=60):
    """Liệt kê tên các sheet gộp, cách nhau dấu phẩy không khoảng trắng: ['1','2','10','22'] -> '1,2,10,22'.
    Danh sách quá dài (> max_len ký tự) thì gộp các dãy số liên tiếp từ 3 sheet trở lên thành 'a-b' ('1,2,3,4,10' -> '1-4,10')
    để tên file không vượt giới hạn đường dẫn của Windows."""
    names = [str(n).strip() for n in names]
    full = ",".join(names)
    if len(full) <= max_len:
        return full
    out, i = [], 0
    while i < len(names):
        j = i
        if names[i].isdigit():
            while j + 1 < len(names) and names[j + 1].isdigit() and int(names[j + 1]) == int(names[j]) + 1:
                j += 1
        if j - i >= 2:
            out.append("%s-%s" % (names[i], names[j]))
        else:
            out.extend(names[i:j + 1])
        i = j + 1
    return ",".join(out)


def build_group(members, template_path, template_info, out_dir, rules, opts):
    """Một nhóm sheet cùng bộ thành phần -> 1 file, đúng logic macro DungGop:
      - Tên sản phẩm (I2) lấy từ sheet đầu nhóm, đã bỏ số thứ tự; nhóm gộp thì BỎ luôn phần mã màu ở cuối tên.
      - Sheet 4: thành phần của từng sheet nối tiếp nhau (STT liên tục); B = tên, C = hàm lượng, D = ghi chú (cột E của BTP);
        nhóm gộp: cột E 'Dạng hoặc màu' = mã màu của từng sheet; bảng kẻ khung A:E, cột tự giãn.
      - Ô B3 (nhóm gộp) = danh sách mã màu các sheet, cách nhau ', '.
      - Tên file: nhóm gộp 'Gop <liệt kê các sheet: 1,2,10,22> - <tên>', sheet đơn lẻ '<sheet> - <tên>'.
    """
    merged = len(members) >= 2
    first = members[0]
    prod_clean = clean_product_name(first.product_raw) or first.name
    base = prod_clean
    if merged:
        fs = extract_shade(first.product_raw)
        if fs and len(prod_clean) > len(fs) and prod_clean.endswith(fs):
            base = prod_clean[:-len(fs)].strip()
        if not base:
            base = prod_clean

    rows, shade_list = [], ""
    for sh in members:
        shade = extract_shade(sh.product_raw) if merged else ""
        for n, c, e in sh.ingredients:
            rows.append((n, c, e, shade) if merged else (n, c, e))
        if merged:
            if shade_list != "":
                shade_list += ", "
            shade_list += shade
    extra = {"B3": shade_list} if merged else {}
    if merged:                                       # nhiều màu/dạng trong một hồ sơ -> "Một nhóm các màu", không phải "Dạng đơn lẻ"
        pres = template_info.get("PRES", {"single": 33, "group": 34})
        extra[pres["single"]] = False
        extra[pres["group"]] = True

    safe = safe_file_part(base)
    if merged:
        prefix = "Gop %s - " % sheet_list_text([m.name for m in members])
        file_base = prefix + safe[:max(10, 120 - len(prefix))]          # cắt phần tên, không cắt danh sách sheet
    else:
        file_base = ("%s - %s" % (first.name, safe))[:120]
    file_base = file_base.rstrip()

    label = ("Gộp %s" % sheet_list_text([m.name for m in members], 40)) if merged else first.name
    res = build_core(label, base, [(sh.product, sh.name) for sh in members], rows, file_base, template_path, template_info,
                     out_dir, rules, opts, extra=extra, members=[sh.name for sh in members], ncols=5)
    if merged and len(shade_list) > MAX_VARIANTS_LEN:
        res.warnings.append("Danh sách dạng/màu (B3) dài %d ký tự, vượt giới hạn %d của form" % (len(shade_list), MAX_VARIANTS_LEN))
    if merged and not any(extract_shade(sh.product_raw) for sh in members):
        res.warnings.append("Không tách được mã màu từ tên sản phẩm (không có từ nào chứa chữ số) nên B3 và cột E để trống")
    return res


def build_all(sheets, template_path, out_dir, rules, opts, progress=None):
    """Dựng file theo chế độ opts.mode. progress(i, n, tên) gọi trước mỗi file.
    Một file lỗi không làm dừng cả lô."""
    info = check_template(template_path)
    os.makedirs(out_dir, exist_ok=True)
    mode = getattr(opts, "mode", MODE_EACH)
    if mode == MODE_MERGE:
        units = [("%d sheet" % len(sheets), sheets, lambda: build_merge(
            sheets, template_path, info, out_dir, rules, opts))] if sheets else []
    elif mode == MODE_GROUP:
        units = []
        for grp in group_sheets(sheets):
            label = ("Gộp %s" % sheet_list_text([m.name for m in grp], 40)) if len(grp) > 1 else grp[0].name
            units.append((label, grp, lambda grp=grp: build_group(grp, template_path, info, out_dir, rules, opts)))
    else:
        units = [(sh.name, [sh], lambda sh=sh: build_one(sh, template_path, info, out_dir, rules, opts))
                 for sh in sheets]
    results = []
    for i, (label, members, fn) in enumerate(units, start=1):
        if progress:
            progress(i, len(units), label)
        try:
            results.append(fn())
        except Exception as ex:
            r = Result(label)
            r.product = members[0].product
            r.members = [m.name for m in members]
            r.error = str(ex)
            results.append(r)
    return results


# ----------------------------------------------------------------------------
# Lưu cấu hình (đường dẫn gần nhất)
# ----------------------------------------------------------------------------
def settings_dir():
    d = os.path.join(os.path.expanduser("~"), ".app_dung")
    os.makedirs(d, exist_ok=True)
    return d


def load_settings():
    try:
        with open(os.path.join(settings_dir(), "settings.json"), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_settings(data):
    try:
        with open(os.path.join(settings_dir(), "settings.json"), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def builtin_rules():
    """Quy tắc tích hợp sẵn trong app (builtin_rules.py) - người dùng không phải nạp."""
    import builtin_rules as br
    return Rules(br.CONGDUNG, br.CHECKS, "tích hợp sẵn")
