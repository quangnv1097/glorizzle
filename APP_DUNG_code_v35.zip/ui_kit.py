# -*- coding: utf-8 -*-
"""Thành phần giao diện dùng chung."""
import tkinter as tk
from tkinter import ttk

PRIMARY_BG = "#CFE3FA"          # nền xanh dương nhạt
PRIMARY_HOVER = "#B5D3F5"
PRIMARY_FG = "#0F3A6B"          # chữ xanh đậm
PRIMARY_EDGE = "#7FAEE0"
DISABLED_BG = "#E9EEF4"
DISABLED_FG = "#97A3B3"
DISABLED_EDGE = "#D3DAE3"


class PrimaryButton(tk.Button):
    """Nút hành động chính: chữ đậm, nền xanh dương nhạt, viền xanh, đổi màu khi rê chuột, tự xám khi bị vô hiệu hóa.
    Dùng giống tk.Button: .config(state='disabled'/'normal')."""

    def __init__(self, master, text, command=None, width=None, font_size=11, state="normal", **kw):
        super().__init__(master, text=text, command=command, cursor="hand2", relief="solid", bd=1,
                         font=("Segoe UI", font_size, "bold"), padx=22, pady=7, **({"width": width} if width else {}), **kw)
        self._state = "normal"
        self.bind("<Enter>", lambda e: self._hover(True))
        self.bind("<Leave>", lambda e: self._hover(False))
        self._paint(state)

    def _paint(self, state):
        self._state = state
        if state == "disabled":
            super().config(state="disabled", bg=DISABLED_BG, fg=DISABLED_FG, activebackground=DISABLED_BG,
                           activeforeground=DISABLED_FG, disabledforeground=DISABLED_FG, highlightbackground=DISABLED_EDGE,
                           highlightcolor=DISABLED_EDGE, highlightthickness=1, cursor="arrow")
        else:
            super().config(state="normal", bg=PRIMARY_BG, fg=PRIMARY_FG, activebackground=PRIMARY_HOVER,
                           activeforeground=PRIMARY_FG, highlightbackground=PRIMARY_EDGE, highlightcolor=PRIMARY_EDGE,
                           highlightthickness=1, cursor="hand2")

    def _hover(self, on):
        if self._state == "normal":
            super().config(bg=PRIMARY_HOVER if on else PRIMARY_BG)

    def config(self, cnf=None, **kw):                       # noqa: A003 - cho phép .config(state=...)
        if "state" in kw and not cnf:
            self._paint(kw.pop("state"))
            if not kw:
                return None
        return super().config(cnf, **kw) if cnf else super().config(**kw)

    configure = config


class ScrollFrame(ttk.Frame):
    """Khung có thanh cuộn dọc. Đặt nội dung vào `.inner`. Lăn chuột cuộn cả trang, trừ khi con trỏ đang ở trên bảng
    (Treeview) hoặc ô văn bản (Text) - các ô này tự cuộn. bg: màu nền (nếu muốn dùng nền riêng, vd màn hình chính)."""

    def __init__(self, master, bg=None):
        super().__init__(master)
        kw = {"bg": bg} if bg else {}
        self.canvas = tk.Canvas(self, highlightthickness=0, borderwidth=0, yscrollincrement=24, **kw)
        self.vbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vbar.set)
        self.vbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner = tk.Frame(self.canvas, **kw) if bg else ttk.Frame(self.canvas)
        self._win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", self._on_canvas)
        self.winfo_toplevel().bind("<MouseWheel>", self._wheel, add="+")
        self.winfo_toplevel().bind("<Button-4>", lambda e: self._wheel(e, 1), add="+")
        self.winfo_toplevel().bind("<Button-5>", lambda e: self._wheel(e, -1), add="+")
        self.on_width = None

    def _on_canvas(self, e):
        self.canvas.itemconfigure(self._win, width=e.width)
        if self.on_width:
            self.on_width(e.width)

    def _inside(self, w):
        while w is not None:
            if w is self:
                return True
            w = getattr(w, "master", None)
        return False

    def _wheel(self, e, direction=None):
        try:
            w = self.winfo_containing(e.x_root, e.y_root)
        except Exception:
            return
        if w is None or not self._inside(w) or isinstance(w, (ttk.Treeview, tk.Text)):
            return
        if self.inner.winfo_reqheight() <= self.canvas.winfo_height():
            return
        d = direction if direction is not None else (1 if getattr(e, "delta", 0) > 0 else -1)
        self.canvas.yview_scroll(-d * 2, "units")
