# -*- coding: utf-8 -*-
"""Kiểm tra ngưỡng hàm lượng - khung dùng chung, nhúng thẳng vào cửa sổ đọc file (Tạo BTP) và cửa sổ Dựng BTP.

  ThresholdPanel : bảng từng thành phần (màu theo trạng thái) + chi tiết + tỉ lệ trộn + xác nhận chất lạ + xuất báo cáo
  ThresholdDialog: cửa sổ nhỏ chứa ThresholdPanel cho một sản phẩm (mở bằng bấm đúp ở Dựng BTP)
  summary_text   : tóm tắt kết quả của một công thức, dùng cho cột "Ngưỡng" trong danh sách
"""
import os
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

import dung_engine as eng
import reg_engine as reg

COLORS = {"CAM": "#F8B4B4", "CAMDK": "#FAD0A8", "VUOT": "#F8B4B4", "THIEU": "#FAD0A8", "UNK": "#E5E7EB", "XEM": "#FFF1B8",
          "KT": "#FFF1B8", "GT": "#D6E6FA", "DAT": "#D7F0DD", "KGH": "#FFFFFF", "KGHS": "#EEF6EA"}
SHORT = {"CAM": "Cấm", "CAMDK": "Cấm có ĐK", "VUOT": "Vượt", "THIEU": "Thiếu %", "UNK": "Chưa xác định", "XEM": "Cần xem",
         "KT": "Kiểm tra tay", "GT": "Giải trình", "DAT": "Đạt", "KGH": "Không giới hạn", "KGHS": "Suy ra KGH"}


def summary_text(findings):
    """(chuỗi tóm tắt, mã: 'bad' | 'warn' | 'ok') cho một công thức."""
    s = reg.summarize(findings)
    bad = s.get("CAM", 0) + s.get("VUOT", 0) + s.get("THIEU", 0)
    parts = []
    for k, label in (("CAM", "cấm"), ("CAMDK", "cấm có ĐK"), ("VUOT", "vượt"), ("THIEU", "thiếu %"), ("UNK", "chưa xác định"),
                     ("XEM", "cần xem"), ("KT", "kiểm tra tay"), ("KGHS", "suy ra KGH")):
        if s.get(k):
            parts.append("%d %s" % (s[k], label))
    tag = "bad" if bad else ("warn" if (s.get("UNK") or s.get("XEM") or s.get("CAMDK") or s.get("KT")) else "ok")
    return (", ".join(parts) or "Đạt"), tag


def export_report(path, products):
    """products: list dict(name, source, findings)."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Tong hop"
    ws.append(["Sản phẩm", "Nguồn", "Cấm", "Cấm có ĐK", "Vượt ngưỡng", "Thiếu %", "Chưa xác định", "Cần xác nhận", "Kiểm tra tay",
               "Cần giải trình", "Đạt", "Suy ra KGH"])
    for p in products:
        s = reg.summarize(p["findings"])
        ws.append([p["name"], p.get("source", ""), s.get("CAM", 0), s.get("CAMDK", 0), s.get("VUOT", 0), s.get("THIEU", 0),
                   s.get("UNK", 0), s.get("XEM", 0), s.get("KT", 0), s.get("GT", 0), s.get("DAT", 0), s.get("KGHS", 0)])
    d = wb.create_sheet("Chi tiet")
    d.append(["Sản phẩm", "STT", "Thành phần", "% công thức", "% quy đổi", "Nhóm", "Trạng thái", "Ngưỡng rút ra",
              "Quy định (rút gọn)", "Nguồn", "Ghi chú"])
    for p in products:
        for k, f in enumerate(p["findings"], start=1):
            d.append([p["name"], k, f.name, f.pct, None if f.effective is None else round(f.effective, 6), f.group,
                      reg.STATUS_TEXT.get(f.status, f.status), ", ".join("%g%%" % v for v in f.limits),
                      (f.limit_text or "").replace("\n", " ")[:500], "; ".join(f.sources),
                      " | ".join(f.notes + ([f.conflict] if f.conflict else []))])
            fill = PatternFill("solid", fgColor=COLORS.get(f.status, "#FFFFFF").lstrip("#"))
            for c in d[d.max_row]:
                c.fill = fill
    for sh in (ws, d):
        for c in sh[1]:
            c.font = Font(bold=True)
            c.alignment = Alignment(wrap_text=True, vertical="center")
        sh.freeze_panes = "A2"
    for col, w in zip("ABCDEFGHIJK", (42, 30, 40, 12, 12, 8, 26, 24, 60, 28, 60)):
        d.column_dimensions[col].width = w
    ws.column_dimensions["A"].width = 46
    wb.save(path)


class ThresholdPanel(ttk.LabelFrame):
    """Khung kiểm tra ngưỡng. Dùng:  panel.show(tên, [(thành phần, %), ...])  hoặc  panel.show_message(văn bản)."""

    def __init__(self, master, settings, on_change=None, export_provider=None, tree_height=8, detail_height=4):
        super().__init__(master, text="Kiểm tra ngưỡng hàm lượng (Annex ASEAN)")
        self.settings = settings
        self.db = reg.get_db()
        self.on_change = on_change
        self.export_provider = export_provider      # trả về list dict(name, source, rows) cần xuất; None = sản phẩm đang xem
        self.mix_var = tk.StringVar(value=str(settings.get("reg_mix", "0")))
        self.hide_var = tk.BooleanVar(value=True)
        self.name, self.rows, self.findings = "", [], []

        bar = ttk.Frame(self)
        bar.pack(fill="x", padx=8, pady=(4, 0))
        ttk.Label(bar, text="Tỉ lệ trộn oxy hóa (phần oxy / 1 phần màu; 0 = không áp dụng):").pack(side="left")
        e = ttk.Entry(bar, textvariable=self.mix_var, width=5)
        e.pack(side="left", padx=4)
        e.bind("<Return>", lambda ev: self.apply_context())
        ttk.Button(bar, text="Áp dụng", command=self.apply_context).pack(side="left")
        ttk.Checkbutton(bar, text="Ẩn chất 'Không giới hạn'", variable=self.hide_var, command=self._redraw).pack(side="left", padx=12)
        ttk.Button(bar, text="Xuất báo cáo Excel…", command=self.export).pack(side="right")
        self.sum_label = ttk.Label(bar, text="")
        self.sum_label.pack(side="right", padx=10)

        holder = ttk.Frame(self)
        holder.pack(fill="both", expand=True, padx=8, pady=4)
        cols = ("stt", "ten", "pct", "tt", "nguong", "nguon")
        self.tree = ttk.Treeview(holder, columns=cols, show="headings", height=tree_height, selectmode="browse")
        for c, (h, w) in {"stt": ("STT", 40), "ten": ("Thành phần", 250), "pct": ("% công thức", 80), "tt": ("Trạng thái", 175),
                          "nguong": ("Ngưỡng / quy định (rút gọn)", 330), "nguon": ("Nguồn", 140)}.items():
            self.tree.heading(c, text=h)
            self.tree.column(c, width=w, anchor="center" if c in ("stt", "pct") else "w", stretch=c in ("nguong", "ten"))
        vs = ttk.Scrollbar(holder, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vs.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vs.pack(side="right", fill="y")
        for k, c in COLORS.items():
            self.tree.tag_configure(k, background=c)
        self.tree.bind("<<TreeviewSelect>>", self._show_detail)
        self.tree.bind("<Button-3>", self._menu)

        self.detail = tk.Text(self, height=detail_height, wrap="word", state="disabled", font=("Segoe UI", 9))
        self.detail.pack(fill="x", padx=8, pady=(0, 6))
        self.show_message("Chọn một bảng thành phần ở trên để xem kiểm tra ngưỡng.")

    # ------------------------------------------------------------ ngữ cảnh
    def context(self):
        try:
            r = float(str(self.mix_var.get()).replace(",", ".") or 0)
        except ValueError:
            r = 0.0
        return {"mix_ratio": max(r, 0.0)}

    def check(self, rows):
        return reg.check_formula(self.db, rows, self.context())

    def apply_context(self):
        self.settings["reg_mix"] = str(self.mix_var.get())
        eng.save_settings(self.settings)
        if self.rows:
            self.findings = self.check(self.rows)
            self._redraw()
        if self.on_change:
            self.on_change()

    # ------------------------------------------------------------ hiển thị
    def show(self, name, rows):
        self.name, self.rows = name, list(rows)
        self.findings = self.check(self.rows)
        self._redraw()

    def show_message(self, text):
        self.name, self.rows, self.findings = "", [], []
        self.tree.delete(*self.tree.get_children())
        self.sum_label.config(text="")
        self._set_detail(text)

    def _redraw(self):
        self.tree.delete(*self.tree.get_children())
        hide = self.hide_var.get()
        for k, f in enumerate(self.findings, start=1):
            if hide and f.status == "KGH":
                continue
            self.tree.insert("", "end", iid=str(k - 1), tags=(f.status,), values=(
                k, f.name[:60], (f.pct_text or ("" if f.pct is None else "%g" % f.pct))[:14],
                reg.STATUS_TEXT.get(f.status, f.status), (f.limit_text or "")[:90].replace("\n", " "),
                "; ".join(f.sources)[:40]))
        s = reg.summarize(self.findings)
        self.sum_label.config(text="  ".join("%s: %d" % (SHORT.get(k, k), v) for k, v in s.items() if v and k != "KGH"))

    def _set_detail(self, text):
        self.detail.configure(state="normal")
        self.detail.delete("1.0", "end")
        self.detail.insert("1.0", text)
        self.detail.configure(state="disabled")

    def _show_detail(self, _e=None):
        sel = self.tree.selection()
        if not sel or not self.findings:
            return
        f = self.findings[int(sel[0])]
        lines = ["%s — %s" % (f.name, reg.STATUS_TEXT.get(f.status, f.status))]
        if f.pct is not None:
            lines.append("Hàm lượng trong công thức: %g%%%s" % (
                f.pct, ("  →  quy đổi để so ngưỡng: %.5g%%" % f.effective) if f.effective is not None else ""))
        if f.limits:
            lines.append("Các ngưỡng rút ra: " + ", ".join("%g%%" % v for v in f.limits))
        if f.limit_text:
            lines.append("Quy định (nguyên văn rút gọn): " + f.limit_text.replace("\n", " ")[:400])
        if f.sources:
            lines.append("Nguồn: " + "; ".join(f.sources))
        if f.conflict:
            lines.append("Mâu thuẫn: " + f.conflict)
        lines += ["- " + n for n in f.notes]
        if f.status == "UNK":
            lines.append("Không thấy trong Annex và bảng của bạn. Nếu chắc chắn không giới hạn, bấm phải để xác nhận.")
        self._set_detail("\n".join(lines))

    # ------------------------------------------------------------ xác nhận chất lạ
    def _menu(self, e):
        iid = self.tree.identify_row(e.y)
        if not iid or not self.findings:
            return
        self.tree.selection_set(iid)
        f = self.findings[int(iid)]
        m = tk.Menu(self, tearoff=0)
        m.add_command(label="Xác nhận: KHÔNG GIỚI HẠN", command=lambda: self._confirm(f, "kgh"))
        m.add_command(label="Xác nhận: CẦN GIẢI TRÌNH", command=lambda: self._confirm(f, "GT"))
        m.add_command(label="Xác nhận: CẤM", command=lambda: self._confirm(f, "CẤM"))
        m.add_command(label="Xác nhận: CÓ GIỚI HẠN (nhập điều kiện)…", command=lambda: self._confirm(f, None))
        m.tk_popup(e.x_root, e.y_root)

    def _confirm(self, f, status):
        if status is None:
            status = simpledialog.askstring("Điều kiện giới hạn", "Nhập ngưỡng/điều kiện, ví dụ: <2%", parent=self)
            if not status:
                return
        reg.save_user_status(self.db, f.name, status)
        self.db.user = reg._load_json(os.path.join(reg._USER_DIR, "user_status.json"), {})
        self.apply_context()

    # ------------------------------------------------------------ xuất báo cáo
    def export(self):
        if self.export_provider:
            items = self.export_provider()
        else:
            items = [{"name": self.name, "source": "", "rows": self.rows}] if self.rows else []
        if not items:
            messagebox.showinfo("Xuất báo cáo", "Chưa có sản phẩm nào để xuất.", parent=self)
            return
        out = filedialog.asksaveasfilename(parent=self, title="Lưu báo cáo kiểm tra ngưỡng", defaultextension=".xlsx",
                                           initialfile="bao_cao_kiem_tra_nguong.xlsx", filetypes=[("Excel", "*.xlsx")])
        if not out:
            return
        products = [{"name": it["name"], "source": it.get("source", ""), "findings": self.check(it["rows"])} for it in items]
        try:
            export_report(out, products)
        except PermissionError:
            messagebox.showerror("Không ghi được", "Không ghi được file (đang mở trong Excel?).", parent=self)
            return
        messagebox.showinfo("Hoàn tất", "Đã lưu báo cáo (%d sản phẩm):\n%s" % (len(products), out), parent=self)


class ThresholdDialog(tk.Toplevel):
    """Cửa sổ chi tiết ngưỡng cho một sản phẩm (mở từ Dựng BTP bằng bấm đúp vào dòng sheet)."""

    def __init__(self, master, settings, name, rows, on_change=None):
        super().__init__(master)
        self.title("Kiểm tra ngưỡng - %s" % name[:70])
        self.geometry("1000x560")
        self.minsize(820, 440)
        self.panel = ThresholdPanel(self, settings, on_change=on_change, tree_height=12, detail_height=5)
        self.panel.pack(fill="both", expand=True, padx=10, pady=10)
        self.panel.show(name, rows)
