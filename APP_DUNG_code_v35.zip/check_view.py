# -*- coding: utf-8 -*-
"""Màn hình Check Có / Không (chỉnh hàng loạt Có/Không + ô văn bản cho nhiều file Excel)."""
import os
import shutil
import tkinter as tk
import re
from tkinter import filedialog, messagebox, simpledialog, ttk

from xlsx_core import (FORM_ROWS, SECTION_BEFORE, YES, NO, MAX_TEXT, clean_text,
                       read_form, write_changes)

COL_W = 170
ROW_H = 56           # dòng Có/Không
TEXT_H = 124         # dòng văn bản
SECTION_H = 30       # thanh tiêu đề nhóm
LABEL_W = 540
MIN_LABEL_W = 180
HEADER_H = 78
BOX = 22

C_PINK = "#F8C8D0"
C_GREEN = "#C6EFCE"
C_EDGE = "#B8B8B8"
C_MOD = "#F28C00"
C_HEAD = "#E6ECF5"
C_SECTION = "#CBD6EA"
C_TEXT_MOD = "#FFF1D0"


NAME_KEY = "I2"          # khóa trong states/orig của tên sản phẩm (ô I2 sheet 1)


def transform_name(name, find="", repl="", prefix="", suffix="", strip_num=False, ignore_case=True):
    """Biến đổi một tên sản phẩm: bỏ số thứ tự đầu tên -> tìm/thay -> thêm đầu / cuối -> gộp khoảng trắng."""
    out = name or ""
    if strip_num:
        import dung_engine
        out = dung_engine.clean_product_name(out) or out
    if find:
        out = re.sub(re.escape(find), lambda _m: repl, out, flags=re.I if ignore_case else 0)
    if prefix:
        out = prefix + out
    if suffix:
        out = out + suffix
    return " ".join(out.split())


def short(text, n):
    return text if len(text) <= n else text[: n - 1] + "…"


class CheckWindow(tk.Toplevel):
    def __init__(self, master=None, paths=None):
        super().__init__(master)
        self.title("Dựng mẫu – chỉnh hàng loạt thông tin sản phẩm")
        self.geometry("1280x740")
        self.minsize(800, 450)

        self.files = []        # list[dict]: path, name, orig{dòng:giá trị}, states{dòng:giá trị}
        self.labels = {}
        self.titles = {}
        self.layout = []
        self.total_h = 0
        self.text_widgets = []
        self.text_map = {}         # (dòng, cột file) -> ô Text
        self.label_widgets = []    # nút "điền hàng loạt" trong cột danh mục
        self.backup_var = tk.BooleanVar(value=True)
        self.label_w = LABEL_W   # độ rộng cột đầu tiên, kéo thanh chia để đổi
        self._build_ui()
        self._redraw()
        if paths:
            self.after(50, lambda: self.add_paths(paths))

    # ---------------- UI ----------------
    def _build_ui(self):
        bar = ttk.Frame(self, padding=(8, 6))
        bar.pack(fill="x")
        ttk.Button(bar, text="Nạp file Excel…", command=self.load_files).pack(side="left")
        ttk.Button(bar, text="Xóa danh sách", command=self.clear_all).pack(side="left", padx=6)
        ttk.Checkbutton(bar, text="Tạo bản sao lưu (.bak) lần lưu đầu",
                        variable=self.backup_var).pack(side="left", padx=12)
        ttk.Button(bar, text="Đổi tên sản phẩm hàng loạt…", command=self._bulk_rename).pack(side="left", padx=6)
        self.save_btn = ttk.Button(bar, text="Lưu hàng loạt", command=self.save_all)
        self.save_btn.pack(side="right")

        legend = ttk.Frame(self, padding=(8, 0))
        legend.pack(fill="x")
        tk.Label(legend, text="  Không  ", bg=C_PINK).pack(side="left")
        tk.Label(legend, text="  Có  ", bg=C_GREEN).pack(side="left", padx=4)
        tk.Label(legend, text="Viền cam / nền vàng nhạt = đã sửa, chưa lưu.  Bấm vào ô để đổi.  "
                              "Bấm tên danh mục để đổi cả dòng.  "
                              "Bấm đúp tên sản phẩm (đầu cột) để đổi tên.  "
                              "Chuột phải vào tên cột để đổi tên / bỏ file.  "
                              "Kéo thanh xám giữa để đổi độ rộng cột danh mục (bấm đúp để về mặc định).",
                 fg="#555").pack(side="left", padx=8)

        grid = ttk.Frame(self)
        grid.pack(fill="both", expand=True, padx=8, pady=6)
        grid.columnconfigure(2, weight=1)
        grid.rowconfigure(1, weight=1)

        self.corner = tk.Canvas(grid, width=self.label_w, height=HEADER_H,
                                bg=C_HEAD, highlightthickness=0)
        self.header = tk.Canvas(grid, height=HEADER_H, bg=C_HEAD, highlightthickness=0)
        self.labelc = tk.Canvas(grid, width=self.label_w, bg="white", highlightthickness=0)
        # thanh chia: kéo ngang để đổi độ rộng cột đầu tiên
        self.sash = tk.Frame(grid, width=6, bg="#9AA5B8", cursor="sb_h_double_arrow")
        self.sash.bind("<B1-Motion>", self._on_sash_drag)
        self.sash.bind("<Double-Button-1>", lambda e: self._set_label_w(LABEL_W))
        self.body = tk.Canvas(grid, bg="white", highlightthickness=0)
        self.vbar = ttk.Scrollbar(grid, orient="vertical", command=self._yview)
        self.hbar = ttk.Scrollbar(grid, orient="horizontal", command=self._xview)
        self.body.configure(xscrollcommand=self.hbar.set, yscrollcommand=self.vbar.set)

        self.corner.grid(row=0, column=0, sticky="nsew")
        self.labelc.grid(row=1, column=0, sticky="nsew")
        self.sash.grid(row=0, column=1, rowspan=2, sticky="ns")
        self.header.grid(row=0, column=2, sticky="nsew")
        self.body.grid(row=1, column=2, sticky="nsew")
        self.vbar.grid(row=1, column=3, sticky="ns")
        self.hbar.grid(row=2, column=2, sticky="ew")

        self.body.bind("<Button-1>", self._on_body_click)
        self.labelc.bind("<Button-1>", self._on_label_click)
        self.header.bind("<Double-Button-1>", self._on_header_dbl)
        self.header.bind("<Button-3>", self._on_header_menu)
        self.header.bind("<Button-2>", self._on_header_menu)   # macOS
        for w in (self.body, self.labelc, self.header):
            self._bind_scroll(w)

        self.status = tk.StringVar(value="Bấm 'Nạp file Excel…' để chọn nhiều file.")
        ttk.Label(self, textvariable=self.status, relief="sunken",
                  anchor="w", padding=(8, 3)).pack(fill="x", side="bottom")

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _bind_scroll(self, w, only_if_unfocused=False):
        def wheel(e):
            if only_if_unfocused and self.focus_get() is w:
                return None                    # ô văn bản đang soạn: để tự cuộn
            self._scroll_units(-1 if e.delta > 0 else 1)
            return "break"

        def wheel_h(e):
            self._xview("scroll", -1 if e.delta > 0 else 1, "units")
            return "break"

        def up(e):
            if only_if_unfocused and self.focus_get() is w:
                return None
            self._scroll_units(-3)
            return "break"

        def down(e):
            if only_if_unfocused and self.focus_get() is w:
                return None
            self._scroll_units(3)
            return "break"

        w.bind("<MouseWheel>", wheel)
        w.bind("<Shift-MouseWheel>", wheel_h)
        w.bind("<Button-4>", up)
        w.bind("<Button-5>", down)

    # ---------------- đổi độ rộng cột đầu ----------------
    def _on_sash_drag(self, e):
        self._set_label_w(e.x_root - self.corner.winfo_rootx())

    def _set_label_w(self, w):
        w = max(MIN_LABEL_W, min(int(w), max(MIN_LABEL_W, self.winfo_width() - 250)))
        if w == self.label_w:
            return
        self.label_w = w
        self.corner.configure(width=w)
        self.labelc.configure(width=w)
        self._draw_labels()

    # ---------------- bố cục dòng ----------------
    def _build_layout(self):
        self.layout = []
        y = 0
        for kind, row in FORM_ROWS:
            if row in SECTION_BEFORE:
                self.layout.append({"kind": "section", "row": row, "y": y, "h": SECTION_H,
                                    "title": self.titles.get(row, "")})
                y += SECTION_H
            h = ROW_H if kind == "check" else TEXT_H
            self.layout.append({"kind": kind, "row": row, "y": y, "h": h})
            y += h
        self.total_h = y

    def _item_at(self, canvas_y):
        for it in self.layout:
            if it["y"] <= canvas_y < it["y"] + it["h"]:
                return it
        return None

    def _draw_labels(self):
        for w_ in self.label_widgets:
            w_.destroy()
        self.label_widgets = []
        self.corner.delete("all")
        self.labelc.delete("all")
        w = self.label_w
        self.labelc.configure(scrollregion=(0, 0, w, self.total_h))
        self.corner.create_text(10, HEADER_H // 2, anchor="w", width=w - 16,
                                font=("Segoe UI", 10, "bold"),
                                text="Danh mục\n(tên sản phẩm ở hàng trên)")
        for it in self.layout:
            y0, h = it["y"], it["h"]
            if it["kind"] == "section":
                self.labelc.create_rectangle(0, y0, w, y0 + h, fill=C_SECTION, outline=C_EDGE)
                self.labelc.create_text(8, y0 + h // 2, anchor="w", width=w - 16,
                                        font=("Segoe UI", 10, "bold"), text=it["title"])
                continue
            label = self.labels.get(it["row"], "")
            if it["kind"] == "text":
                label = (label + "\n" if label else "") + "(nhập văn bản, tối đa %d ký tự)" % MAX_TEXT
                font = ("Segoe UI", 9, "bold")
            else:
                font = ("Segoe UI", 9)
            self.labelc.create_rectangle(0, y0, w, y0 + h, fill="#FAFAFA", outline=C_EDGE)
            if it["kind"] == "text":
                self.labelc.create_text(8, y0 + 8, anchor="nw", width=w - 16,
                                        font=font, text=label)
                if self.files:
                    fr = ttk.Frame(self.labelc)
                    ttk.Label(fr, text="Điền từ ô đầu tiên cho:").pack(side="left")
                    ttk.Button(fr, text="Tất cả file", width=11,
                               command=lambda r=it["row"]: self.fill_text_row(r, 0, "all")
                               ).pack(side="left", padx=(6, 3))
                    ttk.Button(fr, text="Chỉ ô trống", width=11,
                               command=lambda r=it["row"]: self.fill_text_row(r, 0, "empty")
                               ).pack(side="left")
                    self.labelc.create_window(8, y0 + h - 8, anchor="sw", window=fr)
                    self.label_widgets.append(fr)
            else:
                self.labelc.create_text(8, y0 + h // 2, anchor="w", width=w - 16,
                                        font=font, text=label)

    # ---------------- cuộn ----------------
    def _xview(self, *a):
        self.body.xview(*a)
        self.header.xview(*a)

    def _yview(self, *a):
        self.body.yview(*a)
        self.labelc.yview(*a)

    def _scroll_units(self, n):
        self._yview("scroll", n, "units")

    # ---------------- vẽ ----------------
    def _is_modified(self, f):
        return f["states"] != f["orig"]

    def _destroy_text_widgets(self):
        for t in self.text_widgets:
            t.destroy()
        self.text_widgets = []
        self.text_map = {}

    def _redraw(self):
        self._destroy_text_widgets()
        self.header.delete("all")
        self.body.delete("all")
        self._build_layout()
        n = len(self.files)
        total_w = max(n * COL_W, 1)
        self.body.configure(scrollregion=(0, 0, total_w, self.total_h))
        self.header.configure(scrollregion=(0, 0, total_w, HEADER_H))
        self._draw_labels()
        self._draw_header()

        for it in self.layout:
            if it["kind"] == "section" and n:
                self.body.create_rectangle(0, it["y"], total_w, it["y"] + it["h"],
                                           fill=C_SECTION, outline=C_EDGE)
        for c in range(n):
            for it in self.layout:
                if it["kind"] == "check":
                    self._paint_cell(it, c)
                elif it["kind"] == "text":
                    self._make_text(it, c)
        self._update_status()

    def _draw_header(self):
        self.header.delete("all")
        for c, f in enumerate(self.files):
            x0 = c * COL_W
            self.header.create_rectangle(x0, 0, x0 + COL_W, HEADER_H,
                                         fill=C_HEAD, outline=C_EDGE)
            mark = "● " if self._is_modified(f) else ""
            if f["name"]:
                self.header.create_text(x0 + 6, 5, anchor="nw", width=COL_W - 12,
                                        font=("Segoe UI", 10, "bold"),
                                        text=mark + short(f["name"], 52))
            else:
                self.header.create_text(x0 + 6, 5, anchor="nw", width=COL_W - 12,
                                        font=("Segoe UI", 10, "italic"), fill="#888",
                                        text=mark + "(chưa có tên SP)")
            self.header.create_text(x0 + 6, HEADER_H - 4, anchor="sw",
                                    font=("Segoe UI", 8), fill="#555",
                                    text=short(os.path.basename(f["path"]), 28))

    def _paint_cell(self, it, c):
        f = self.files[c]
        row = it["row"]
        on = f["states"][row]
        changed = on != f["orig"][row]
        tag = "c%d_%d" % (row, c)
        self.body.delete(tag)
        x0, y0, h = c * COL_W, it["y"], it["h"]
        self.body.create_rectangle(
            x0, y0, x0 + COL_W, y0 + h,
            fill=C_GREEN if on else C_PINK,
            outline=C_MOD if changed else C_EDGE,
            width=3 if changed else 1, tags=tag)
        bx, by = x0 + 34, y0 + (h - BOX) // 2
        self.body.create_rectangle(bx, by, bx + BOX, by + BOX,
                                   fill="white", outline="#666", width=2, tags=tag)
        if on:
            self.body.create_text(bx + BOX // 2, by + BOX // 2, text="✓",
                                  font=("Segoe UI", 14, "bold"), fill="#0B7A2B", tags=tag)
        self.body.create_text(bx + BOX + 10, y0 + h // 2, anchor="w",
                              text=YES if on else NO, font=("Segoe UI", 9),
                              fill="#0B5A20" if on else "#8A1C2B", tags=tag)

    def _make_text(self, it, c):
        f = self.files[c]
        row = it["row"]
        x0, y0, h = c * COL_W, it["y"], it["h"]
        self.body.create_rectangle(x0, y0, x0 + COL_W, y0 + h, fill="#FAFAFA", outline=C_EDGE)
        t = tk.Text(self.body, wrap="word", font=("Segoe UI", 9), relief="solid", bd=1,
                    undo=True, padx=4, pady=3)
        t.insert("1.0", f["states"][row])
        t.edit_reset()
        t.edit_modified(False)
        t.configure(bg=C_TEXT_MOD if f["states"][row] != f["orig"][row] else "white")
        t.bind("<<Modified>>", lambda e, t=t, c=c, row=row: self._on_text_modified(t, c, row))
        t.bind("<Control-a>", self._select_all)
        t.bind("<Control-A>", self._select_all)
        self._bind_scroll(t, only_if_unfocused=True)
        t.bind("<Button-3>", lambda e, row=row, c=c: self._text_menu(e, row, c))
        t.bind("<Button-2>", lambda e, row=row, c=c: self._text_menu(e, row, c))  # macOS
        self.text_map[(row, c)] = t
        self.body.create_window(x0 + 4, y0 + 4, anchor="nw", window=t,
                                width=COL_W - 8, height=h - 8)
        self.text_widgets.append(t)

    def _text_menu(self, e, row, c):
        w = e.widget
        w.focus_set()
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Cắt", command=lambda: w.event_generate("<<Cut>>"))
        menu.add_command(label="Sao chép", command=lambda: w.event_generate("<<Copy>>"))
        menu.add_command(label="Dán", command=lambda: w.event_generate("<<Paste>>"))
        menu.add_separator()
        menu.add_command(label="Áp dụng nội dung ô này cho TẤT CẢ file",
                         command=lambda: self.fill_text_row(row, c, "all"))
        menu.add_command(label="Áp dụng nội dung ô này cho các file bên phải",
                         command=lambda: self.fill_text_row(row, c, "right"))
        menu.add_command(label="Áp dụng nội dung ô này vào các ô còn trống",
                         command=lambda: self.fill_text_row(row, c, "empty"))
        menu.tk_popup(e.x_root, e.y_root)
        return "break"

    def fill_text_row(self, row, src_col=0, mode="all"):
        """Chép nội dung ô văn bản của file `src_col` sang các file khác trong cùng dòng.
        mode: "all" = mọi file khác, "right" = các file bên phải, "empty" = chỉ ô đang trống."""
        if not self.files or not (0 <= src_col < len(self.files)):
            return
        src = self.files[src_col]["states"][row]
        if mode == "right":
            cols = range(src_col + 1, len(self.files))
        elif mode == "empty":
            cols = [c for c, f in enumerate(self.files)
                    if c != src_col and f["states"][row] == ""]
        else:
            cols = [c for c in range(len(self.files)) if c != src_col]
        cols = [c for c in cols if self.files[c]["states"][row] != src]
        if not cols:
            self.status.set("Không có ô nào cần thay đổi.")
            return
        overwrite = sum(1 for c in cols if self.files[c]["states"][row] != "")
        if overwrite and not messagebox.askyesno(
                "Điền hàng loạt",
                "%d ô đã có nội dung khác sẽ bị ghi đè%s.\nTiếp tục?"
                % (overwrite, " (và bị xóa trống)" if src == "" else "")):
            return
        for c in cols:
            f = self.files[c]
            f["states"][row] = src
            t = self.text_map.get((row, c))
            if t is not None:
                t.delete("1.0", "end")
                t.insert("1.0", src)
                t.configure(bg=C_TEXT_MOD if src != f["orig"][row] else "white")
        self._draw_header()
        self._update_status()
        self.status.set("Đã điền %d ô.  " % len(cols) + self.status.get())

    @staticmethod
    def _select_all(e):
        e.widget.tag_add("sel", "1.0", "end-1c")
        return "break"

    def _on_text_modified(self, t, c, row):
        if not t.edit_modified():
            return
        t.edit_modified(False)
        txt = t.get("1.0", "end-1c")
        if len(txt) > MAX_TEXT:
            t.delete("1.0+%dc" % MAX_TEXT, "end-1c")
            txt = t.get("1.0", "end-1c")
            t.bell()
            self.status.set("Ô văn bản chỉ nhận tối đa %d ký tự." % MAX_TEXT)
        f = self.files[c]
        was_modified = self._is_modified(f)
        f["states"][row] = clean_text(txt)
        t.configure(bg=C_TEXT_MOD if f["states"][row] != f["orig"][row] else "white")
        if self._is_modified(f) != was_modified:
            self._draw_header()
        self._update_status(keep_message=len(txt) >= MAX_TEXT)

    def _update_status(self, keep_message=False):
        n = len(self.files)
        mod = sum(1 for f in self.files if self._is_modified(f))
        cells = sum(1 for f in self.files
                    for r, v in f["states"].items() if v != f["orig"][r])
        if not keep_message:
            self.status.set("%d file đã nạp  |  %d file có thay đổi (%d ô) chưa lưu"
                            % (n, mod, cells))
        self.save_btn.configure(text="Lưu hàng loạt (%d)" % mod if mod else "Lưu hàng loạt")
        self.save_btn.state(["!disabled"] if mod else ["disabled"])

    # ---------------- tương tác ----------------
    def _on_body_click(self, e):
        self.body.focus_set()
        x, y = self.body.canvasx(e.x), self.body.canvasy(e.y)
        c = int(x // COL_W)
        it = self._item_at(y)
        if it and it["kind"] == "check" and 0 <= c < len(self.files):
            f = self.files[c]
            f["states"][it["row"]] = not f["states"][it["row"]]
            self._paint_cell(it, c)
            self._draw_header()
            self._update_status()

    def _on_label_click(self, e):
        self.labelc.focus_set()
        if not self.files:
            return
        it = self._item_at(self.labelc.canvasy(e.y))
        if not it or it["kind"] != "check":
            return
        row = it["row"]
        target = not all(f["states"][row] for f in self.files)
        for c, f in enumerate(self.files):
            f["states"][row] = target
            self._paint_cell(it, c)
        self._draw_header()
        self._update_status()

    def set_name(self, c, new):
        """Đổi tên sản phẩm (ô I2) của file thứ c - chỉ ghi vào file khi bấm Lưu hàng loạt."""
        f = self.files[c]
        new = " ".join((new or "").split())
        f["states"][NAME_KEY] = new
        f["name"] = new

    def _edit_name(self, c):
        f = self.files[c]
        new = simpledialog.askstring("Đổi tên sản phẩm", "Tên sản phẩm mới (ô I2):\n%s" % os.path.basename(f["path"]),
                                     initialvalue=f["states"][NAME_KEY], parent=self)
        if new is None:
            return
        self.set_name(c, new)
        self._draw_header()
        self._update_status()

    def _on_header_dbl(self, e):
        c = int(self.header.canvasx(e.x) // COL_W)
        if 0 <= c < len(self.files):
            self._edit_name(c)

    def _bulk_rename(self):
        if not self.files:
            messagebox.showinfo("Đổi tên sản phẩm", "Hãy nạp file Excel trước.", parent=self)
            return
        RenameNamesDialog(self, self.files, self._apply_names)

    def _apply_names(self, new_names):
        """new_names: list tên mới theo thứ tự self.files."""
        n = 0
        for c, nm in enumerate(new_names):
            if nm != self.files[c]["states"][NAME_KEY]:
                self.set_name(c, nm)
                n += 1
        self._draw_header()
        self._update_status()
        self.status.set("Đã đổi tên %d sản phẩm (chưa lưu).  " % n + self.status.get())

    def _on_header_menu(self, e):
        c = int(self.header.canvasx(e.x) // COL_W)
        if not (0 <= c < len(self.files)):
            return
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Đổi tên sản phẩm…", command=lambda: self._edit_name(c))
        menu.add_separator()
        menu.add_command(label="Bỏ file này khỏi danh sách", command=lambda: self._remove_file(c))
        menu.tk_popup(e.x_root, e.y_root)

    def _remove_file(self, c):
        f = self.files[c]
        if self._is_modified(f) and not messagebox.askyesno(
                "Bỏ file", "File này có thay đổi chưa lưu. Vẫn bỏ?"):
            return
        del self.files[c]
        self._redraw()

    # ---------------- nạp / lưu ----------------
    @staticmethod
    def _norm_labels(d):
        return {r: " ".join(v.split()) for r, v in d.items()}

    def load_files(self):
        paths = filedialog.askopenfilenames(
            parent=self, title="Chọn các file Excel mẫu",
            filetypes=[("Excel", "*.xlsx *.xlsm"), ("Tất cả", "*.*")])
        if paths:
            self.add_paths(paths)

    def add_paths(self, paths):
        self.config(cursor="watch")
        self.update_idletasks()
        known = {os.path.normcase(os.path.abspath(f["path"])) for f in self.files}
        errors, mismatched = [], []
        for p in paths:
            key = os.path.normcase(os.path.abspath(p))
            if key in known:
                continue
            try:
                d = read_form(p)
            except Exception as ex:
                errors.append("%s: %s" % (os.path.basename(p), ex))
                continue
            if not self.files:
                self.labels = d["labels"]
                self.titles = d["titles"]
            elif self._norm_labels(d["labels"]) != self._norm_labels(self.labels):
                mismatched.append(os.path.basename(p))
            orig = dict(d["values"])
            orig[NAME_KEY] = d["name"]
            self.files.append({"path": p, "name": d["name"],
                               "orig": orig, "states": dict(orig)})
            known.add(key)
        self.config(cursor="")
        self._redraw()
        msg = []
        if errors:
            msg.append("Không đọc được:\n  " + "\n  ".join(errors))
        if mismatched:
            msg.append("Danh mục khác file đầu tiên (vẫn nạp, hiển thị theo file đầu tiên):\n  "
                       + "\n  ".join(mismatched))
        if msg:
            messagebox.showwarning("Lưu ý khi nạp file", "\n\n".join(msg), parent=self)

    def clear_all(self):
        if any(self._is_modified(f) for f in self.files) and not messagebox.askyesno(
                "Xóa danh sách", "Có thay đổi chưa lưu. Vẫn xóa danh sách?"):
            return
        self.files.clear()
        self.labels = {}
        self.titles = {}
        self._redraw()

    def save_all(self):
        todo = [f for f in self.files if self._is_modified(f)]
        if not todo:
            return
        if not messagebox.askyesno(
                "Lưu hàng loạt",
                "Ghi đè %d file Excel với các thay đổi?\n"
                "(Hãy đóng các file này trong Excel trước khi lưu.)" % len(todo)):
            return
        self.config(cursor="watch")
        self.update_idletasks()
        ok, fails = 0, []
        for f in todo:
            changes = {r: v for r, v in f["states"].items() if v != f["orig"][r]}
            try:
                if self.backup_var.get():
                    bak = f["path"] + ".bak"
                    if not os.path.exists(bak):
                        shutil.copy2(f["path"], bak)
                write_changes(f["path"], changes)
                f["orig"] = dict(f["states"])
                ok += 1
            except PermissionError:
                fails.append("%s: không ghi được – file đang mở trong Excel?"
                             % os.path.basename(f["path"]))
            except Exception as ex:
                fails.append("%s: %s" % (os.path.basename(f["path"]), ex))
        self.config(cursor="")
        self._redraw()
        if fails:
            messagebox.showerror("Lưu xong, có lỗi",
                                 "Đã lưu %d file.\nLỗi %d file:\n  %s"
                                 % (ok, len(fails), "\n  ".join(fails)))
        else:
            messagebox.showinfo("Đã lưu", "Đã lưu thành công %d file." % ok)

    def _on_close(self):
        if any(self._is_modified(f) for f in self.files) and not messagebox.askyesno(
                "Thoát", "Còn thay đổi chưa lưu. Vẫn thoát?"):
            return
        self.destroy()




class RenameNamesDialog(tk.Toplevel):
    """Đổi tên sản phẩm (ô I2) hàng loạt: bỏ số thứ tự đầu tên, tìm/thay, thêm tiền tố / hậu tố; có xem trước."""

    def __init__(self, master, files, on_apply):
        super().__init__(master)
        self.title("Đổi tên sản phẩm hàng loạt")
        self.geometry("900x620")
        self.minsize(760, 480)
        self.files = files
        self.on_apply = on_apply
        self.v_find, self.v_repl = tk.StringVar(), tk.StringVar()
        self.v_pre, self.v_suf = tk.StringVar(), tk.StringVar()
        self.v_num = tk.BooleanVar(value=False)
        self.v_case = tk.BooleanVar(value=True)
        box = ttk.LabelFrame(self, text="Cách đổi (áp dụng lần lượt từ trên xuống, kết quả xem ngay ở bảng dưới)")
        box.pack(fill="x", padx=12, pady=10)
        box.columnconfigure(1, weight=1)
        box.columnconfigure(3, weight=1)
        ttk.Checkbutton(box, text="Bỏ số thứ tự đứng đầu tên (1. , 2.1 - , …)", variable=self.v_num,
                        command=self._preview).grid(row=0, column=0, columnspan=4, sticky="w", padx=8, pady=(6, 2))
        ttk.Label(box, text="Tìm:").grid(row=1, column=0, sticky="e", padx=(8, 4), pady=3)
        ttk.Entry(box, textvariable=self.v_find).grid(row=1, column=1, sticky="ew", padx=4)
        ttk.Label(box, text="Thay bằng:").grid(row=1, column=2, sticky="e", padx=(12, 4))
        ttk.Entry(box, textvariable=self.v_repl).grid(row=1, column=3, sticky="ew", padx=(4, 8))
        ttk.Checkbutton(box, text="Không phân biệt hoa/thường", variable=self.v_case,
                        command=self._preview).grid(row=2, column=1, sticky="w", padx=4)
        ttk.Label(box, text="Thêm vào đầu:").grid(row=3, column=0, sticky="e", padx=(8, 4), pady=3)
        ttk.Entry(box, textvariable=self.v_pre).grid(row=3, column=1, sticky="ew", padx=4)
        ttk.Label(box, text="Thêm vào cuối:").grid(row=3, column=2, sticky="e", padx=(12, 4))
        ttk.Entry(box, textvariable=self.v_suf).grid(row=3, column=3, sticky="ew", padx=(4, 8), pady=(0, 6))
        for v in (self.v_find, self.v_repl, self.v_pre, self.v_suf):
            v.trace_add("write", lambda *_a: self._preview())

        fr = ttk.LabelFrame(self, text="Xem trước - bấm đúp vào ô 'Tên mới' để sửa trực tiếp (Enter: lưu, Esc: bỏ, ↑ ↓: sang dòng khác)")
        fr.pack(fill="both", expand=True, padx=12, pady=4)
        self.tree = ttk.Treeview(fr, columns=("file", "old", "new"), show="headings", height=14)
        for col, text, w in (("file", "File", 200), ("old", "Tên hiện tại", 320), ("new", "Tên mới", 320)):
            self.tree.heading(col, text=text)
            self.tree.column(col, width=w, anchor="w")
        self.tree.tag_configure("chg", foreground="#B45F06")
        self.tree.tag_configure("man", foreground="#1F5FBF", background="#EAF2FF")
        self.tree.bind("<Double-Button-1>", self._on_dbl)
        self.manual = {}                 # {chỉ số file: tên sửa tay} - ưu tiên hơn kết quả của quy tắc
        self.auto = []                   # tên do quy tắc tạo ra
        self._edit = None
        vs = ttk.Scrollbar(fr, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vs.set)
        self.tree.pack(side="left", fill="both", expand=True, padx=(6, 0), pady=6)
        vs.pack(side="right", fill="y", pady=6)
        bb = ttk.Frame(self)
        bb.pack(fill="x", padx=12, pady=(4, 10))
        self.info = ttk.Label(bb, text="")
        self.info.pack(side="left")
        ttk.Button(bb, text="Áp dụng", command=self._apply).pack(side="right")
        ttk.Button(bb, text="Bỏ các chỗ đã sửa tay", command=self._clear_manual).pack(side="right", padx=(0, 8))
        ttk.Button(bb, text="Đóng", command=self.destroy).pack(side="right", padx=8)
        self.new_names = []
        self._preview()
        self.transient(master)

    def _preview(self):
        self._end_edit(False)
        self.tree.delete(*self.tree.get_children())
        self.auto, self.new_names = [], []
        changed = 0
        for i, f in enumerate(self.files):
            old = f["states"][NAME_KEY]
            auto = transform_name(old, self.v_find.get(), self.v_repl.get(), self.v_pre.get(), self.v_suf.get(),
                                  self.v_num.get(), self.v_case.get())
            self.auto.append(auto)
            new = self.manual.get(i, auto)
            self.new_names.append(new)
            diff = new != old
            changed += diff
            tags = ("man",) if i in self.manual else ("chg",) if diff else ()
            self.tree.insert("", "end", iid=str(i), tags=tags,
                             values=(os.path.basename(f["path"]), old, new))
        self.info.config(text="%d / %d tên sẽ thay đổi (%d sửa tay)" % (changed, len(self.files), len(self.manual)))

    # ---- sửa trực tiếp ô "Tên mới"
    def _on_dbl(self, e):
        if self.tree.identify_region(e.x, e.y) != "cell" or self.tree.identify_column(e.x) != "#3":
            return
        iid = self.tree.identify_row(e.y)
        if iid:
            self._begin_edit(iid)

    def _begin_edit(self, iid):
        self._end_edit(True)
        box = self.tree.bbox(iid, "#3")
        if not box:
            return
        x, y, w, h = box
        var = tk.StringVar(value=self.new_names[int(iid)])
        ent = ttk.Entry(self.tree, textvariable=var)
        ent.place(x=x, y=y, width=w, height=h)
        ent.focus_set()
        ent.select_range(0, "end")
        ent.bind("<Return>", lambda _e: self._end_edit(True))
        ent.bind("<Escape>", lambda _e: self._end_edit(False))
        ent.bind("<FocusOut>", lambda _e: self._end_edit(True))
        ent.bind("<Down>", lambda _e: self._move_edit(1))
        ent.bind("<Up>", lambda _e: self._move_edit(-1))
        self._edit = (iid, ent, var)
        self.tree.selection_set(iid)

    def _end_edit(self, commit):
        if not self._edit:
            return None
        iid, ent, var = self._edit
        self._edit = None
        text = " ".join(var.get().split())
        ent.destroy()
        if commit:
            self.set_manual(int(iid), text)
        return iid

    def _move_edit(self, step):
        iid = self._end_edit(True)
        if iid is not None:
            j = int(iid) + step
            if 0 <= j < len(self.files):
                self._begin_edit(str(j))
        return "break"

    def set_manual(self, i, text):
        """Đặt tên mới sửa tay cho dòng i; trùng với kết quả của quy tắc thì bỏ đánh dấu sửa tay."""
        if text == self.auto[i]:
            self.manual.pop(i, None)
        else:
            self.manual[i] = text
        old = self.files[i]["states"][NAME_KEY]
        self.new_names[i] = text
        tags = ("man",) if i in self.manual else ("chg",) if text != old else ()
        self.tree.item(str(i), tags=tags)
        self.tree.set(str(i), "new", text)
        self.info.config(text="%d / %d tên sẽ thay đổi (%d sửa tay)" % (
            sum(1 for k, f in enumerate(self.files) if self.new_names[k] != f["states"][NAME_KEY]),
            len(self.files), len(self.manual)))

    def _clear_manual(self):
        self.manual = {}
        self._preview()

    def _apply(self):
        self._end_edit(True)
        self.on_apply(list(self.new_names))
        self.destroy()
