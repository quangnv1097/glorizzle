# -*- coding: utf-8 -*-
"""
Gom dữ liệu mẫu: quét một thư mục các file Form dựng mẫu đã hoàn chỉnh và xuất MỘT bảng Excel nhỏ
chỉ gồm: Tên sản phẩm (I2) | Công dụng (B32) | Thành phần (sheet 4).
Các sheet/ô khác (nhà sản xuất, đơn vị đóng gói...) KHÔNG được đọc và không đưa vào bảng.
"""
import os
import warnings

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from xlsx_core import clean_text, read_form

CONGDUNG_ROW = 32
ING_SHEET_INDEX = 3
ING_FIRST_ROW = 5
ING_LAST_ROW = 1000
CELL_LIMIT = 32000          # Excel giới hạn 32767 ký tự/ô


def find_files(folder, recursive=True):
    out = []
    if recursive:
        walker = os.walk(folder)
    else:
        walker = [(folder, [], os.listdir(folder))]
    for root, _dirs, files in walker:
        for fn in files:
            low = fn.lower()
            if fn.startswith("~$") or not low.endswith((".xlsx", ".xlsm")):
                continue
            out.append(os.path.join(root, fn))
    return sorted(out)


def read_ingredients(path):
    """Trả về list[(tên, hàm lượng)] từ sheet 4 (cột B, C), bắt đầu dòng 5."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            if len(wb.worksheets) <= ING_SHEET_INDEX:
                raise ValueError("thiếu sheet 4 (danh sách thành phần)")
            ws = wb.worksheets[ING_SHEET_INDEX]
            try:
                ws.reset_dimensions()
            except Exception:
                pass
            items = []
            for row in ws.iter_rows(min_row=ING_FIRST_ROW, max_row=ING_LAST_ROW,
                                    min_col=1, max_col=4, values_only=True):
                row = tuple(row) + (None,) * (4 - len(row))
                name = clean_text(row[1]).strip()
                if name:
                    items.append((name, clean_text(row[2]).strip()))
        finally:
            wb.close()
    return items


def collect(folder, recursive=True, only_with_congdung=True, progress=None):
    """Trả về (rows, skipped, errors).
       rows   : list[dict(file, name, congdung, ingredients)]
       skipped: danh sách file bỏ qua vì chưa có công dụng
       errors : list[(file, lỗi)]"""
    files = find_files(folder, recursive)
    rows, skipped, errors = [], [], []
    for i, p in enumerate(files, start=1):
        if progress:
            progress(i, len(files), os.path.basename(p))
        try:
            info = read_form(p)
            cd = info["values"].get(CONGDUNG_ROW, "")
            cd = cd.strip() if isinstance(cd, str) else ""
            if only_with_congdung and not cd:
                skipped.append(os.path.basename(p))
                continue
            ings = read_ingredients(p)
            rows.append({"file": os.path.basename(p), "name": info["name"],
                         "congdung": cd, "ingredients": ings})
        except Exception as ex:
            errors.append((os.path.basename(p), str(ex)))
    return rows, skipped, errors


def export_xlsx(rows, out_path, with_percent=False):
    wb = Workbook()
    ws = wb.active
    ws.title = "Du lieu mau"
    head = ["STT", "File", "Tên sản phẩm", "Công dụng", "Số thành phần", "Thành phần"]
    ws.append(head)
    for i, r in enumerate(rows, start=1):
        if with_percent:
            parts = ["%s (%s)" % (n, p) if p else n for n, p in r["ingredients"]]
        else:
            parts = [n for n, _p in r["ingredients"]]
        text = "; ".join(parts)
        if len(text) > CELL_LIMIT:
            text = text[:CELL_LIMIT - 1] + "…"
        ws.append([i, r["file"], r["name"], r["congdung"], len(r["ingredients"]), text])
    fill = PatternFill("solid", fgColor="DDE6F3")
    for c in range(1, len(head) + 1):
        cell = ws.cell(1, c)
        cell.font = Font(bold=True)
        cell.fill = fill
        cell.alignment = Alignment(horizontal="center", vertical="center")
    for col, w in zip("ABCDEF", (6, 38, 42, 60, 14, 90)):
        ws.column_dimensions[col].width = w
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=cell.column in (2, 3, 4, 6))
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = "A1:%s%d" % (get_column_letter(len(head)), max(len(rows) + 1, 1))
    wb.save(out_path)
