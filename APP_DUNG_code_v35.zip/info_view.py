# -*- coding: utf-8 -*-
"""Cửa sổ "Thay đổi các Info": nhập thông tin một lần, cập nhật hàng loạt nhiều file Excel."""
import os
import tkinter as tk
from datetime import date
from tkinter import filedialog, messagebox, ttk

import dung_engine as eng
import gom_data
import info_engine as ie


class InfoWindow(tk.Toplevel):
    def __init__(self, master, settings, paths=None):
        super().__init__(master)
        self.title("Thay đổi các Info")
        self.geometry("980x800")
        self.minsize(900, 680)
        self.settings = settings
        self.vars = {k: tk.StringVar() for k, *_ in ie.FIELDS}
        self.backup_var = tk.BooleanVar(value=True)
        self.paths = []                      # danh sách đường dẫn theo thứ tự trong bảng
        self._build_ui()
        if paths:
            self.add_paths(paths)

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        ttk.Label(self, wraplength=940, justify="left", foreground="#555", text=(
            "Chỉ các ô bạn nhập mới được ghi vào file; ô để trống thì giữ nguyên giá trị trong file. "
            "Số điện thoại và ngày ký được ghi dạng văn bản (giữ số 0 đầu).")
                  ).pack(fill="x", padx=12, pady=(10, 4))

        top = ttk.LabelFrame(self, text="1. Thông tin cần thay")
        top.pack(fill="x", padx=12, pady=6)
        top.columnconfigure(0, weight=1)
        top.columnconfigure(1, weight=1)

        left = ttk.Frame(top)
        left.grid(row=0, column=0, rowspan=2, sticky="nsew", padx=(8, 4), pady=6)
        self._group(left, "chung", with_today=True)
        right1 = ttk.Frame(top)
        right1.grid(row=0, column=1, sticky="nsew", padx=(4, 8), pady=(6, 0))
        self._group(right1, "nsx")
        right2 = ttk.Frame(top)
        right2.grid(row=1, column=1, sticky="nsew", padx=(4, 8), pady=(0, 6))
        self._group(right2, "dg")

        bar = ttk.Frame(top)
        bar.grid(row=2, column=0, columnspan=2, sticky="ew", padx=8, pady=(0, 8))
        ttk.Button(bar, text="Điền sẵn từ file đầu tiên trong danh sách",
                   command=self._prefill).pack(side="left")
        ttk.Button(bar, text="Xóa trắng các ô nhập", command=self._clear_inputs).pack(side="left", padx=6)

        fb = ttk.LabelFrame(self, text="2. Các file Excel cần cập nhật (.xlsx / .xlsm)")
        fb.pack(fill="both", expand=True, padx=12, pady=6)
        tb = ttk.Frame(fb)
        tb.pack(fill="x", padx=8, pady=(6, 0))
        ttk.Button(tb, text="Thêm file…", command=self._pick_files).pack(side="left")
        ttk.Button(tb, text="Thêm cả thư mục…", command=self._pick_folder).pack(side="left", padx=6)
        ttk.Button(tb, text="Bỏ file đã chọn", command=self._remove_selected).pack(side="left")
        ttk.Button(tb, text="Xóa hết", command=self._clear_files).pack(side="left", padx=6)
        self.count_label = ttk.Label(tb, text="")
        self.count_label.pack(side="right")

        holder = ttk.Frame(fb)
        holder.pack(fill="both", expand=True, padx=8, pady=6)
        self.tree = ttk.Treeview(holder, columns=("file", "dir", "kq"), show="headings", height=8)
        self.tree.heading("file", text="File")
        self.tree.heading("dir", text="Thư mục")
        self.tree.heading("kq", text="Kết quả")
        self.tree.column("file", width=330, anchor="w")
        self.tree.column("dir", width=300, anchor="w")
        self.tree.column("kq", width=260, anchor="w")
        vs = ttk.Scrollbar(holder, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vs.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vs.pack(side="right", fill="y")

        rb = ttk.Frame(self)
        rb.pack(fill="x", padx=12, pady=(2, 10))
        self.run_btn = ttk.Button(rb, text="Cập nhật hàng loạt", command=self.run)
        self.run_btn.pack(side="left")
        ttk.Checkbutton(rb, text="Tạo bản sao lưu (.bak) cho mỗi file",
                        variable=self.backup_var).pack(side="left", padx=12)
        self.progress = ttk.Progressbar(rb, mode="determinate")
        self.progress.pack(side="left", fill="x", expand=True, padx=10)

        self._update_count()

    def _group(self, parent, group, with_today=False):
        box = ttk.LabelFrame(parent, text=ie.GROUP_TITLES[group])
        box.pack(fill="both", expand=True)
        box.columnconfigure(1, weight=1)
        r = 0
        for key, label, _targets, g in ie.FIELDS:
            if g != group:
                continue
            ttk.Label(box, text=label).grid(row=r, column=0, sticky="w", padx=(8, 6), pady=(5, 0))
            hint = "→ " + ie.targets_text(key)
            if group != "chung":
                hint = "→ " + ie.targets_text(key)
            ttk.Label(box, text=hint, foreground="#888", font=("Segoe UI", 8)).grid(
                row=r, column=2, sticky="w", padx=(6, 8), pady=(5, 0))
            ent = ttk.Entry(box, textvariable=self.vars[key])
            ent.grid(row=r + 1, column=0, columnspan=2, sticky="ew", padx=8, pady=(0, 2))
            if with_today and key == "sign_date":
                ttk.Button(box, text="Hôm nay", width=9,
                           command=lambda: self.vars["sign_date"].set(date.today().strftime("%d/%m/%Y"))
                           ).grid(row=r + 1, column=2, padx=(6, 8))
            r += 2
        ttk.Frame(box, height=4).grid(row=r, column=0)

    # ------------------------------------------------------------- danh sách file
    def _update_count(self):
        self.count_label.config(text="%d file" % len(self.paths))
        self.run_btn.config(state="normal" if self.paths else "disabled")

    def add_paths(self, paths):
        known = {os.path.normcase(os.path.abspath(p)) for p in self.paths}
        added = skipped = 0
        for p in paths:
            key = os.path.normcase(os.path.abspath(p))
            if key in known:
                continue
            known.add(key)
            ok = p.lower().endswith(ie.SUPPORTED)
            self.paths.append(p)
            self.tree.insert("", "end", iid=str(len(self.paths) - 1),
                             values=(os.path.basename(p), os.path.dirname(p),
                                     "" if ok else "✖ không hỗ trợ (hãy lưu sang .xlsx)"))
            added += 1
            skipped += (not ok)
        self._update_count()
        if skipped:
            messagebox.showwarning("Lưu ý", "%d file không phải .xlsx/.xlsm nên sẽ không được cập nhật." % skipped,
                                   parent=self)

    def _reindex(self):
        self.tree.delete(*self.tree.get_children())
        for i, p in enumerate(self.paths):
            ok = p.lower().endswith(ie.SUPPORTED)
            self.tree.insert("", "end", iid=str(i), values=(
                os.path.basename(p), os.path.dirname(p), "" if ok else "✖ không hỗ trợ (hãy lưu sang .xlsx)"))
        self._update_count()

    def _pick_files(self):
        ps = filedialog.askopenfilenames(
            parent=self, title="Chọn các file Excel cần cập nhật",
            initialdir=self.settings.get("info_dir") or self.settings.get("out_dir") or None,
            filetypes=[("Excel", "*.xlsx *.xlsm *.xls *.xlsb"), ("Tất cả", "*.*")])
        if ps:
            self.settings["info_dir"] = os.path.dirname(ps[0])
            eng.save_settings(self.settings)
            self.add_paths(ps)

    def _pick_folder(self):
        d = filedialog.askdirectory(parent=self, title="Chọn thư mục chứa các file Excel",
                                    initialdir=self.settings.get("info_dir") or self.settings.get("out_dir") or None)
        if not d:
            return
        self.settings["info_dir"] = d
        eng.save_settings(self.settings)
        files = gom_data.find_files(d, recursive=True)
        if not files:
            messagebox.showinfo("Thêm thư mục", "Không thấy file .xlsx/.xlsm nào trong thư mục này.", parent=self)
            return
        self.add_paths(files)

    def _remove_selected(self):
        sel = {int(i) for i in self.tree.selection()}
        if not sel:
            return
        self.paths = [p for i, p in enumerate(self.paths) if i not in sel]
        self._reindex()

    def _clear_files(self):
        self.paths = []
        self._reindex()

    # ------------------------------------------------------------- ô nhập
    def _prefill(self):
        first = next((p for p in self.paths if p.lower().endswith(ie.SUPPORTED)), None)
        if not first:
            messagebox.showinfo("Điền sẵn", "Hãy thêm ít nhất một file .xlsx/.xlsm vào danh sách.", parent=self)
            return
        try:
            info = ie.read_info(first)
        except Exception as ex:
            messagebox.showerror("Không đọc được file", str(ex), parent=self)
            return
        for k, v in info.items():
            self.vars[k].set(v)

    def _clear_inputs(self):
        for v in self.vars.values():
            v.set("")

    def _values(self):
        return ie.clean_values({k: v.get() for k, v in self.vars.items()})

    # ------------------------------------------------------------- chạy
    def run(self):
        vals = self._values()
        if not vals:
            messagebox.showwarning("Chưa nhập gì", "Bạn chưa nhập thông tin nào để thay.", parent=self)
            return
        todo = [(i, p) for i, p in enumerate(self.paths) if p.lower().endswith(ie.SUPPORTED)]
        if not todo:
            messagebox.showwarning("Không có file", "Chưa có file .xlsx/.xlsm nào trong danh sách.", parent=self)
            return
        warns = ie.validate(vals)
        fields = ", ".join(ie.FIELD_BY_KEY[k][1] for k in vals)
        msg = ("Sẽ ghi đè %d file với các thông tin:\n  %s\n\n(Hãy đóng các file này trong Excel trước.)"
               % (len(todo), fields))
        if warns:
            msg += "\n\nLưu ý:\n  " + "\n  ".join(warns)
        if not messagebox.askyesno("Cập nhật hàng loạt", msg + "\n\nTiếp tục?", parent=self):
            return

        self.run_btn.config(state="disabled")
        self.config(cursor="watch")
        self.progress.config(maximum=len(todo), value=0)
        ok = fail = 0
        for n, (i, p) in enumerate(todo, start=1):
            self.progress["value"] = n - 1
            self.update_idletasks()
            try:
                cells, notes = ie.update_file(p, vals, make_backup=self.backup_var.get())
                text = "✔ đã ghi %d ô" % cells
                if notes:
                    text += " (" + "; ".join(notes) + ")"
                ok += 1
            except PermissionError:
                text = "✖ không ghi được – file đang mở trong Excel?"
                fail += 1
            except Exception as ex:
                text = "✖ %s" % ex
                fail += 1
            self.tree.set(str(i), "kq", text)
        self.progress["value"] = len(todo)
        self.config(cursor="")
        self.run_btn.config(state="normal")
        messagebox.showinfo("Hoàn tất", "Thành công: %d file.\nLỗi: %d file.%s" % (
            ok, fail, "\n(Xem cột Kết quả để biết chi tiết.)" if fail else ""), parent=self)


# ======================================================================================
# Bảng info riêng cho từng nhóm (dùng trong cửa sổ Dựng BTP: "Điền info các nhóm gộp")
# ======================================================================================
class InfoForm(ttk.Frame):
    """Các ô nhập info giống cửa sổ "Thay đổi các Info" (3 khối: chung / nhà sản xuất / đơn vị đóng gói)."""

    def __init__(self, parent):
        super().__init__(parent)
        self.vars = {k: tk.StringVar() for k, *_ in ie.FIELDS}
        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        left = ttk.Frame(self)
        left.grid(row=0, column=0, rowspan=2, sticky="nsew", padx=(0, 4))
        self._group(left, "chung", with_today=True)
        r1 = ttk.Frame(self)
        r1.grid(row=0, column=1, sticky="nsew", padx=(4, 0))
        self._group(r1, "nsx")
        r2 = ttk.Frame(self)
        r2.grid(row=1, column=1, sticky="nsew", padx=(4, 0), pady=(4, 0))
        self._group(r2, "dg")

    _group = InfoWindow._group

    def get(self):
        return ie.clean_values({k: v.get() for k, v in self.vars.items()})

    def set(self, values):
        values = values or {}
        for k, v in self.vars.items():
            v.set(values.get(k, ""))


class GroupInfoDialog(tk.Toplevel):
    """Mỗi nhóm một bảng info riêng. groups: list dict {gid, label, members, color}; tables: {gid: {khóa: giá trị}}."""

    def __init__(self, master, settings, groups, tables, source_text="", template_info=None):
        super().__init__(master)
        self.title("Điền info các nhóm gộp")
        self.geometry("1060x760")
        self.minsize(960, 640)
        self.settings = settings
        self.groups = groups
        self.template_info = dict(template_info or {})
        self.tables = {g["gid"]: dict((tables or {}).get(g["gid"], {})) for g in groups}
        if self.template_info:                 # nhóm chưa có info -> điền sẵn info đọc từ file mẫu
            for g in groups:
                if not ie.clean_values(self.tables[g["gid"]]):
                    self.tables[g["gid"]] = dict(self.template_info)
        self.result = None
        self.cur = None
        self.preset_var = tk.StringVar()
        self.copy_var = tk.StringVar()
        self._build(source_text)
        if groups:
            self.tree.selection_set(groups[0]["gid"])
            self._on_select()
        self.transient(master)
        self.grab_set()

    def _build(self, source_text):
        ttk.Label(self, wraplength=1020, justify="left", foreground="#555", text=(
            "Mỗi nhóm có một bảng info riêng; khi dựng, file của nhóm nào được điền info của nhóm đó. "
            "%s Ô để trống = giữ nguyên giá trị trong form mẫu. Số điện thoại và ngày ký ghi dạng văn bản." % source_text)
                  ).pack(fill="x", padx=12, pady=(10, 4))
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True, padx=12, pady=4)
        lf = ttk.LabelFrame(body, text="Các nhóm")
        lf.pack(side="left", fill="y", padx=(0, 8))
        self.tree = ttk.Treeview(lf, columns=("nhom", "sheets", "n"), show="headings", height=14, selectmode="browse")
        self.tree.heading("nhom", text="Nhóm")
        self.tree.heading("sheets", text="Sheet")
        self.tree.heading("n", text="Đã nhập")
        self.tree.column("nhom", width=90, anchor="w", stretch=False)
        self.tree.column("sheets", width=170, anchor="w")
        self.tree.column("n", width=60, anchor="center", stretch=False)
        for i, g in enumerate(self.groups):
            tag = "c%d" % i
            if g.get("color"):
                self.tree.tag_configure(tag, background=g["color"])
            self.tree.insert("", "end", iid=g["gid"], tags=(tag,) if g.get("color") else (),
                             values=(g["label"], eng_sheet_text(g["members"]), self._count(g["gid"])))
        self.tree.pack(fill="y", expand=True, padx=6, pady=6)
        self.tree.bind("<<TreeviewSelect>>", lambda _e: self._on_select())

        right = ttk.Frame(body)
        right.pack(side="left", fill="both", expand=True)
        self.title_label = ttk.Label(right, text="", font=("Segoe UI", 10, "bold"))
        self.title_label.pack(anchor="w", pady=(0, 4))
        self.form = InfoForm(right)
        self.form.pack(fill="x")

        tools = ttk.LabelFrame(right, text="Làm nhanh")
        tools.pack(fill="x", pady=8)
        r1 = ttk.Frame(tools)
        r1.pack(fill="x", padx=8, pady=(6, 2))
        ttk.Label(r1, text="Sao chép từ nhóm:").pack(side="left")
        self.copy_cb = ttk.Combobox(r1, textvariable=self.copy_var, state="readonly", width=22,
                                    values=[g["label"] for g in self.groups])
        self.copy_cb.pack(side="left", padx=6)
        ttk.Button(r1, text="Sao chép", command=self._copy_from).pack(side="left")
        ttk.Button(r1, text="Áp dụng cho TẤT CẢ nhóm khác", command=self._apply_all).pack(side="left", padx=12)
        ttk.Button(r1, text="Xóa trắng nhóm này", command=lambda: self.form.set({})).pack(side="left")
        r1b = ttk.Frame(tools)
        r1b.pack(fill="x", padx=8, pady=2)
        st = "normal" if self.template_info else "disabled"
        ttk.Button(r1b, text="Lấy info từ file mẫu cho nhóm này", command=self._from_template, state=st).pack(side="left")
        ttk.Button(r1b, text="Lấy info từ file mẫu cho TẤT CẢ nhóm", command=self._from_template_all, state=st).pack(side="left", padx=8)
        ttk.Label(r1b, text=("(nhóm chưa nhập gì được điền sẵn từ file mẫu)" if self.template_info
                             else "(file mẫu chưa có info)"), foreground="#777").pack(side="left")
        r2 = ttk.Frame(tools)
        r2.pack(fill="x", padx=8, pady=(2, 6))
        ttk.Label(r2, text="Mẫu đã lưu:").pack(side="left")
        self.preset_cb = ttk.Combobox(r2, textvariable=self.preset_var, state="readonly", width=28,
                                      values=sorted(self.settings.get("info_presets", {})))
        self.preset_cb.pack(side="left", padx=6)
        ttk.Button(r2, text="Dùng mẫu cho nhóm này", command=self._use_preset).pack(side="left")
        ttk.Button(r2, text="Lưu nhóm này thành mẫu…", command=self._save_preset).pack(side="left", padx=8)
        ttk.Button(r2, text="Xóa mẫu", command=self._del_preset).pack(side="left")

        bb = ttk.Frame(self)
        bb.pack(fill="x", padx=12, pady=(4, 10))
        ttk.Button(bb, text="Đồng ý", command=self._ok).pack(side="right")
        ttk.Button(bb, text="Hủy", command=self.destroy).pack(side="right", padx=8)
        self.warn_label = ttk.Label(bb, text="", foreground="#B45F06")
        self.warn_label.pack(side="left")

    # ------------------------------------------------------------------
    def _count(self, gid):
        return len(ie.clean_values(self.tables.get(gid, {})))

    def _group(self, gid):
        return next(g for g in self.groups if g["gid"] == gid)

    def _store_current(self):
        if self.cur is not None:
            self.tables[self.cur] = self.form.get()
            self.tree.set(self.cur, "n", self._count(self.cur))

    def _on_select(self):
        sel = self.tree.selection()
        if not sel or sel[0] == self.cur:
            return
        self._store_current()
        self.cur = sel[0]
        g = self._group(self.cur)
        self.form.set(self.tables.get(self.cur, {}))
        self.title_label.config(text="%s  —  %s" % (g["label"], eng_sheet_text(g["members"], 90)))
        self.copy_cb.config(values=[x["label"] for x in self.groups if x["gid"] != self.cur])

    def _copy_from(self):
        self._store_current()
        src = next((g for g in self.groups if g["label"] == self.copy_var.get()), None)
        if src:
            self.form.set(self.tables.get(src["gid"], {}))

    def _from_template(self):
        if self.template_info:
            self.form.set(self.template_info)

    def _from_template_all(self):
        if not self.template_info:
            return
        if not messagebox.askyesno("Lấy info từ file mẫu", "Ghi đè info của MỌI nhóm bằng info đọc từ file mẫu?", parent=self):
            return
        for g in self.groups:
            self.tables[g["gid"]] = dict(self.template_info)
            self.tree.set(g["gid"], "n", self._count(g["gid"]))
        self.form.set(self.template_info)

    def _apply_all(self):
        if self.cur is None:
            return
        vals = self.form.get()
        if not vals:
            messagebox.showinfo("Áp dụng", "Nhóm này chưa nhập thông tin nào.", parent=self)
            return
        if not messagebox.askyesno("Áp dụng cho tất cả nhóm",
                                   "Ghi đè info của MỌI nhóm khác bằng info đang nhập ở nhóm này?", parent=self):
            return
        self._store_current()
        for g in self.groups:
            self.tables[g["gid"]] = dict(vals)
            self.tree.set(g["gid"], "n", self._count(g["gid"]))

    def _use_preset(self):
        p = self.settings.get("info_presets", {}).get(self.preset_var.get())
        if p:
            self.form.set(p)

    def _save_preset(self):
        vals = self.form.get()
        if not vals:
            messagebox.showinfo("Lưu mẫu", "Chưa nhập thông tin nào để lưu.", parent=self)
            return
        from tkinter import simpledialog
        name = simpledialog.askstring("Lưu mẫu", "Tên mẫu (vd: tên công ty):", parent=self)
        if not name or not name.strip():
            return
        self.settings.setdefault("info_presets", {})[name.strip()] = vals
        eng.save_settings(self.settings)
        self.preset_cb.config(values=sorted(self.settings["info_presets"]))
        self.preset_var.set(name.strip())

    def _del_preset(self):
        name = self.preset_var.get()
        if name and name in self.settings.get("info_presets", {}):
            del self.settings["info_presets"][name]
            eng.save_settings(self.settings)
            self.preset_cb.config(values=sorted(self.settings["info_presets"]))
            self.preset_var.set("")

    def _ok(self):
        self._store_current()
        warns = []
        for g in self.groups:
            for w in ie.validate(self.tables.get(g["gid"], {})):
                warns.append("%s: %s" % (g["label"], w))
        if warns and not messagebox.askyesno("Kiểm tra", "Lưu ý:\n  " + "\n  ".join(warns[:8]) + "\n\nVẫn lưu?", parent=self):
            return
        self.result = {g["gid"]: ie.clean_values(self.tables.get(g["gid"], {})) for g in self.groups}
        self.destroy()


def eng_sheet_text(names, max_len=40):
    return eng.sheet_list_text(names, max_len)
