# -*- coding: utf-8 -*-
"""
Làm sạch TÊN THÀNH PHẦN - dùng chung cho mọi bước: đọc file khách hàng (Excel/CSV/Word/PDF), nạp file BTP, ghi
vào Form dựng mẫu và đối chiếu ngưỡng. Chỉ sửa "rác định dạng", KHÔNG đổi tên sang tên khác (không tự đổi 'Aqua' thành
'Water', không sửa chính tả) để tên ghi vào hồ sơ vẫn đúng như khách cung cấp.

clean_name(raw)       -> tên đã làm sạch
split_name_pct(name)  -> (tên, hàm lượng dạng chữ | "")  tách phần '5%' dính cuối tên ("Glycerin 5%", "Glycerin (5 %)")
"""
import re
import unicodedata

_ZW = re.compile("[\u200b\u200c\u200d\u2060\ufeff\u00ad]")
_CTRL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")
_SUPER = re.compile(r"[\u00b9\u00b2\u00b3\u2070-\u2079]+\s*$")
_DASHES = str.maketrans({"\u2010": "-", "\u2011": "-", "\u2012": "-", "\u2013": "-", "\u2014": "-", "\u2212": "-"})
_LEAD = re.compile(r"^\s*(?:\(?\d{1,3}[.)]\s+(?=[A-Za-z(\[])|[\u2022\u00b7\u25cf\u25aa\u25a0*\-\u2013\u2014]\s+)")
_FOOT = re.compile(r"\s*[\(\[]\s*(?:\d{1,2}|\*+|\u2020|\u2021)\s*[\)\]]\s*$")
_TRAIL_MARK = re.compile(r"[\s*\u2020\u2021\u00a7#]+$")
_CI = re.compile(r"(?i)\bC\.?\s?I\.?\s*(\d{5})(?::(\d))?\b")
_HYPHEN_WRAP = re.compile(r"(?<=[A-Za-z0-9])-\s+(?=[A-Za-z0-9])")
_PCT_TAIL = re.compile(r"^(?P<n>.*?[A-Za-z].*?)[\s:,;\-]*[\(\[]?\s*(?P<p>\d{1,3}(?:[.,]\d+)?)\s*%\s*[\)\]]?\s*$")


def clean_name(raw):
    if raw is None:
        return ""
    s = str(raw)
    s = s.replace("\r", " ").replace("\n", " ").replace("\t", " ").replace("\xa0", " ")
    s = _CTRL.sub("", _ZW.sub("", s))
    s = _SUPER.sub("", s)                                   # ¹ ² ³ ở cuối (chú thích) - bỏ TRƯỚC khi NFKC đổi thành 1 2 3
    s = unicodedata.normalize("NFKC", s).translate(_DASHES)
    for _ in range(2):                                      # vài lớp ký hiệu chồng nhau, vd "1. • Glycerin"
        s2 = _LEAD.sub("", s)
        if s2 == s:
            break
        s = s2
    s = _HYPHEN_WRAP.sub("-", s)                            # "4- HYDROXY" (đứt dòng sau dấu gạch) -> "4-HYDROXY"
    s = _CI.sub(lambda m: "CI %s%s" % (m.group(1), (":" + m.group(2)) if m.group(2) else ""), s)
    s = re.sub(r"\(\s*\)", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    for _ in range(3):
        before = s
        s = _FOOT.sub("", s)
        s = _TRAIL_MARK.sub("", s)
        s = s.rstrip(" .,;:").strip()
        if s == before:
            break
    return s


def split_name_pct(name):
    """'Glycerin 5%' -> ('Glycerin', '5'); không có % dính cuối -> (name, '')."""
    m = _PCT_TAIL.match(name or "")
    if m:
        return clean_name(m.group("n")), m.group("p")
    return name, ""
