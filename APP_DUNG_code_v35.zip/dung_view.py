# -*- coding: utf-8 -*-
"""Cửa sổ "Dựng BTP": chọn tính năng, chọn sheet sản phẩm, dựng hàng loạt file mẫu."""
import os
import subprocess
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import dung_engine as eng
import info_engine
import info_view
import ui_kit
import reg_engine
import reg_view

CHK, UNCHK = "☑", "☐"
# màu nhóm: lấy đúng bảng màu pastel tô tab của macro gop_2
GROUP_COLORS = ["#8EA9DB", "#A9D08E", "#FFD966", "#B4A7D6", "#9CC2E6", "#F4B183", "#FF99CC", "#BFBFBF", "#76A5AF", "#D9EAD3"]


class DungWindow(tk.Toplevel):
    def __init__(self, master, btp_path, sheets, settings, on_open_check=None, on_open_info=None):
        super().__init__(master)
        self.title("Dựng BTP")
        self.geometry("1020x900")
        self.minsize(900, 720)

        self.settings = settings
        self.on_open_check = on_open_check
        self.on_open_info = on_open_info
        self.rules = eng.builtin_rules()
        self.btp_path = ""
        self.prod = []
        self.selected = set()
        self.result_paths = []

        self.template_var = tk.StringVar(value=settings.get("template", ""))
        self.out_var = tk.StringVar(value=settings.get("out_dir", ""))
        self.opt_name = tk.BooleanVar(value=True)
        self.opt_ing = tk.BooleanVar(value=True)
        self.opt_notes = tk.BooleanVar(value=True)         # điền ghi chú theo Bảng Ghi chú vào cột D sheet 4
        self.opt_cd = tk.BooleanVar(value=True)
        self.opt_cd_ext = tk.BooleanVar(value=False)      # dùng file công dụng lẻ bên ngoài
        self.ext_cd_path = settings.get("congdung_ext_path", "")
        self.ext_cd_entries = []
        self.opt_chk = tk.BooleanVar(value=True)
        self.opt_nodup = tk.BooleanVar(value=True)
        self.opt_onlypct = tk.BooleanVar(value=False)
        self._ngtag = {}                       # tên sheet -> mã màu kiểm tra ngưỡng (bad/warn/ok)
        self.group_units = 0                   # số file sẽ tạo ở chế độ gộp nhóm
        self.mode_var = tk.StringVar(value=eng.MODE_EACH)
        self.default_cd_var = tk.StringVar(value=settings.get("default_congdung", ""))
        self.group_of = {}                     # tên sheet -> số nhóm (chế độ gộp theo nhóm)
        self._tab_tags = set()                 # các tag màu tab đã tạo trong bảng sheet
        self.opt_info = tk.BooleanVar(value=bool(settings.get("opt_info_groups", False)))
        self.info_src_var = tk.StringVar(value=settings.get("info_groups_source", eng.INFO_SRC_GOP))
        self.template_info = {}                # info đọc từ file mẫu (khóa trường -> giá trị)
        self._tpl_key = None
        self.info_tables = dict(settings.get("info_group_tables", {}))     # {gid nhóm: {khóa trường: giá trị}}

        self._build_ui()
        self.set_sheets(btp_path, sheets)
        self._on_mode()
        self._load_template_info()

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        pad = {"padx": 10, "pady": 4}

        top = ttk.Frame(self)
        top.pack(fill="x", **pad)
        self.btp_label = ttk.Label(top, text="", font=("Segoe UI", 10, "bold"))
        self.btp_label.pack(side="left")

        # --- file & thư mục
        box = ttk.LabelFrame(self, text="1. File mẫu và thư mục lưu")
        box.pack(fill="x", **pad)
        box.columnconfigure(1, weight=1)
        ttk.Label(box, text="File Form dựng mẫu (template):").grid(row=0, column=0, sticky="w", padx=8, pady=4)
        tpl_entry = ttk.Entry(box, textvariable=self.template_var)
        tpl_entry.grid(row=0, column=1, sticky="ew", padx=4)
        tpl_entry.bind("<FocusOut>", lambda _e: self._load_template_info())
        tpl_entry.bind("<Return>", lambda _e: self._load_template_info())
        ttk.Button(box, text="Chọn…", command=self._pick_template).grid(row=0, column=2, padx=8)
        self.tpl_info_label = ttk.Label(box, text="", foreground="#555", font=("Segoe UI", 8), wraplength=900, justify="left")
        self.tpl_info_label.grid(row=2, column=0, columnspan=3, sticky="w", padx=8, pady=(0, 4))
        ttk.Label(box, text="Thư mục lưu file kết quả:").grid(row=1, column=0, sticky="w", padx=8, pady=4)
        ttk.Entry(box, textvariable=self.out_var).grid(row=1, column=1, sticky="ew", padx=4)
        ttk.Button(box, text="Chọn…", command=self._pick_out).grid(row=1, column=2, padx=8)

        # --- chế độ dựng
        mb = ttk.LabelFrame(self, text="2. Chế độ dựng")
        mb.pack(fill="x", **pad)
        modes = [
            (eng.MODE_EACH, "Mỗi sheet một file (mặc định)"),
            (eng.MODE_MERGE, "Gộp các sheet đã chọn thành MỘT file "
                             "(thành phần trùng tên được cộng dồn hàm lượng)"),
            (eng.MODE_GROUP, "Gộp theo nhóm (macro DungGop): các sheet cùng bộ thành phần (không tính chất tạo màu CI) "
                             "vào chung một file"),
        ]
        for val, text in modes:
            ttk.Radiobutton(mb, text=text, value=val, variable=self.mode_var,
                            command=self._on_mode).pack(anchor="w", padx=10, pady=1)
        self.grp_box = ttk.Frame(mb)
        self.grp_box.pack(fill="x", padx=30, pady=(0, 6))
        self.grp_note = ttk.Label(self.grp_box, foreground="#666", font=("Segoe UI", 8), justify="left", wraplength=900, text=(
            "Nhóm gộp: tên sản phẩm lấy từ sheet đầu và bỏ phần mã màu; mã màu từng sheet ghi ở cột E (Dạng hoặc màu) của sheet 4 và ô B3; "
            "tên file 'Gop <liệt kê các sheet, vd 1,2,10,22> - <tên>'. Sheet không có sheet cùng thành phần được dựng riêng '<sheet> - <tên>'. "
            "Cột Nhóm / màu dòng bên dưới cho biết sheet nào vào cùng file (bảng màu tab của macro gop). "
            "Macro DungGop không điền Công dụng nên ô 'Điền Công dụng' tự bỏ tích khi chọn chế độ này."))
        self.grp_note.pack(anchor="w")

        # --- tính năng
        fb = ttk.LabelFrame(self, text="3. Tính năng cần chạy")
        fb.pack(fill="x", **pad)
        feats = [
            (self.opt_name, "Ghi tên sản phẩm vào ô I2 (tự bỏ số thứ tự đứng đầu tên sheet)"),
            (self.opt_ing, "Nạp danh sách thành phần vào sheet 4 (STT + cột C, D, E của BTP; "
                           "Times New Roman 13, kẻ khung)"),
            (self.opt_notes, "Điền ghi chú theo tên thành phần vào cột D sheet 4 (từ dòng 5) theo 'Bảng Ghi chú' - "
                             "ô cột E của BTP đã có chữ thì giữ nguyên"),
            (self.opt_cd, "Điền Công dụng vào ô B32 (tra theo tên sản phẩm / tên sheet)"),
            (self.opt_chk, "Tự tích Có/Không ở I4:I30 theo từ khóa và theo danh sách thành phần (ô trống -> Không)"),
            (self.opt_onlypct, "Chỉ ghi % cho chất có giới hạn / cấm / chưa xác định (chất không giới hạn để trống % - theo bộ kiểm tra ngưỡng)"),
            (self.opt_nodup, "Không ghi đè file trùng tên (thêm hậu tố (2), (3)…)"),
        ]
        for var, text in feats:
            if var is self.opt_cd:
                row = ttk.Frame(fb)
                row.pack(fill="x", padx=10, pady=1)
                ttk.Checkbutton(row, text=text, variable=var).pack(side="left")
                ttk.Checkbutton(row, text="Nạp file công dụng lẻ bên ngoài", variable=self.opt_cd_ext,
                                command=self._on_ext_cd).pack(side="left", padx=(24, 0))
                ttk.Button(row, text="Chọn file…", command=self._pick_ext_cd).pack(side="left", padx=6)
                self.ext_cd_label = ttk.Label(row, text="", foreground="#555")
                self.ext_cd_label.pack(side="left")
                continue
            ttk.Checkbutton(fb, text=text, variable=var).pack(anchor="w", padx=10, pady=1)
        # --- info riêng cho từng nhóm
        ib = ttk.Frame(fb)
        ib.pack(fill="x", padx=10, pady=(4, 0))
        ttk.Checkbutton(ib, text="Điền info các nhóm gộp (mỗi nhóm một bảng info riêng: công ty, nhà sản xuất, đơn vị đóng gói…)",
                        variable=self.opt_info, command=self._on_info_toggle).pack(anchor="w")
        ib2 = ttk.Frame(fb)
        ib2.pack(fill="x", padx=34, pady=(0, 2))
        ttk.Label(ib2, text="Chia nhóm theo:").pack(side="left")
        ttk.Radiobutton(ib2, text="nhóm gộp (cùng bộ thành phần, mục 2)", value=eng.INFO_SRC_GOP,
                        variable=self.info_src_var, command=self._on_info_toggle).pack(side="left", padx=(6, 0))
        ttk.Radiobutton(ib2, text="màu tab sheet trong file BTP", value=eng.INFO_SRC_COLOR,
                        variable=self.info_src_var, command=self._on_info_toggle).pack(side="left", padx=(10, 0))
        self.info_btn_edit = ttk.Button(ib2, text="Nhập info các nhóm…", command=self._edit_info)
        self.info_btn_edit.pack(side="left", padx=14)
        self.info_summary = ttk.Label(ib2, text="", foreground="#555")
        self.info_summary.pack(side="left")
        df = ttk.Frame(fb)
        df.pack(fill="x", padx=10, pady=(2, 6))
        df.columnconfigure(1, weight=1)
        ttk.Label(df, text="Công dụng mặc định khi không khớp (tuỳ chọn):").grid(row=0, column=0, sticky="w")
        ttk.Entry(df, textvariable=self.default_cd_var).grid(row=0, column=1, sticky="ew", padx=6)

        # --- chọn sheet
        sb = ttk.LabelFrame(self, text="4. Chọn sheet sản phẩm (bấm vào dòng để tích / bỏ tích)")
        sb.pack(fill="both", expand=True, **pad)
        bar = ttk.Frame(sb)
        bar.pack(fill="x", padx=8, pady=(4, 0))
        ttk.Button(bar, text="Chọn tất cả", command=lambda: self._select_all(True)).pack(side="left")
        ttk.Button(bar, text="Bỏ chọn tất cả", command=lambda: self._select_all(False)).pack(side="left", padx=6)
        self.count_label = ttk.Label(bar, text="")
        self.count_label.pack(side="right")

        holder = ttk.Frame(sb)
        holder.pack(fill="both", expand=True, padx=8, pady=6)
        cols = ("chon", "sheet", "ten", "nhom", "tp", "ng")
        self.tree = ttk.Treeview(holder, columns=cols, show="headings", height=8, selectmode="none")
        self.tree.heading("chon", text="")
        self.tree.heading("sheet", text="Sheet")
        self.tree.heading("ten", text="Tên sản phẩm (sau khi bỏ STT)")
        self.tree.heading("nhom", text="Nhóm")
        self.tree.heading("tp", text="Số TP")
        self.tree.heading("ng", text="Ngưỡng (Annex) - bấm đúp để xem chi tiết")
        self.tree.column("chon", width=40, anchor="center", stretch=False)
        self.tree.column("sheet", width=90, anchor="w", stretch=False)
        self.tree.column("ten", width=330, anchor="w")
        self.tree.column("nhom", width=70, anchor="center", stretch=False)
        self.tree.column("tp", width=55, anchor="center", stretch=False)
        self.tree.column("ng", width=300, anchor="w")
        self.tree.tag_configure("bad", foreground="#B00020")
        self.tree.tag_configure("warn", foreground="#B45F06")
        for i, col in enumerate(GROUP_COLORS):
            self.tree.tag_configure("g%d" % i, background=col)
        self.tree.bind("<Double-Button-1>", self._on_tree_double)
        vs = ttk.Scrollbar(holder, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vs.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vs.pack(side="right", fill="y")
        self.tree.bind("<Button-1>", self._on_tree_click)

        # --- chạy + nhật ký
        rb2 = ttk.Frame(self)
        rb2.pack(fill="x", **pad)
        self.run_btn = ui_kit.PrimaryButton(rb2, text="Dựng file", command=self.run, width=16, font_size=12)
        self.run_btn.pack(side="left", ipady=3)
        self.progress = ttk.Progressbar(rb2, mode="determinate")
        self.progress.pack(side="left", fill="x", expand=True, padx=10)
        self.open_btn = ttk.Button(rb2, text="Mở thư mục kết quả", command=self._open_folder, state="disabled")
        self.open_btn.pack(side="right")
        self.check_btn = ttk.Button(rb2, text="Check Có / Không các file vừa dựng",
                                    command=self._open_check, state="disabled")
        self.check_btn.pack(side="right", padx=6)
        self.info_btn = ttk.Button(rb2, text="Thay đổi Info các file vừa dựng",
                                   command=self._open_info, state="disabled")
        self.info_btn.pack(side="right")

        lf = ttk.Frame(self)
        lf.pack(fill="both", expand=True, padx=10, pady=(0, 8))
        self.log = tk.Text(lf, height=9, wrap="word", state="disabled", font=("Consolas", 9))
        ls = ttk.Scrollbar(lf, orient="vertical", command=self.log.yview)
        self.log.configure(yscrollcommand=ls.set)
        self.log.pack(side="left", fill="both", expand=True)
        ls.pack(side="right", fill="y")
        self.log.tag_configure("ok", foreground="#0B7A2B")
        self.log.tag_configure("err", foreground="#B00020")
        self.log.tag_configure("info", foreground="#555555")

    # ------------------------------------------------------------ dữ liệu
    def set_sheets(self, btp_path, sheets):
        """Nạp (hoặc nạp lại) danh sách sheet từ file BTP."""
        self.btp_path = btp_path
        self._all_sheets = sheets
        self.prod = eng.product_sheets(sheets)
        self.selected = {s.name for s in self.prod}
        self.tree.delete(*self.tree.get_children())
        self._thr_ctx = {"mix_ratio": self._mix_ratio()}
        for s in self.prod:
            ng, ngtag = reg_view.summary_text(reg_engine.check_formula(
                reg_engine.get_db(), [(c, d) for c, d, _e in s.ingredients if c is not None and str(c).strip()], self._thr_ctx))
            self._ngtag[s.name] = ngtag if ngtag in ("bad", "warn") else ""
            self.tree.insert("", "end", iid=s.name, tags=(self._ngtag[s.name],) if self._ngtag[s.name] else (),
                             values=(CHK, s.name, s.product, "", len(s.ingredients), ng))
        skipped = [s.name for s in sheets if not eng.is_product_sheet(s.name)]
        txt = "File BTP: %s  —  %d sheet sản phẩm" % (os.path.basename(btp_path), len(self.prod))
        if skipped:
            txt += "  (bỏ qua: %s)" % ", ".join(skipped[:6])
        self.btp_label.config(text=txt)
        self._update_count()

    def _mix_ratio(self):
        try:
            return max(float(str(self.settings.get("reg_mix", "0")).replace(",", ".") or 0), 0.0)
        except ValueError:
            return 0.0

    def _on_tree_double(self, e):
        if self.tree.identify_region(e.x, e.y) != "cell":
            return
        iid = self.tree.identify_row(e.y)
        sh = next((s for s in self.prod if s.name == iid), None)
        if sh:
            rows = [(c, d) for c, d, _e2 in sh.ingredients if c is not None and str(c).strip()]
            reg_view.ThresholdDialog(self, self.settings, "%s - %s" % (sh.name, sh.product), rows,
                                     on_change=lambda: self.set_sheets(self.btp_path, self._all_sheets))

    def _update_count(self):
        self.count_label.config(text="Đã chọn %d / %d sheet" % (len(self.selected), len(self.prod)))
        self._refresh_groups()

    def _on_mode(self):
        group = self.mode_var.get() == eng.MODE_GROUP
        if group and self.opt_cd.get() and not self.opt_cd_ext.get() and not getattr(self, "_cd_auto_off", False):
            self.opt_cd.set(False)                  # DungGop bỏ bước Công dụng (bật lại thủ công được)
            self._cd_auto_off = True
        if not group:
            self._cd_auto_off = False
        self._refresh_groups()

    def _chosen(self):
        return [s for s in self.prod if s.name in self.selected]

    def _info_groups(self):
        return eng.info_groups(self._chosen(), self.info_src_var.get())

    def _on_info_toggle(self):
        self.settings["opt_info_groups"] = bool(self.opt_info.get())
        self.settings["info_groups_source"] = self.info_src_var.get()
        self._refresh_groups()

    def _tab_tag(self, color):
        tag = "t" + color.lstrip("#")
        if tag not in self._tab_tags:
            self.tree.tag_configure(tag, background=color)
            self._tab_tags.add(tag)
        return tag

    def _refresh_groups(self):
        """Cột Nhóm + màu dòng: sheet nào (trong số đã chọn) vào chung một file khi gộp theo nhóm (đánh số N1, N2... theo thứ tự
        xuất hiện); sheet không có sheet cùng thành phần hiện 'riêng' và được dựng riêng.
        Khi bật 'Điền info các nhóm gộp' cột này hiện nhóm info (theo nhóm gộp hoặc theo màu tab sheet)."""
        self.group_of, label, color = {}, {}, {}
        self.group_units = 0
        if self.mode_var.get() == eng.MODE_GROUP:
            seq = 0
            for grp in eng.group_sheets(self._chosen()):
                if len(grp) == 1:
                    self.group_units += 1
                    label[grp[0].name] = "riêng"
                    continue
                seq += 1
                self.group_units += 1
                for sh in grp:
                    self.group_of[sh.name] = seq
                    label[sh.name] = "N%d" % seq
                    if len(grp) > 1:
                        color[sh.name] = "g%d" % ((seq - 1) % len(GROUP_COLORS))
        summary = ""
        if self.opt_info.get():
            label, color = {}, {}
            groups = self._info_groups()
            filled = 0
            for i, g in enumerate(groups):
                if info_engine.clean_values(self.info_tables.get(g["gid"], {})):
                    filled += 1
                for m in g["members"]:
                    label[m] = g["label"]
                    if g.get("color"):
                        color[m] = self._tab_tag(g["color"])
                    elif g["gid"].startswith("N"):
                        color[m] = "g%d" % ((int(g["gid"][1:]) - 1) % len(GROUP_COLORS))
            summary = "%d nhóm, %d nhóm đã nhập info" % (len(groups), filled)
            if self.info_src_var.get() == eng.INFO_SRC_COLOR and groups and all(g["gid"] == "none" for g in groups):
                summary = "file BTP không có sheet nào tô màu tab"
            self.info_btn_edit.config(state="normal")
        else:
            self.info_btn_edit.config(state="disabled")
        self.info_summary.config(text=summary)
        for s in self.prod:
            self.tree.set(s.name, "nhom", label.get(s.name, ""))
            tags = tuple(t for t in (self._ngtag.get(s.name, ""), color.get(s.name, "")) if t)
            self.tree.item(s.name, tags=tags)

    def _edit_info(self):
        groups = self._info_groups()
        if not groups:
            messagebox.showinfo("Info các nhóm", "Chưa chọn sheet nào.", parent=self)
            return
        src = ("Nhóm chia theo màu tab sheet trong file BTP (sheet không tô màu dồn vào nhóm 'Không màu')."
               if self.info_src_var.get() == eng.INFO_SRC_COLOR else
               "Nhóm chia theo cùng bộ thành phần như 'Gộp theo nhóm' (sheet không có sheet cùng thành phần dồn vào nhóm 'Sheet riêng').")
        self._load_template_info()
        dlg = info_view.GroupInfoDialog(self, self.settings, groups, self.info_tables, src,
                                        template_info=self.template_info)
        self.wait_window(dlg)
        if dlg.result is not None:
            self.info_tables.update(dlg.result)
            self.settings["info_group_tables"] = self.info_tables
            eng.save_settings(self.settings)
            self._refresh_groups()

    # ------------------------------------------------------------ thao tác
    def _load_ext_cd(self, path):
        """Nạp file công dụng ngoài; trả về True nếu đọc được."""
        try:
            self.ext_cd_entries = eng.load_congdung_file(path)
        except Exception as ex:
            self.ext_cd_entries = []
            messagebox.showerror("Không đọc được file công dụng", str(ex), parent=self)
            return False
        self.ext_cd_path = path
        self.settings["congdung_ext_path"] = path
        eng.save_settings(self.settings)
        return True

    def _show_ext_cd(self):
        if self.opt_cd_ext.get() and self.ext_cd_entries:
            self.ext_cd_label.config(text="%s  (%d sản phẩm)" % (os.path.basename(self.ext_cd_path), len(self.ext_cd_entries)))
        else:
            self.ext_cd_label.config(text="")

    def _pick_ext_cd(self):
        p = filedialog.askopenfilename(
            parent=self, title="Chọn file công dụng lẻ (cột Tên sản phẩm + cột Công dụng)",
            initialdir=os.path.dirname(self.ext_cd_path) or None,
            filetypes=[("Excel", "*.xlsx *.xlsm"), ("Tất cả", "*.*")])
        if p and self._load_ext_cd(p):
            self.opt_cd_ext.set(True)
            self.opt_cd.set(True)
        self._show_ext_cd()

    def _on_ext_cd(self):
        """Tích 'Nạp file công dụng lẻ bên ngoài': chưa có file thì mở hộp chọn file; không chọn thì bỏ tích."""
        if self.opt_cd_ext.get():
            if not self.ext_cd_entries:
                if not (self.ext_cd_path and os.path.isfile(self.ext_cd_path) and self._load_ext_cd(self.ext_cd_path)):
                    self._pick_ext_cd()
            if not self.ext_cd_entries:
                self.opt_cd_ext.set(False)
            else:
                self.opt_cd.set(True)             # dùng file ngoài thì phải bật 'Điền Công dụng vào B32'
        self._show_ext_cd()

    def _load_template_info(self):
        """Đọc info sẵn có trong file mẫu (công ty, nhà sản xuất, đơn vị đóng gói, fax…) để điền sẵn vào bảng info các nhóm."""
        path = self.template_var.get().strip()
        try:
            key = (path, os.path.getmtime(path)) if os.path.isfile(path) else (path, None)
        except OSError:
            key = (path, None)
        if key == self._tpl_key:
            return
        self._tpl_key = key
        self.template_info = {}
        text = ""
        if key[1] is not None and path.lower().endswith(info_engine.SUPPORTED):
            try:
                self.template_info = {k: v for k, v in info_engine.read_info(path).items() if v}
            except Exception as ex:
                text = "Không đọc được info trong file mẫu: %s" % ex
            else:
                ti = self.template_info
                if ti:
                    bits = [ti[k] for k in ("co_name", "nsx_name", "dg_name") if ti.get(k)]
                    text = "Đã đọc %d mục info có sẵn trong file mẫu (%s). Dùng ở bảng 'Nhập info các nhóm…'." % (
                        len(ti), "; ".join(bits[:3]) or "chưa có tên công ty")
                else:
                    text = "File mẫu chưa có info nào được điền."
        self.tpl_info_label.config(text=text)

    def _pick_template(self):
        p = filedialog.askopenfilename(
            parent=self, title="Chọn file Form dựng mẫu",
            initialdir=os.path.dirname(self.template_var.get()) or None,
            filetypes=[("Excel", "*.xlsx"), ("Tất cả", "*.*")])
        if p:
            self.template_var.set(p)
            self._load_template_info()

    def _pick_out(self):
        p = filedialog.askdirectory(parent=self, title="Chọn thư mục lưu file kết quả",
                                    initialdir=self.out_var.get() or None)
        if p:
            self.out_var.set(p)

    def _on_tree_click(self, e):
        if self.tree.identify_region(e.x, e.y) != "cell":
            return None
        iid = self.tree.identify_row(e.y)
        if not iid:
            return None
        if iid in self.selected:
            self.selected.discard(iid)
        else:
            self.selected.add(iid)
        self.tree.set(iid, "chon", CHK if iid in self.selected else UNCHK)
        self._update_count()
        return "break"

    def _select_all(self, on):
        self.selected = {s.name for s in self.prod} if on else set()
        for s in self.prod:
            self.tree.set(s.name, "chon", CHK if on else UNCHK)
        self._update_count()

    def _log(self, text, tag="info"):
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n", tag)
        self.log.see("end")
        self.log.configure(state="disabled")

    def _open_folder(self):
        out = self.out_var.get().strip()
        if not os.path.isdir(out):
            return
        if sys.platform.startswith("win"):
            os.startfile(out)                                  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", out])
        else:
            subprocess.Popen(["xdg-open", out])

    def _open_info(self):
        if self.on_open_info and self.result_paths:
            self.on_open_info(list(self.result_paths))

    def _open_check(self):
        if self.on_open_check and self.result_paths:
            self.on_open_check(list(self.result_paths))

    # ------------------------------------------------------------ chạy
    def run(self):
        tpl = self.template_var.get().strip()
        out = self.out_var.get().strip()
        if not os.path.isfile(tpl):
            messagebox.showwarning("Thiếu file mẫu", "Hãy chọn file Form dựng mẫu (template).", parent=self)
            return
        if not out:
            messagebox.showwarning("Thiếu thư mục", "Hãy chọn thư mục lưu file kết quả.", parent=self)
            return
        chosen = [s for s in self.prod if s.name in self.selected]
        if not chosen:
            messagebox.showwarning("Chưa chọn sheet", "Hãy tích chọn ít nhất một sheet sản phẩm.", parent=self)
            return
        opts = eng.Options(fill_name=self.opt_name.get(), fill_ingredients=self.opt_ing.get(),
                           fill_congdung=self.opt_cd.get(), fill_checks=self.opt_chk.get(),
                           fill_notes=self.opt_notes.get(),
                           no_overwrite=self.opt_nodup.get(), mode=self.mode_var.get(),
                           
                           default_congdung=self.default_cd_var.get().strip(),
                           external_congdung=(self.ext_cd_entries if self.opt_cd_ext.get() else None),
                           only_restricted_pct=self.opt_onlypct.get())
        if self.opt_info.get():
            groups = self._info_groups()
            opts.info_by_sheet, opts.info_label_by_sheet = {}, {}
            for g in groups:
                vals = info_engine.clean_values(self.info_tables.get(g["gid"], {}))
                for m in g["members"]:
                    opts.info_label_by_sheet[m] = g["label"]
                    if vals:
                        opts.info_by_sheet[m] = vals
            if not opts.info_by_sheet:
                if messagebox.askyesno("Chưa nhập info", "Bạn đã bật 'Điền info các nhóm gộp' nhưng chưa nhập info cho nhóm nào.\n\n"
                                       "Mở bảng nhập info ngay bây giờ?", parent=self):
                    self._edit_info()
                return
            missing = [g["label"] for g in groups if not info_engine.clean_values(self.info_tables.get(g["gid"], {}))]
            if missing and not messagebox.askyesno("Nhóm chưa có info", "Các nhóm sau chưa nhập info nên sẽ giữ nguyên info của form mẫu:\n  %s\n\nVẫn dựng?" % ", ".join(missing), parent=self):
                return
        if not (opts.fill_name or opts.fill_ingredients or opts.fill_congdung or opts.fill_checks or opts.info_by_sheet):
            messagebox.showwarning("Chưa chọn tính năng",
                                   "Hãy tích ít nhất một tính năng ở mục 3.", parent=self)
            return
        self.settings["opt_info_groups"] = bool(self.opt_info.get())
        self.settings["info_groups_source"] = self.info_src_var.get()
        self.settings["template"] = tpl
        self.settings["out_dir"] = out
        self.settings["default_congdung"] = self.default_cd_var.get().strip()
        eng.save_settings(self.settings)

        self.run_btn.config(state="disabled")
        self.open_btn.config(state="disabled")
        self.check_btn.config(state="disabled")
        self.info_btn.config(state="disabled")
        n_units = (self.group_units if opts.mode == eng.MODE_GROUP
                   else 1 if opts.mode == eng.MODE_MERGE else len(chosen))
        self.progress.config(maximum=max(n_units, 1), value=0)
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")
        mode_txt = {eng.MODE_EACH: "mỗi sheet một file", eng.MODE_MERGE: "gộp %d sheet thành một file" % len(chosen),
                    eng.MODE_GROUP: "gộp theo nhóm (DungGop)"}[opts.mode]
        self._log("Bắt đầu dựng (%s): %d file…" % (mode_txt, n_units))
        self.config(cursor="watch")

        def progress(i, n, name):
            self.progress.config(maximum=max(n, 1))
            self.progress["value"] = i - 1
            self.update_idletasks()

        try:
            results = eng.build_all(chosen, tpl, out, self.rules, opts, progress)
        except Exception as ex:
            self.config(cursor="")
            self.run_btn.config(state="normal")
            messagebox.showerror("Lỗi khi dựng", str(ex), parent=self)
            self._log("LỖI: %s" % ex, "err")
            return
        self.config(cursor="")
        self.progress["value"] = self.progress["maximum"]
        self.run_btn.config(state="normal")

        ok = [r for r in results if not r.error]
        bad = [r for r in results if r.error]
        self.result_paths = [r.path for r in ok]
        for r in results:
            if r.error:
                self._log("✖ %s %s: %s" % ("Sheet" if opts.mode == eng.MODE_EACH else "", r.sheet, r.error), "err")
                continue
            line = "✔ %s" % r.sheet
            if opts.mode != eng.MODE_EACH:
                line += " (%d sheet: %s%s)" % (len(r.members), ", ".join(r.members[:6]),
                                              " …" if len(r.members) > 6 else "")
            line += "  ->  %s" % os.path.basename(r.path)
            parts = []
            if opts.fill_ingredients:
                parts.append("%d thành phần" % r.n_ingredients)
                if opts.fill_notes:
                    parts.append("ghi chú: %d ô" % r.notes_filled)
            if opts.fill_congdung:
                parts.append("công dụng: %s" % (
                    "%s%s (%.2f)" % ("[file ngoài] " if r.congdung_src == "file" else "", r.congdung_key, r.congdung_score) if r.congdung_key
                    else "dùng mặc định (không khớp)" if r.congdung_default
                    else "không khớp (điểm cao nhất %.2f)" % r.congdung_score))
            if opts.fill_checks:
                parts.append("tích Có: %s" % (", ".join("I%d" % x for x in r.ticked) or "không"))
            if r.info_label:
                parts.append("info nhóm %s (%d ô)" % (r.info_label, r.info_cells))
            if parts:
                line += "   |   " + "   |   ".join(parts)
            self._log(line, "ok")
            for why in getattr(r, "check_reasons", []):
                self._log("   · " + why, "info")
            for w in r.warnings:
                self._log("   ! " + w, "info")
        if opts.mode == eng.MODE_GROUP:
            n_merged = sum(1 for r in ok if len(r.members) > 1)
            self._log("(gộp: %d, đơn: %d)" % (n_merged, len(ok) - n_merged), "info")
        self._log("Xong: %d thành công, %d lỗi. Thư mục: %s" % (len(ok), len(bad), out),
                  "ok" if not bad else "err")
        if ok:
            self.open_btn.config(state="normal")
            self.check_btn.config(state="normal" if self.on_open_check else "disabled")
            self.info_btn.config(state="normal" if self.on_open_info else "disabled")
        messagebox.showinfo("Hoàn tất", "Đã dựng %d file.%s" % (
            len(ok), "\nLỗi %d sheet (xem nhật ký)." % len(bad) if bad else ""), parent=self)
