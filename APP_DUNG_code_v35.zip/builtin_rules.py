# -*- coding: utf-8 -*-
"""
Quy tắc TÍCH HỢP SẴN trong app (người dùng không phải nạp/chỉnh).

CONGDUNG : (từ khóa trong tên sản phẩm / tên sheet, nội dung công dụng điền vào ô B32)
CHECKS   : (ô Có/Không, các từ khóa cách nhau dấu phẩy; có từ khóa trong tên SP | công dụng |
            tên thành phần thì ô được tích "Có")

Tạo tự động từ sheet "Thao Tac" bằng tools/cap_nhat_quy_tac.py. Có thể sửa tay trực tiếp.
"""

CONGDUNG = [
    ('CLEANSING FOAM', 'Sữa rửa mặt tạo bọt giúp làm sạch da mặt, giúp loại bỏ bụi bẩn và bã nhờn trên da, giúp da sạch mịn, đồng thời giúp dưỡng ẩm cho da'),
    ('CLEANSER', 'Sản phẩm giúp làm sạch da mặt, giúp loại bỏ bụi bẩn và bã nhờn trên da, giúp da sạch mịn'),
    ('SOOTHING SERUM', 'Sản phẩm dưỡng da giúp dưỡng ẩm cho da, giúp làm dịu da khô, giúp da mềm mại, mịn màng '),
    ('FACIAL MASK', 'Mặt nạ dưỡng da giúp dưỡng ẩm cho da, giúp làm dịu da khô, đồng thời hỗ trợ giúp làm sạch bã nhờn trên da, giúp da mềm mại và mịn màng'),
    ('OIL CONTROL TONER', 'Sản phẩm giúp làm sạch bã nhờn trên da, giúp dưỡng ẩm cho da, hỗ trợ giúp làm dịu da khô, giúp da mềm mại và mịn màng'),
    ('OIL CONTROL LOTION', 'Sản phẩm dưỡng da giúp dưỡng ẩm cho da, hỗ trợ làm dịu da khô, giúp da mềm mại và mịn màng'),
    ('ESSENCE SPRAY', 'Sản phẩm dạng xịt giúp dưỡng ẩm cho da, hỗ trợ làm dịu da khô, giúp da mềm mại và mịn màng '),
    ('CLEANSING MILK', 'Sữa tẩy trang giúp làm sạch bụi bẩn ở trên da, giúp dưỡng ẩm da, giúp da mịn màng.'),
    ('BRIGHTENING BLEACHING GEL', 'Sản phẩm dưỡng da giúp dưỡng ẩm cho da, giúp da mềm mịn, giúp làm trắng da. '),
    ('BRIGHTENING BLEACHING LOTION', 'Sản phẩm dưỡng da giúp dưỡng ẩm cho da, giúp da mềm mịn, giúp làm trắng da. '),
    ('BRIGHTENING BLEACHING MIST', 'Sản phẩm dưỡng da giúp dưỡng ẩm cho da, giúp da mềm mịn, giúp làm trắng da. '),
    ('BRIGHTENING BLEACHING TONER', 'Sản phẩm dưỡng da giúp dưỡng ẩm cho da, giúp da mềm mịn, giúp làm trắng da. '),
    ('ALOE VERA GEL', 'Sản phẩm dưỡng da giúp dưỡng ẩm cho da, giúp da mềm mịn, giúp làm dịu da khô'),
    ('HYALURON LOTION', 'Sản phẩm dưỡng da giúp dưỡng ẩm cho da, giúp da mềm mịn đồng thời giúp chống nhăn da'),
    ('HYALURON MIST', 'Sản phẩm dạng xịt giúp dưỡng ẩm cho da, giúp da mềm mịn đồng thời giúp chống nhăn da'),
    ('REPAIR GEL', 'Sản phẩm dưỡng da giúp dưỡng ẩm cho da, giúp da mềm mịn đồng thời giúp chống nhăn da, giúp làm trắng da'),
    ('REPAIR LOTION', 'Sản phẩm dưỡng da giúp dưỡng ẩm cho da, giúp da mềm mịn đồng thời giúp chống nhăn da, giúp làm trắng da'),
    ('PURIFYING LOTION', 'Sản phẩm dưỡng da giúp dưỡng ẩm cho da, giúp da mềm mịn, giúp làm dịu da khô'),
    ('PURIFYING MIST', 'Sản phẩm dạng xịt giúp dưỡng ẩm cho da, giúp da mềm mịn, giúp làm dịu da khô'),
    ('Brigtening Cream', 'Kem dưỡng chuyên sâu giúp làm sáng da, mờ thâm nám và tàn nhang. Chứa các hoạt chất làm trắng mạnh mẽ kết hợp cùng thành phần làm dịu và dưỡng ẩm, củng cố hàng rào bảo vệ da.'),
    ('Brightening Serum', 'Tinh chất (Serum) dưỡng sáng da, làm đều màu da và hỗ trợ làm mờ các vết thâm sau mụn. Công thức dịu nhẹ, kháng viêm, giúp phục hồi làn da xỉn màu.'),
    ('Cleaning Daily Toner', 'Nước hoa hồng (Toner) sử dụng hàng ngày giúp làm sạch sâu lỗ chân lông, tẩy tế bào chết nhẹ nhàng, kiểm soát bã nhờn và hỗ trợ ngăn ngừa mụn ẩn, mụn đầu đen.'),
    ('Moisturizing Milk Serum', 'Tinh chất dưỡng ẩm dạng sữa với hàm lượng chiết xuất rau má cao, kết hợp phục hồi sâu giúp làm dịu tức thì làn da kích ứng, tổn thương và cấp ẩm tối ưu.'),
    ('Hydrating Cream', 'Kem dưỡng ẩm và làm dịu da chuyên sâu, giảm sưng đỏ, kháng viêm nhờ chiết xuất rau má. Giúp củng cố hàng rào giữ ẩm, mang lại làn da mềm mại, khỏe mạnh.'),
    ('Face Cleansing Gel', 'Gel rửa mặt dịu nhẹ giúp làm sạch bụi bẩn, dầu thừa mà không gây khô căng da. Bổ sung thành phần dưỡng ẩm và làm dịu, phù hợp cho da nhạy cảm.'),
    ('Purifying Cleanser', 'Sữa rửa mặt chiết xuất từ nước gạo giúp làm sạch sâu, thanh lọc làn da đồng thời hỗ trợ dưỡng sáng nhẹ nhàng, mang lại bề mặt da mịn màng, rạng rỡ.'),
    ('Collagen Serum', 'Tinh chất (Serum) cấp nước tầng sâu và bổ sung Collagen giúp tăng độ đàn hồi, ngăn ngừa các dấu hiệu lão hóa sớm, nuôi dưỡng làn da căng bóng, mượt mà.'),
    ('Daily Serum', 'Tinh chất chăm sóc lỗ chân lông hàng ngày, giúp điều tiết tuyến bã nhờn, làm thông thoáng lỗ chân lông, hỗ trợ đẩy mụn ẩn và cải thiện bề mặt da mịn màng.'),
    ('Eye Cream', 'Kem dưỡng vùng mắt chuyên sâu giúp giảm quầng thâm, bọng mắt và cải thiện các nếp nhăn quanh mắt. Hỗ trợ chống lão hóa và dưỡng ẩm cho vùng da mắt nhạy cảm.'),
    ('Repairing & Strengthening Barrier Cream', 'Kem dưỡng phục hồi và củng cố hàng rào bảo vệ da chuyên sâu. Làm dịu nhanh tình trạng da bị tổn thương, kích ứng, khô ráp hoặc sau các liệu trình điều trị.'),
    ('Retinol 0.5 Serum', 'Tinh chất Retinol tinh khiết giúp thúc đẩy quá trình tái tạo tế bào, làm mờ nếp nhăn, cải thiện độ săn chắc của da và làm mịn kết cấu da, chống lão hóa.'),
    ('Oil Clarifying Clay Mask', 'Mặt nạ đất sét kết hợp tràm trà và BHA giúp hút sạch dầu thừa, bã nhìn tích tụ, kháng viêm, làm dịu các nốt mụn sưng và hỗ trợ gom cồi mụn nhanh chóng.'),
    ('SUN CREAM', 'Kem chống nắng phổ rộng SPF 50+ bảo vệ da tối ưu trước tia UV, đồng thời tích hợp hoạt chất dưỡng sáng giúp ngăn ngừa sạm nám, đốm nâu và thâm mụn.'),
    ('Vitamin C Daily Glow Serum', 'Tinh chất Vitamin C sử dụng hàng ngày giúp chống oxy hóa mạnh mẽ, làm sáng đều màu da, mờ vết thâm, kích thích sản sinh collagen cho da rạng rỡ.'),
    ('Rice Hydra Bright Toner', 'Nước hoa hồng (Toner) chiết xuất từ gạo cấp ẩm sâu, làm dịu da tức thì, nuôi dưỡng làn da mềm mại, hỗ trợ dưỡng sáng và cải thiện độ đàn hồi của da.'),
    ('Spf 50+ Cica Color Corrector Cream', 'Kem chống nắng nâng tông và điều chỉnh sắc tố da (Color Corrector), kết hợp chiết xuất rau má giúp làm dịu các vùng da mẩn đỏ, kích ứng, bảo vệ da tối ưu.'),
]

CHECKS = [
    # Số dòng đã đối chiếu với nhãn cột B sheet 1 của Form dựng mẫu (bản v34 sửa các ô bị lệch dòng
    # chép từ sheet "Thao Tac": I14 -> I15, I16 -> I17, I25 -> I26, I27 -> gộp vào I28).
    ('I4', 'kem, nhũ tương, sữa, gel, dầu, lotion, milk, cream, emulsion, mist, toner, toner pad, miếng bông thấm tẩm mỹ phẩm, nước hoa hồng, nước cân bằng da'),
    ('I5', 'mặt nạ, mask, sheet mask'),
    ('I10', 'tắm, gội, shampoo, bath, shower, muối tắm, làm sạch tóc và da đầu'),
    ('I13', 'shampoo, conditioner, chăm sóc tóc'),
    ('I14', 'nhuộm tóc, nhuộm màu tóc, tẩy màu tóc, tẩy tóc, hair color, hair colour, hair dye, hair tint, hair bleach'),
    ('I15', 'uốn tóc, ép tóc, duỗi tóc, giữ nếp tóc, tạo nếp xoăn, waving, hair perm, perm lotion, perm cream, straightening, cold wave'),
    ('I17', 'làm sạch, tẩy trang, cleansing, cleanser, rửa mặt, làm sạch bụi bẩn, bã nhờn'),
    ('I18', 'dưỡng tóc, cung cấp độ ẩm cho tóc, mềm mượt, giảm xơ rối, bồng bềnh'),
    ('I21', 'trang điểm, tô điểm cho mặt, tô điểm cho mắt, eye palette, blush'),
    ('I22', 'son môi, môi, tô điểm cho môi, over glaze'),
    ('I26', 'chống nắng, sunblock, sunscreen, uv'),
    ('I28', 'làm trắng, sáng da, mờ thâm, brightening, bleaching, whitening, niacinamide, arbutin, chống nhăn da, anti-wrinkle, lão hóa, phục hồi, cải thiện nếp nhăn, skin whitening, dưỡng trắng'),
    ('I29', 'chống nhăn, lão hóa, phục hồi, anti-wrinkle, anti-aging, repair, renaturation, peptide'),
]

# Tích theo THÀNH PHẦN: xem loai_sp.py (Annex III + danh sách chất đặc trưng).
# Ghi chú cột E/D (Bảng Ghi chú) -> ô tích
NOTE_CHECKS = [
    ('I14', r'hair colou?rant|hair dye|oxidative'),
]
# Có ô con được tích thì tích luôn ô nhóm cha (dòng 14-19 là các loại thuộc "Sản phẩm chăm sóc tóc")
PARENT_CHECKS = [
    ('I13', ('I14', 'I15', 'I16', 'I18', 'I19')),   # I17 (làm sạch) không kéo theo vì sữa rửa mặt cũng tích I17
]
# Ô được tích theo ô khác thì bỏ tích ô này (khi ô này chỉ được tích do TỪ KHÓA, vd 'cream' trong
# 'A CREAM HAIR PERM' không có nghĩa là kem dùng trên da)
EXCLUDE_IF = [
    ('I4', ('I14', 'I15')),
]
