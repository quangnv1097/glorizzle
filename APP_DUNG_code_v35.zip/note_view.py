# -*- coding: utf-8 -*-
"""Cửa sổ 'Bảng Ghi chú': xem / sửa / bổ sung ghi chú theo tên thành phần (xem note_engine.py)."""
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import dung_engine as eng
import note_engine as ne


class NoteWindow(tk.Toplevel):
    def __init__(self, master, settings=None, on_change=None):
        super().__init__(master)
        self.title("Bảng Ghi chú thành phần")
        self.geometry("820x640")
        self.minsize(640, 460)
        self.settings = settings if settings is not None else {}
        self.on_change = on_change
        self.items = [list(x) for x in ne.load_items()]          # [[tên, ghi chú]]
        self.dirty = False
        self._edit = None
        self.q = tk.StringVar()

        hint = ttk.Label(self, justify="left", wraplength=780, foreground="#444",
                         text="Ghi chú theo tên thành phần (vd Citric acid → pH adjuster). Khi tạo file BTP, ghi chú được ghi vào cột E; "
                              "khi Dựng, ghi chú được ghi vào cột D (từ dòng 5) sheet 4 'Danh sách thành phần'. "
                              "Khớp tên không phân biệt hoa/thường. Bấm đúp vào ô để sửa (Enter: lưu ô, Esc: bỏ, ↑ ↓: sang dòng khác).")
        hint.pack(fill="x", padx=12, pady=(10, 4))
        self.bind("<Configure>", lambda e: hint.config(wraplength=max(300, self.winfo_width() - 40)) if e.widget is self else None)

        top = ttk.Frame(self)
        top.pack(fill="x", padx=12, pady=(2, 4))
        ttk.Label(top, text="Tìm:").pack(side="left")
        ent = ttk.Entry(top, textvariable=self.q, width=28)
        ent.pack(side="left", padx=(4, 12))
        self.q.trace_add("write", lambda *_a: self._render())
        ttk.Button(top, text="Thêm dòng", command=self._add).pack(side="left", padx=2)
        ttk.Button(top, text="Xóa dòng đã chọn", command=self._delete).pack(side="left", padx=2)
        ttk.Button(top, text="Dán từ Excel", command=self._paste).pack(side="left", padx=2)
        ttk.Button(top, text="Nạp từ file Excel…", command=self._import).pack(side="left", padx=2)
        ttk.Button(top, text="Xuất ra Excel…", command=self._export).pack(side="left", padx=2)

        fr = ttk.Frame(self)
        fr.pack(fill="both", expand=True, padx=12, pady=4)
        self.tree = ttk.Treeview(fr, columns=("name", "note"), show="headings", selectmode="extended")
        self.tree.heading("name", text="Tên thành phần")
        self.tree.heading("note", text="Ghi chú")
        self.tree.column("name", width=380, anchor="w")
        self.tree.column("note", width=340, anchor="w")
        self.tree.tag_configure("dup", background="#FFF1D6")
        self.tree.tag_configure("empty", foreground="#999999")
        vs = ttk.Scrollbar(fr, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vs.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vs.pack(side="right", fill="y")
        self.tree.bind("<Double-Button-1>", self._on_dbl)
        self.tree.bind("<Delete>", lambda _e: self._delete())
        self.tree.bind("<Control-v>", lambda _e: self._paste())

        bb = ttk.Frame(self)
        bb.pack(fill="x", padx=12, pady=(4, 10))
        self.info = ttk.Label(bb, text="")
        self.info.pack(side="left")
        ttk.Button(bb, text="Lưu và đóng", command=self._save_close).pack(side="right")
        ttk.Button(bb, text="Lưu", command=self._save).pack(side="right", padx=(0, 8))
        ttk.Button(bb, text="Đóng", command=self._close).pack(side="right", padx=(0, 8))
        ttk.Button(bb, text="Khôi phục bảng mẫu", command=self._reset).pack(side="right", padx=(0, 16))
        self.protocol("WM_DELETE_WINDOW", self._close)
        self._render()
        self.transient(master)
        ent.focus_set()

    # ------------------------------------------------------------ hiển thị
    def _dup_keys(self):
        seen, dup = {}, set()
        for n, t in self.items:
            k = ne.norm_key(n)
            if not k:
                continue
            if k in seen and seen[k] != t:
                dup.add(k)
            seen.setdefault(k, t)
        return dup

    def _render(self):
        self._end_edit(False)
        q = ne.norm_key(self.q.get()) if self.q.get().strip() else ""
        dup = self._dup_keys()
        self.tree.delete(*self.tree.get_children())
        shown = 0
        for i, (n, t) in enumerate(self.items):
            if q and q not in ne.norm_key(n) and q not in ne.norm_key(t):
                continue
            tags = ("dup",) if ne.norm_key(n) in dup else ("empty",) if not t else ()
            self.tree.insert("", "end", iid=str(i), values=(n, t), tags=tags)
            shown += 1
        self._status(shown, len(dup))

    def _status(self, shown=None, ndup=None):
        total = len(self.items)
        filled = sum(1 for n, t in self.items if n.strip() and t.strip())
        txt = "%d dòng (%d có ghi chú)" % (total, filled)
        if shown is not None and shown != total:
            txt += " - đang hiện %d" % shown
        if ndup:
            txt += " - %d tên trùng nhưng ghi chú khác (tô vàng, dòng đầu được dùng)" % ndup
        if self.dirty:
            txt += " - CHƯA LƯU"
        self.info.config(text=txt)

    def _mark(self):
        self.dirty = True
        self._status()

    # ------------------------------------------------------------ sửa trực tiếp
    def _on_dbl(self, e):
        if self.tree.identify_region(e.x, e.y) != "cell":
            return
        iid = self.tree.identify_row(e.y)
        col = self.tree.identify_column(e.x)
        if iid:
            self._begin_edit(iid, 0 if col == "#1" else 1)

    def _begin_edit(self, iid, col):
        self._end_edit(True)
        box = self.tree.bbox(iid, "#%d" % (col + 1))
        if not box:
            return
        x, y, w, h = box
        var = tk.StringVar(value=self.items[int(iid)][col])
        ent = ttk.Entry(self.tree, textvariable=var)
        ent.place(x=x, y=y, width=w, height=h)
        ent.focus_set()
        ent.select_range(0, "end")
        ent.bind("<Return>", lambda _e: self._end_edit(True))
        ent.bind("<Escape>", lambda _e: self._end_edit(False))
        ent.bind("<FocusOut>", lambda _e: self._end_edit(True))
        ent.bind("<Down>", lambda _e: self._move_edit(1))
        ent.bind("<Up>", lambda _e: self._move_edit(-1))
        ent.bind("<Tab>", lambda _e: self._tab_edit())
        self._edit = (iid, col, ent, var)
        self.tree.selection_set(iid)

    def _end_edit(self, commit):
        if not self._edit:
            return None
        iid, col, ent, var = self._edit
        self._edit = None
        text = ne.clean_note(var.get())
        try:
            ent.destroy()
        except tk.TclError:
            pass
        if commit and self.tree.exists(iid) and text != self.items[int(iid)][col]:
            self.items[int(iid)][col] = text
            self.tree.set(iid, "name" if col == 0 else "note", text)
            self._mark()
        return (iid, col)

    def _move_edit(self, step):
        cur = self._end_edit(True)
        if cur:
            kids = list(self.tree.get_children())
            if cur[0] in kids:
                j = kids.index(cur[0]) + step
                if 0 <= j < len(kids):
                    self._begin_edit(kids[j], cur[1])
        return "break"

    def _tab_edit(self):
        cur = self._end_edit(True)
        if cur:
            self._begin_edit(cur[0], 1 - cur[1])
        return "break"

    # ------------------------------------------------------------ thao tác
    def _add(self):
        if self.q.get():
            self.q.set("")
        self.items.append(["", ""])
        self._mark()
        self._render()
        iid = str(len(self.items) - 1)
        self.tree.see(iid)
        self._begin_edit(iid, 0)

    def _delete(self):
        self._end_edit(False)
        sel = sorted((int(i) for i in self.tree.selection()), reverse=True)
        if not sel:
            return
        if len(sel) > 1 and not messagebox.askyesno("Xóa dòng", "Xóa %d dòng đã chọn?" % len(sel), parent=self):
            return
        for i in sel:
            del self.items[i]
        self._mark()
        self._render()

    def _paste(self):
        self._end_edit(False)
        try:
            raw = self.clipboard_get()
        except tk.TclError:
            messagebox.showinfo("Dán từ Excel", "Bộ nhớ tạm đang trống. Hãy chép 2 cột (tên thành phần | ghi chú) trong Excel rồi bấm lại.", parent=self)
            return "break"
        new = []
        for line in raw.replace("\r", "").split("\n"):
            parts = line.split("\t")
            if parts and parts[0].strip():
                new.append((parts[0], parts[1] if len(parts) > 1 else ""))
        new = ne.clean_items(new)
        if not new:
            messagebox.showinfo("Dán từ Excel", "Không có dòng nào để dán (cần 2 cột cách nhau bằng Tab, như khi chép từ Excel).", parent=self)
            return "break"
        self._merge(new, "bộ nhớ tạm")
        return "break"

    def _merge(self, new, source):
        base = [tuple(x) for x in self.items]
        merged, added, updated = ne.merge_items(base, new)
        if not added and not updated:
            messagebox.showinfo("Gộp ghi chú", "Không có gì mới từ %s (%d dòng đều đã có và giống nhau)." % (source, len(new)), parent=self)
            return
        if not messagebox.askyesno("Gộp ghi chú", "Từ %s: thêm %d dòng mới, cập nhật ghi chú của %d dòng đã có.\n\nGộp vào bảng?" % (
                source, added, updated), parent=self):
            return
        self.items = [list(x) for x in merged]
        self._mark()
        self._render()

    def _import(self):
        p = filedialog.askopenfilename(parent=self, title="Chọn file Excel có bảng ghi chú (cột tên | cột ghi chú)",
                                       initialdir=self.settings.get("note_dir") or None,
                                       filetypes=[("Excel", "*.xlsx *.xlsm"), ("Tất cả", "*.*")])
        if not p:
            return
        try:
            new, where = ne.read_xlsx(p)
        except Exception as ex:
            messagebox.showerror("Không đọc được file", "%s\n\n(Nếu file đang mở trong Excel, hãy lưu rồi thử lại.)" % ex, parent=self)
            return
        self.settings["note_dir"] = os.path.dirname(p)
        eng.save_settings(self.settings)
        if not new:
            messagebox.showwarning("Không thấy bảng ghi chú", "Không tìm thấy hai cột liền nhau (tên thành phần | ghi chú ngắn) trong file.", parent=self)
            return
        self._merge(new, "%s (%s)" % (os.path.basename(p), where))

    def _export(self):
        p = filedialog.asksaveasfilename(parent=self, title="Xuất bảng ghi chú", defaultextension=".xlsx",
                                         initialfile="Bang ghi chu.xlsx", filetypes=[("Excel", "*.xlsx")])
        if not p:
            return
        try:
            ne.write_xlsx([tuple(x) for x in self.items], p)
        except Exception as ex:
            messagebox.showerror("Không ghi được", str(ex), parent=self)
            return
        messagebox.showinfo("Đã xuất", "Đã xuất %d dòng." % len(ne.clean_items(self.items)), parent=self)

    def _reset(self):
        if not messagebox.askyesno("Khôi phục bảng mẫu", "Thay toàn bộ bảng hiện tại bằng bảng mẫu có sẵn (%d dòng)? "
                                   "Các dòng bạn đã thêm sẽ mất (chỉ khi bấm Lưu)." % len(ne.DEFAULT_ITEMS), parent=self):
            return
        self.items = [list(x) for x in ne.DEFAULT_ITEMS]
        self._mark()
        self._render()

    # ------------------------------------------------------------ lưu / đóng
    def _save(self):
        self._end_edit(True)
        try:
            saved = ne.save_items([tuple(x) for x in self.items])
        except Exception as ex:
            messagebox.showerror("Không lưu được", str(ex), parent=self)
            return False
        self.items = [list(x) for x in saved]
        self.dirty = False
        self._render()
        if self.on_change:
            self.on_change(len(saved))
        return True

    def _save_close(self):
        if self._save():
            self.destroy()

    def _close(self):
        self._end_edit(True)
        if self.dirty:
            r = messagebox.askyesnocancel("Bảng Ghi chú", "Bảng có thay đổi chưa lưu. Lưu trước khi đóng?", parent=self)
            if r is None:
                return
            if r and not self._save():
                return
        self.destroy()
