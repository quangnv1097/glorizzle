# -*- coding: utf-8 -*-
"""
Tạo file BTP từ dữ liệu khách hàng (Excel/CSV, Word, PDF).

Logic port từ các macro trong "TH_check_TP (Tools).xlsm":
  - excel()                     : Excel/CSV khách hàng -> sheet số
  - ReadWordToExcel()           : bảng trong Word -> sheet số
  - ImportFromPDF_*()           : PDF -> sheet số (macro dùng Word để đổi PDF; app đọc bảng trực tiếp)
  - KiemTraTong100_ToanBoSheet(): tổng hàm lượng = 100, tô hồng tab nếu lệch
  - Xuat_file()                 : xuất các sheet số ra file BTP mới

Cách làm chung: duyệt từng dòng, tìm DÒNG TIÊU ĐỀ có đồng thời cột hàm lượng (%, content, w/w...) và cột
thành phần (INCI, ingredient, thành phần...) trong 15 cột đầu, rồi đọc các dòng bên dưới tới khi gặp
TOTAL/SUM/TỔNG hoặc 10 dòng trống liên tiếp. Mỗi bảng tìm được = một sheet trong file BTP:
    A: "<số>. <tên sản phẩm>" (mọi dòng)   B: STT   C: thành phần   D: hàm lượng (văn bản)
    G: hàm lượng dạng số   H1: "OK (100)" hoặc báo lệch
Sheet đặt tên theo số thứ tự file (1, 2, 3...); bảng thứ hai trở đi trong cùng file là 2.1, 2.2...
"""
import csv
import io
import os
import re
import sys
import unicodedata
import warnings
import xml.etree.ElementTree as ET
import zipfile
from datetime import date, datetime

import name_clean
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font

HEADER_COLS = 15            # chỉ tìm tiêu đề trong 15 cột đầu (giống macro)
MAX_ROWS = 20000
MAX_BLANKS = 10             # 10 dòng trống liên tiếp thì dừng bảng
TOTAL_TOL = 0.01            # sai số khi kiểm tra tổng = 100
SUPPORTED = {".xlsx": "excel", ".xlsm": "excel", ".xls": "excel", ".csv": "csv",
             ".docx": "word", ".pdf": "pdf"}
UNSUPPORTED_HINT = {".doc": "Word cũ (.doc) chưa hỗ trợ - hãy lưu thành .docx",
                    ".xlsb": "Excel .xlsb chưa hỗ trợ - hãy lưu thành .xlsx"}

_ZW = re.compile("[\u200b\u200c\u200d\u2060\ufeff]")
_CTRL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")


class ReadError(ValueError):
    """Không đọc được file. `preview` = các dòng đầu của file để người dùng xem tên cột thực tế."""

    def __init__(self, message, preview=None):
        super().__init__(message)
        self.preview = list(preview or [])


# ----------------------------------------------------------------------------
# Làm sạch chuỗi
# ----------------------------------------------------------------------------
def unaccent_upper(s):
    s = s.replace("Đ", "D").replace("đ", "d")
    s = "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")
    return s.upper()


def clean_cell(s):
    """Làm sạch ô: NBSP -> cách, bỏ ký tự điều khiển / ký tự vô hình, gộp xuống dòng, trim."""
    if s is None:
        return ""
    s = str(s).replace("\xa0", " ").replace("\r", " ").replace("\n", " ").replace("\t", " ")
    s = _CTRL.sub("", _ZW.sub("", s))
    return s.strip()


def clean_ingredient(s):
    """Làm sạch tên thành phần (xem name_clean.py): khoảng trắng, ký tự vô hình, dấu gạch ngang, dấu . , ; ở cuối,
    số thứ tự / ký hiệu đầu dòng, dấu chú thích (* † ¹ (1)), dạng 'C.I. 77891', dấu gạch bị đứt dòng."""
    return name_clean.clean_name(s)


def format_number(v):
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, int):
        return str(v)
    if v != v or v in (float("inf"), float("-inf")):
        return ""
    if float(v).is_integer() and abs(v) < 1e15:
        return str(int(v))
    out = ("%.12f" % v).rstrip("0").rstrip(".")
    return out or "0"


def cell_text(v, number_format=None):
    """Giá trị ô -> chuỗi. Ô số định dạng % (vd 0,0125 hiển thị 1,25%) được nhân 100."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, (int, float)):
        if number_format and "%" in str(number_format):
            return format_number(round(v * 100, 10))
        return format_number(v)
    if isinstance(v, (datetime, date)):
        return str(v)
    return clean_cell(v)


def clean_pct(s):
    """Làm sạch ô hàm lượng như macro (NBSP, ký tự lạ, trim). Giữ nguyên số liệu."""
    return clean_cell(s)


def normalize_pct(text, strip_percent=True, decimal_comma=True):
    """Chuẩn hóa để ghi ra BTP: bỏ ký hiệu %, đổi dấu chấm thập phân thành dấu phẩy."""
    t = clean_cell(text)
    if strip_percent:
        t = re.sub(r"\s*%\s*$", "", t).strip()
    if decimal_comma and re.fullmatch(r"[<>≤≥~]?\s*\d+\.\d+", t):
        t = t.replace(".", ",")
    return t


def parse_pct(text):
    """Chuỗi hàm lượng -> (số, gần_đúng). '<0,1' -> (0.1, True). Khoảng '0,5-1' hoặc chữ -> (None, False)."""
    t = clean_cell(text).replace("%", "").replace(" ", "")
    if not t:
        return None, False
    approx = False
    if t[0] in "<>≤≥~":
        approx, t = True, t[1:]
    t = t.replace(",", ".")
    try:
        return float(t), approx
    except ValueError:
        return None, False


# ----------------------------------------------------------------------------
# Nhận diện dòng tiêu đề
# ----------------------------------------------------------------------------
_PCT_RE = re.compile(r"%|CONTENT|W/W|PERCENT|\bWT\b|CONC|HAM LUONG|TY LE|NONG DO|QUANTITY|AMOUNT|"
                     r"\bQTY\b|\bPCT\b|DOSAGE|DOSAGGIO|\bQUANTITA\b|PHAN TRAM")
_ING_KEYS = ("INCI", "INGREDIENT", "ICID", "THANH PHAN", "TEN CHAT", "NGUYEN LIEU", "COMPONENT",
             "SUBSTANCE", "RAW MATERIAL", "COMPOSANT", "DENOMINATION", "COMPOSITION")


def _norm_hdr(s):
    """Chuẩn hóa để so tên cột: bỏ dấu, IN HOA, chỉ giữ chữ-số-%-/ và gộp khoảng trắng."""
    return " ".join(re.sub(r"[^A-Z0-9%/]+", " ", unaccent_upper(s or "")).split())


class ColumnHints:
    """Tên cột do người dùng nhập (nhiều tên cách nhau dấu phẩy/chấm phẩy/xuống dòng)."""

    def __init__(self, ing=None, pct=None, name=None):
        self.add_colour = True                                                    # PDF nhiều bảng: thêm mã màu vào tên sản phẩm
        self.colour = []                                                          # nhãn mã màu bổ sung (đã chuẩn hóa)
        self.ing = [h for h in (_norm_hdr(x) for x in (ing or [])) if h]
        self.pct = [h for h in (_norm_hdr(x) for x in (pct or [])) if h]
        self.name = [h for h in (_norm_hdr(x) for x in (name or [])) if h]       # từ khóa nhãn chứa tên sản phẩm (vd Description)

    @classmethod
    def from_text(cls, ing_text="", pct_text="", name_text=""):
        split = lambda t: [x for x in re.split(r"[,;\n|]+", t or "") if x.strip()]
        return cls(split(ing_text), split(pct_text), split(name_text))

    def empty(self):
        return not (self.ing or self.pct or self.name)


_INCI_OCR = re.compile(r"\bINC[IL1!|]\s*NAME\b|\b[IL1]NCI\s*NAME\b")    # OCR hay đọc 'INCI NAME' thành 'INCL NAME'


def _is_inci(u):
    return "INCI" in u or "ICID" in u or bool(_INCI_OCR.search(u))


def _inci_score(u):
    if re.search(r"\bEU\b|INCIUE|INCI\s*UE\b|\bUE\b|EUROP", u):
        return 13
    if re.search(r"\bEN\b|\bUS\b|\bUSA\b|INCIUS|INCI\s*US\b", u):
        return 12
    if re.search(r"\bKR\b|\bCN\b", u):
        return 11
    return 10


def detect_roles(cells, hints=None):
    """Trả về (cột %, [các cột thành phần theo thứ tự ưu tiên]) - chỉ số 1-based, 0 / [] nếu không thấy.
    Ưu tiên: tên cột người dùng nhập > cột có chữ ACTUAL (với %) > cột INCI (EU > EN/US > KR/CN) > cột
    'ingredient/thành phần' thường."""
    pct, pct_score = 0, -1
    ings = []
    for c, txt in enumerate(cells[:HEADER_COLS], start=1):
        if not txt:
            continue
        u = unaccent_upper(txt)
        h = _norm_hdr(txt)
        if hints and any(k in h for k in hints.ing):          # người dùng chỉ định cột thành phần
            ings.append((100, c))
            continue
        hint_pct = bool(hints and any(k in h for k in hints.pct))
        if hint_pct or _PCT_RE.search(u):
            sc = 100 if hint_pct else (60 if "ACTUAL" in u else 50)
            if sc > pct_score:
                pct, pct_score = c, sc
            continue
        if "FUNCTION" not in u and (any(k in u for k in _ING_KEYS) or _INCI_OCR.search(u)):
            ings.append(((_inci_score(u) if _is_inci(u) else 0), c))
    ings.sort(key=lambda x: (-x[0], x[1]))
    return pct, [c for _sc, c in ings if c != pct]


def detect_header(cells, hints=None):
    """Như detect_roles nhưng chỉ trả về (cột %, cột thành phần tốt nhất)."""
    pct, cols = detect_roles(cells, hints)
    return pct, (cols[0] if cols else 0)


_TOTAL_RE = re.compile(r"^(TOTAL|SUM|TONG)\b")
_HEADER_WORD = re.compile(r"\bINCI\b")


def _is_total(u):
    return bool(_TOTAL_RE.match(u))


def _is_header_row(u):
    return u == "ICID" or u == "CONTENT" or bool(_HEADER_WORD.search(u))


def extract_tables(grid, hints=None):
    """Tìm các bảng thành phần trong lưới ô (list các list chuỗi). Trả về [(dòng tiêu đề, items)]."""
    out = []
    n = len(grid)
    r = 0
    while r < n:
        pct, ing = detect_header(grid[r], hints)
        if pct and ing and sum(1 for c in grid[r] if _NUM_RE.match(c or "") and re.search(r"[.,]\d", c)) >= 2:
            pct = 0                                             # dòng có >= 2 số thập phân = dữ liệu, không phải tiêu đề
        if pct and ing:
            items, blanks, dr = [], 0, r + 1
            while dr < n:
                row = grid[dr]
                name = clean_ingredient(row[ing - 1]) if ing - 1 < len(row) else ""
                if not name:
                    blanks += 1
                else:
                    u = unaccent_upper(name)
                    if _is_total(u):
                        break
                    if not _is_header_row(u):
                        blanks = 0
                        items.append((name, clean_pct(row[pct - 1]) if pct - 1 < len(row) else ""))
                if blanks >= MAX_BLANKS:
                    break
                dr += 1
            if items:
                out.append((r, items))
                r = dr
                continue
        r += 1
    return out


# ----------------------------------------------------------------------------
# Tên sản phẩm
# ----------------------------------------------------------------------------
_NAME_LABELS = ("PRODUCT NAME", "TEN SAN PHAM")


def _label_match(txt, key):
    """Ô `txt` là nhãn có từ khóa `key` (đã chuẩn hóa)? Trả về (khớp, phần giá trị đứng sau dấu ':' nếu có)."""
    if not txt:
        return False, ""
    if ":" in txt:
        left, right = txt.split(":", 1)
        nl = _norm_hdr(left)
        if nl == key or (key in nl and len(nl) <= len(key) + 25):
            return True, clean_cell(right)
    nt = _norm_hdr(txt)
    if nt == key or (key in nt and len(nt) <= len(key) + 12):
        return True, ""
    return False, ""


def find_name_by_keys(grid, keys, max_rows=200):
    """Tìm tên sản phẩm theo từ khóa người dùng nhập (vd 'Description'): nhãn dạng 'Nhãn: giá trị', nhãn nằm trên giá trị
    (tiêu đề cột rồi dòng dưới) hoặc giá trị ở ô bên phải."""
    for key in keys or []:
        for r, row in enumerate(grid[:max_rows]):
            for c, txt in enumerate(row):
                ok, inline = _label_match(txt, key)
                if not ok:
                    continue
                if inline:
                    return inline
                below = ""
                for rr in range(r + 1, min(r + 4, len(grid))):          # giá trị ở dòng ngay dưới, cùng cột
                    if c < len(grid[rr]) and clean_cell(grid[rr][c]):
                        below = clean_cell(grid[rr][c])
                        break
                right = ""
                for k in range(1, 16):
                    if c + k < len(row) and clean_cell(row[c + k]):
                        right = clean_cell(row[c + k])
                        break
                if txt.strip().endswith(":"):
                    val = right or below
                else:
                    val = below or right
                if val:
                    return val
    return ""


def find_product_name(grid, max_rows=200, keys=None):
    """Tìm ô có nhãn 'Product name' / 'Tên sản phẩm': lấy phần sau dấu ':' hoặc ô không trống bên phải.
    keys: từ khóa do người dùng nhập (được thử TRƯỚC các nhãn mặc định)."""
    if keys:
        found = find_name_by_keys(grid, keys, max_rows)
        if found:
            return found
    for r, row in enumerate(grid[:max_rows]):
        for c, txt in enumerate(row):
            if not txt:
                continue
            u = unaccent_upper(txt)
            if not any(lbl in u for lbl in _NAME_LABELS):
                continue
            if ":" in txt:
                after = clean_cell(txt.split(":", 1)[1])
                if after:
                    return after
            for k in range(1, 16):
                if c + k < len(row) and clean_cell(row[c + k]):
                    return clean_cell(row[c + k])
    return ""


_TITLE_SKIP = re.compile(r"\b(INCI|INGREDIENT|THANH PHAN|NGUYEN LIEU|FORMULA|FORMULATION|COMPOSITION|BANG|TABLE|LIST|"
                         r"TOTAL|TONG|NO\.?|STT|CAS|FUNCTION|REFERENCE|W/W|DATE|NGAY|PAGE|TRANG|COMPANY|CONG TY)\b")


def title_above_table(grid, header_row, max_up=4):
    """Tên sản phẩm KHÔNG có nhãn: dòng tiêu đề (thường là ô gộp) nằm ngay phía trên dòng tiêu đề cột của bảng thành phần.
    Duyệt ngược từ dòng sát bảng, lấy dòng đầu tiên chỉ có MỘT nội dung chữ (ô gộp lặp lại giá trị cũng tính là một)
    và không giống tiêu đề cột / nhãn chung (Formula, Ingredient list, Date...). Trả về "" nếu không có."""
    for r in range(header_row - 1, max(-1, header_row - 1 - max_up), -1):
        vals = []
        for c in grid[r]:
            t = clean_cell(c)
            if t and t not in vals:
                vals.append(t)
        if not vals:
            continue
        if len(vals) != 1:
            return ""                      # dòng nhiều ô khác nhau = không phải tiêu đề đơn
        t = vals[0]
        u = unaccent_upper(t)
        if len(t) < 3 or re.fullmatch(r"[\d.,\s%/\-]+", t) or _TITLE_SKIP.search(u):
            continue
        return t
    return ""


def _is_generic_sheet_name(name):
    u = unaccent_upper(name.strip())
    return bool(re.fullmatch(r"[\d.,\s]+", u)) or u.startswith(("SHEET", "TRANG", "BANG"))


def file_stem(path):
    return os.path.splitext(os.path.basename(path))[0]


# ----------------------------------------------------------------------------
# Kết quả đọc
# ----------------------------------------------------------------------------
class Table:
    def __init__(self, source_path, product, items, source_sheet=""):
        fixed = []
        for n, p in items:
            n2, p2 = name_clean.split_name_pct(n)           # "Glycerin 5%" -> tên "Glycerin", hàm lượng "5" (nếu ô % trống)
            if p2 and not clean_cell(p):
                n, p = n2, p2
            fixed.append((n, p))
        items = _resolve_fill(fixed)                        # "Add to 100" -> 100 - tổng các dòng còn lại
        self.source_path = source_path
        self.source_file = os.path.basename(source_path)
        self.source_sheet = source_sheet
        self.product = product
        self.items = items              # [(tên thành phần, hàm lượng dạng chữ)]
        self.notes = []
        self.selected = True

    def stats(self):
        """(tổng %, số dòng có %, số dòng thiếu %, số dòng không đọc được, có giá trị gần đúng)"""
        total, have, missing, bad, approx_any = 0.0, 0, 0, 0, False
        for _n, p in self.items:
            if not clean_cell(p):
                missing += 1
                continue
            v, approx = parse_pct(p)
            if v is None:
                bad += 1
            else:
                total += v
                have += 1
                approx_any = approx_any or approx
        return total, have, missing, bad, approx_any

    def status(self):
        """(mã, văn bản) - mã: ok | warn."""
        total, have, missing, bad, approx = self.stats()
        msgs = []
        ok = abs(total - 100) <= TOTAL_TOL
        if ok:
            msgs.append("Tổng 100")
        else:
            msgs.append("Tổng %s" % format_number(round(total, 6)))
            if have and 0.99 <= total <= 1.01:
                msgs.append("có vẻ là tỉ lệ thập phân (chưa nhân 100)")
        if missing:
            msgs.append("thiếu hàm lượng ở %d dòng" % missing)
        if bad:
            msgs.append("%d ô hàm lượng không đọc được" % bad)
        if approx:
            msgs.append("có giá trị dạng '<'")
        return ("ok" if ok and not missing and not bad else "warn"), "; ".join(msgs)


def _make_tables(path, product, found, sheet=""):
    return [Table(path, product, items, sheet) for _r, items in found]


# ----------------------------------------------------------------------------
# Excel / CSV
# ----------------------------------------------------------------------------
def _excel_grids(path):
    """Sinh (tên sheet, lưới ô dạng chuỗi) cho mọi sheet."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".xls":
        try:
            import xlrd
        except ImportError:
            raise ValueError("File .xls cần thư viện xlrd (pip install xlrd) hoặc hãy lưu sang .xlsx")
        try:
            book = xlrd.open_workbook(path, formatting_info=True)
            fmt = True
        except Exception:
            book = xlrd.open_workbook(path)
            fmt = False
        for sh in book.sheets():
            grid = []
            for r in range(min(sh.nrows, MAX_ROWS)):
                row = []
                for c in range(min(sh.ncols, 40)):
                    cell = sh.cell(r, c)
                    v = cell.value
                    if cell.ctype == xlrd.XL_CELL_EMPTY or v == "":
                        row.append("")
                    elif cell.ctype == xlrd.XL_CELL_NUMBER:
                        nf = None
                        if fmt:
                            try:
                                nf = book.format_map[book.xf_list[cell.xf_index].format_key].format_str
                            except Exception:
                                nf = None
                        row.append(cell_text(v, nf))
                    else:
                        row.append(clean_cell(v))
                grid.append(row)
            yield sh.name, grid
        return
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            for ws in wb.worksheets:
                try:
                    ws.reset_dimensions()
                except Exception:
                    pass
                grid = []
                for k, row in enumerate(ws.iter_rows(max_col=40)):
                    if k >= MAX_ROWS:
                        break
                    grid.append([cell_text(getattr(c, "value", None), getattr(c, "number_format", None))
                                 for c in row])
                yield ws.title, grid
        finally:
            wb.close()


def read_excel(path, hints=None):
    tables, notes = [], []
    for sheet_name, grid in _excel_grids(path):
        found = extract_tables(grid, hints)
        if not found:
            continue
        product = find_product_name(grid, keys=getattr(hints, "name", None))
        if product:
            tables += _make_tables(path, clean_cell(product), found, sheet_name)
            continue
        fallback = file_stem(path) if _is_generic_sheet_name(sheet_name) else sheet_name.strip()
        for r, items in found:                      # không có nhãn: thử tiêu đề phía trên từng bảng, rồi tên sheet / tên file
            title = title_above_table(grid, r)
            tables.append(Table(path, clean_cell(title or fallback), items, sheet_name))
    return tables, notes


def _read_csv_text(path):
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "utf-16", "cp1258", "cp1252"):
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode("latin-1")


def read_csv_file(path, hints=None):
    text = _read_csv_text(path)
    try:
        dialect = csv.Sniffer().sniff(text[:5000], delimiters=",;\t|")
    except Exception:
        dialect = csv.excel
    grid = [[clean_cell(c) for c in row] for _i, row in zip(range(MAX_ROWS), csv.reader(io.StringIO(text), dialect))]
    found = extract_tables(grid, hints)
    product = find_product_name(grid, keys=getattr(hints, "name", None))
    if product:
        return _make_tables(path, clean_cell(product), found), []
    return [Table(path, clean_cell(title_above_table(grid, r) or file_stem(path)), items) for r, items in found], []


# ----------------------------------------------------------------------------
# Word (.docx) - đọc trực tiếp XML, không cần cài Word
# ----------------------------------------------------------------------------
_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def _tc_text(tc):
    parts = []
    for el in tc.iter():
        if el.tag == _W + "t" and el.text:
            parts.append(el.text)
        elif el.tag in (_W + "tab", _W + "br", _W + "p"):
            parts.append(" ")
    return clean_cell("".join(parts))


def _tbl_grid(tbl):
    grid = []
    for tr in tbl.findall(_W + "tr"):
        row = []
        for tc in tr.findall(_W + "tc"):
            pr = tc.find(_W + "tcPr")
            span, cont = 1, False
            if pr is not None:
                gs = pr.find(_W + "gridSpan")
                if gs is not None:
                    try:
                        span = max(1, int(gs.get(_W + "val", "1")))
                    except ValueError:
                        span = 1
                vm = pr.find(_W + "vMerge")
                if vm is not None and vm.get(_W + "val") != "restart":
                    cont = True
            row.append("" if cont else _tc_text(tc))
            row.extend([""] * (span - 1))
        grid.append(row)
    return grid


def _name_from_paragraphs(paragraphs, keys=None):
    """Tìm 'Product name: xxx' trong các đoạn văn (nhìn từ đoạn gần bảng nhất). keys: từ khóa người dùng nhập - khớp thì lấy
    phần sau dấu ':' hoặc đoạn văn kế tiếp."""
    for key in keys or []:
        for i in range(len(paragraphs) - 1, -1, -1):
            ok, inline = _label_match(paragraphs[i], key)
            if ok:
                if inline:
                    return inline
                if i + 1 < len(paragraphs) and clean_cell(paragraphs[i + 1]):
                    return clean_cell(paragraphs[i + 1])
    for txt in reversed(paragraphs):
        u = unaccent_upper(txt)
        if any(lbl in u for lbl in _NAME_LABELS) and ":" in txt:
            after = clean_cell(txt.split(":", 1)[1])
            if after:
                return after
    return ""


def read_docx(path, hints=None):
    try:
        with zipfile.ZipFile(path) as z:
            root = ET.fromstring(z.read("word/document.xml"))
    except KeyError:
        raise ValueError("không phải file .docx hợp lệ")
    except zipfile.BadZipFile:
        raise ValueError("file .docx bị hỏng hoặc không phải .docx")
    body = root.find(_W + "body")
    paragraphs, tables, stem = [], [], file_stem(path)
    for child in list(body) if body is not None else []:
        if child.tag == _W + "p":
            t = _tc_text(child)
            if t:
                paragraphs.append(t)
        elif child.tag == _W + "tbl":
            grid = _tbl_grid(child)
            found = extract_tables(grid, hints)
            if not found:
                continue
            nk = getattr(hints, "name", None)
            product = (find_product_name(grid[:8], keys=nk) or _name_from_paragraphs(paragraphs[-8:], nk) or stem)
            tables += _make_tables(path, clean_cell(product), found)
    return tables, []


# ----------------------------------------------------------------------------
# PDF (cần pdfplumber; PDF có lớp chữ)
# ----------------------------------------------------------------------------
_HEADING_RE = re.compile(r"^\d+(\.\d+)+\.?\s")


def _pdf_product_name(page_texts):
    for text in page_texts[:2]:
        lines = [clean_cell(l) for l in text.splitlines()]
        lines = [l for l in lines if l]
        for i, line in enumerate(lines):
            u = unaccent_upper(line)
            if not any(lbl in u or lbl.replace(" ", "") in re.sub(r"\s+", "", u) for lbl in _NAME_LABELS):
                continue
            cand = ""
            m = re.search(r"(product\s*name|t[êe]n\s*s[ảa]n\s*ph[ẩa]m)\s*[:\-]?\s*(.*)$", line, re.I)
            rest = clean_cell(m.group(2)).strip(" \"'“”‘’") if m else ""
            m2 = re.match(r"^[/(][^:]{0,40}:\s*(.*)$", rest)          # nhãn song ngữ '/Nome prodotto: ...'
            if m2:
                rest = m2.group(1).strip()
            if not re.sub(r"[\(\[][^\)\]]*[\)\]]?", "", rest).strip(" :-.\t"):
                rest = ""                                    # phần còn lại chỉ là nhãn song ngữ trong ngoặc "(Product Name) :"
            if rest:
                cand = rest
            else:
                parts = []                       # tên có thể xuống dòng: lấy tới khi gặp đề mục kế tiếp
                for nxt in lines[i + 1:i + 5]:
                    if _HEADING_RE.match(nxt):
                        break
                    parts.append(nxt)
                cand = " ".join(parts)
            if cand and not _HEADING_RE.match(cand) and len(cand) <= 300:
                return cand
    return ""


def _pdf_name_by_keys(pages_words, keys, max_pages=2):
    """PDF: tìm từ khóa người dùng nhập (vd 'Description') trong các dòng chữ đầu file. Nhãn dạng 'Nhãn: giá trị' lấy phần sau ':';
    nhãn đứng riêng (tiêu đề ô) thì lấy dòng ngay dưới, các chữ thẳng cột với nhãn trở đi."""
    for key in keys or []:
        kw = key.split()
        for words in pages_words[:max_pages]:
            lines = _group_lines(words)
            for li, line in enumerate(lines):
                texts = [_norm_hdr(w["text"]) for w in line]
                for i in range(len(line)):
                    if not kw or texts[i:i + len(kw)] != kw:
                        continue
                    last = line[i + len(kw) - 1]
                    rest = [w for w in line[i + len(kw):]]
                    rest_txt = " ".join(w["text"] for w in rest).strip()
                    if last["text"].endswith(":") or rest_txt.startswith(":"):
                        val = clean_cell(rest_txt.lstrip(":"))
                        if val:
                            return val
                    x0 = line[i]["x0"]
                    if li + 1 < len(lines):
                        nxt = [w for w in lines[li + 1] if w["x0"] >= x0 - 4]
                        val = clean_cell(" ".join(w["text"] for w in nxt))
                        if val:
                            return val
                    val = clean_cell(rest_txt.lstrip(":"))
                    if val:
                        return val
    return ""


# ---------------- đọc theo VỊ TRÍ cột (PDF không kẻ bảng, hoặc kết quả OCR) ----------------
_NUM_RE = re.compile(r"^[<>~≤≥]?\s*\d+(?:[.,]\d+)?\s*%?$")
_PAGE_RE = re.compile(r"^(PAGE|TRANG|PAG\.?)\s*\d+", re.I)
GAP_NEW_CELL = 8.0           # khoảng cách ngang (pt) lớn hơn mức này = sang ô tiêu đề mới
LINE_TOL = 3.0               # lệch dọc (pt) cho phép trong cùng một dòng
WRAP_GAP = 5.0               # dòng tên bị xuống dòng: khoảng cách dọc tối đa so với dòng trước
HEADER_SPLIT = 8.5           # hai dòng chữ lệch dọc không quá mức này có thể là một dòng tiêu đề bị OCR tách đôi


def _group_lines(words, tol=LINE_TOL):
    lines = []
    for w in sorted(words, key=lambda w: (w["top"], w["x0"])):
        if lines and abs(lines[-1][0]["top"] - w["top"]) <= tol:
            lines[-1].append(w)
        else:
            lines.append([w])
    for ln in lines:
        ln.sort(key=lambda w: w["x0"])
    return lines


def _segment_header(line):
    """Chia dòng tiêu đề thành các ô theo khoảng cách ngang. Trả về [(chữ, x0, x1)]."""
    cells, cur = [], [line[0]]
    for w in line[1:]:
        if w["x0"] - cur[-1]["x1"] > GAP_NEW_CELL:
            cells.append(cur)
            cur = [w]
        else:
            cur.append(w)
    cells.append(cur)
    return [(" ".join(x["text"] for x in c), c[0]["x0"], c[-1]["x1"]) for c in cells]


def _boundaries(cells):
    """Ranh giới giữa các cột = điểm giữa khoảng trống giữa hai ô tiêu đề liền kề."""
    return [(cells[k][2] + cells[k + 1][1]) / 2.0 for k in range(len(cells) - 1)]


def _data_boundaries(cells, body_lines):
    """Ranh giới cột = giữa khe trống rộng nhất (không có chữ nào của bảng chen vào) nằm giữa hai ô tiêu đề
    liền kề. Chính xác hơn lấy điểm giữa hai chữ tiêu đề khi chữ trong cột dài hơn tiêu đề."""
    ivs = []
    for ln in body_lines:
        span = ln[-1]["x1"] - ln[0]["x0"]
        gaps = [b["x0"] - a["x1"] for a, b in zip(ln, ln[1:])]
        if (gaps and max(gaps) > GAP_NEW_CELL) or span <= 150:      # bỏ dòng văn xuôi liền mạch
            ivs += [(w["x0"], w["x1"]) for w in ln]
    ivs.sort()
    merged = []
    for a, b in ivs:
        if merged and a <= merged[-1][1] + 0.5:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    gutters = [(merged[i][1], merged[i + 1][0]) for i in range(len(merged) - 1)]
    out = []
    for k in range(len(cells) - 1):
        lo, hi = cells[k][1], cells[k + 1][2]
        cand = [(g1 - g0, (g0 + g1) / 2.0) for g0, g1 in gutters if g0 >= lo - 1 and g1 <= hi + 1 and g1 - g0 >= 2.0]
        if cand:
            out.append(max(cand)[1])
            continue
        # không có khe trống nào (chữ cột trái dài sát/đè sang cột phải): dựa vào các chữ của cột phải
        # thường canh trái ngay dưới ô tiêu đề của nó -> ranh giới đặt sát bên trái chúng
        nx0 = cells[k + 1][1]
        xs = [w["x0"] for ln in body_lines for w in ln if abs(w["x0"] - nx0) <= 6.0]
        if len(xs) >= 2:
            out.append(min(min(xs) - 2.0, nx0 - 1.0))
        else:
            out.append((cells[k][2] + cells[k + 1][1]) / 2.0)
    return out


def _col_of(x, bounds):
    for k, b in enumerate(bounds):
        if x < b:
            return k
    return len(bounds)


def _infer_pct_col(cells, next_lines, ing_cols):
    """Tiêu đề cột % không nhận ra (OCR đọc '%' thành '+'...): chọn cột có nhiều số thập phân nhất ở các dòng dưới."""
    bounds = _boundaries(cells)
    dec, integer = {}, {}
    for line in next_lines:
        by = {}
        for w in line:
            by.setdefault(_col_of((w["x0"] + w["x1"]) / 2.0, bounds), []).append(w["text"])
        for k, ws in by.items():
            t = " ".join(ws)
            if k + 1 in ing_cols or not _NUM_RE.match(t):
                continue
            (dec if re.search(r"[.,]\d", t) else integer)[k] = (dec if re.search(r"[.,]\d", t) else integer).get(k, 0) + 1
    pool = dec if dec else {}
    if not pool:
        return 0
    best = max(pool.items(), key=lambda kv: (kv[1], kv[0]))
    return best[0] + 1 if best[1] >= 2 else 0


def _virtual_pct(cells, next_lines, ing_cols):
    """Không có ô tiêu đề nào cho cột % (vd OCR bỏ mất ký hiệu %): lấy cụm số thập phân nằm ở bên phải
    nhiều nhất làm cột %, chèn một ô tiêu đề ảo vào đúng vị trí. Trả về (cells mới, ing mới, pct) hoặc (cells, ings, 0)."""
    nums = []
    for line in next_lines:
        for w in line:
            if _NUM_RE.match(w["text"]) and re.search(r"[.,]\d", w["text"]):
                nums.append(w)
    if len(nums) < 2:
        return cells, ing_cols, 0
    bins = {}
    for w in nums:
        bins.setdefault(int(w["x1"] // 40), []).append(w)
    best = max(bins.values(), key=lambda ws: (len(ws), max(w["x1"] for w in ws)))
    if len(best) < 2:
        return cells, ing_cols, 0
    new = ("%", min(w["x0"] for w in best), max(w["x1"] for w in best))
    tagged = [(c, k + 1 in ing_cols) for k, c in enumerate(cells)] + [(new, False)]
    tagged.sort(key=lambda t: t[0][1])
    cells2 = [t[0] for t in tagged]
    pct = next(k for k, t in enumerate(tagged) if t[0] is new) + 1
    ings = [k + 1 for k, t in enumerate(tagged) if t[1]]
    return cells2, ings, pct


def _headerless_active(lines):
    """Không tìm được dòng tiêu đề (vd OCR đọc hỏng tiêu đề): suy ra cột từ chính dữ liệu.
    Cột % = cụm số thập phân nằm ở bên phải; cột thành phần = cột chữ ngoài cùng bên trái của các dòng có số đó."""
    rows = []
    for ln in lines:
        nums = [w for w in ln if _NUM_RE.match(w["text"]) and re.search(r"[.,]\d", w["text"])]
        if nums and len(ln) >= 2 and ln[0] is not nums[-1]:
            rows.append((ln, nums[-1]))
    if len(rows) < 3:
        return None
    bins = {}
    for ln, w in rows:
        bins.setdefault(int(w["x1"] // 40), []).append((ln, w))
    best = max(bins.values(), key=lambda v: (len(v), max(w["x1"] for _l, w in v)))
    if len(best) < 3:
        return None
    p0, p1 = min(w["x0"] for _l, w in best), max(w["x1"] for _l, w in best)
    lefts = sorted(ln[0]["x0"] for ln, _w in best)
    left = lefts[len(lefts) // 2]
    ivs = sorted((w["x0"], w["x1"]) for ln in lines for w in ln
                 if w["x0"] >= left - 3 and w["x1"] < p0 and not (max([b["x0"] - a["x1"] for a, b in zip(ln, ln[1:])] or [0]) <= GAP_NEW_CELL
                                                                   and ln[-1]["x1"] - ln[0]["x0"] > 150))
    hi, cur = left, None
    for a, b in ivs:                                    # khoảng chữ liền mạch bắt đầu từ mép trái của cột thành phần
        if cur is None:
            if a <= left + 3:
                cur = b
        elif a <= cur + 5.0:
            cur = max(cur, b)
        else:
            break                                       # gặp khe trống đầu tiên: hết cột thành phần
    hi = cur if cur else left + 100
    cells = [("NAME", left, hi), ("-", hi + 2, max(hi + 3, p0 - 2)), ("%", p0, p1)]
    return ([(cells[0][2] + cells[1][1]) / 2.0, (cells[1][2] + cells[2][1]) / 2.0], 2, [0], left)


def _tighten_pct_bound(bounds, cells, pct, body_lines):
    """Ranh giới bên trái của cột % không được cắt vào các số: đẩy nó sát sang trái số đầu tiên của cột %
    (khi chữ của cột bên cạnh dài, hoặc OCR để lại ký tự lạ trong khe giữa hai cột, khe rộng nhất bị chọn sai
    và số % dính vào chữ của cột bên trái)."""
    k = pct - 2                                      # chỉ số ranh giới nằm ngay trước cột %
    if k < 0 or k >= len(bounds):
        return bounds
    _t, hx0, hx1 = cells[pct - 1]
    xs = [w["x0"] for ln in body_lines for w in ln
          if _NUM_RE.match(w["text"]) and re.search(r"[.,]\d", w["text"])
          and hx0 - 40 <= (w["x0"] + w["x1"]) / 2.0 <= hx1 + 80]
    if len(xs) < 2:
        return bounds
    cand = min(xs) - 2.0
    if cand > bounds[k] and (k + 1 >= len(bounds) or cand < bounds[k + 1]):
        bounds = list(bounds)
        bounds[k] = cand
    return bounds


def positional_items(pages_words, hints=None):
    """pages_words: danh sách (mỗi trang) các từ {text, x0, x1, top, bottom}. Tìm dòng tiêu đề có cột thành
    phần + cột %, rồi đọc các dòng bên dưới theo vị trí cột. Dòng có số ở cột % bắt đầu một thành phần;
    dòng không có số mà có chữ ở cột thành phần (sát dòng trước) được nối vào tên."""
    items, active, done = [], None, False
    for words in pages_words:
        if done:
            break
        lines = _group_lines(words)
        start, header = 0, None
        has_dec = lambda ln: any(_NUM_RE.match(w["text"]) and re.search(r"[.,]\d", w["text"]) for w in ln)
        for li, line in enumerate(lines):
            if has_dec(line):
                continue                                        # dòng có số thập phân = dữ liệu, không phải tiêu đề
            cands = [(line, li + 1)]
            if li + 1 < len(lines) and not has_dec(lines[li + 1]) \
                    and lines[li + 1][0]["top"] - line[0]["top"] <= HEADER_SPLIT:
                # OCR hay tách một dòng tiêu đề thành hai dòng lệch nhau vài pt: thử ghép cả hai
                cands.append((sorted(line + lines[li + 1], key=lambda w: w["x0"]), li + 2))
            for ln, nxt_start in cands:
                cells = _segment_header(ln)
                pct, ings = detect_roles([c[0] for c in cells], hints)
                if ings and not pct and len(cells) >= 3:        # suy ra cột % chỉ khi dòng có >= 3 ô (tránh tiêu đề văn bản)
                    nxt = lines[nxt_start:nxt_start + 40]
                    pct = _infer_pct_col(cells, nxt, ings)
                    if not pct:                          # không có ô tiêu đề cho cột %: tạo cột ảo theo vị trí các số
                        cells, ings, pct = _virtual_pct(cells, nxt, ings)
                if pct and ings:
                    header = (cells, pct, ings)
                    start = nxt_start
                    break
            if header:
                break
        if header:
            cells, pct, ings = header
            bounds = _data_boundaries(cells, lines[start:start + 80])
            bounds = _tighten_pct_bound(bounds, cells, pct, lines[start:start + 80])
            active = (bounds, pct - 1, [c - 1 for c in ings], None)
        elif active is None:
            active = _headerless_active(lines)
            if active is None:
                continue
        bounds, pct_i, ing_is, lead_x = active
        prev_bottom = None
        for line in lines[start:]:
            by_col = {}
            for w in line:
                by_col.setdefault(_col_of((w["x0"] + w["x1"]) / 2.0, bounds), []).append(w)
            text = {k: " ".join(w["text"] for w in ws) for k, ws in by_col.items()}
            top, bottom = min(w["top"] for w in line), max(w["bottom"] for w in line)
            whole = " ".join(w["text"] for w in line)
            name = next((text[k] for k in ing_is if text.get(k)), "")
            if lead_x is not None:                       # không có tiêu đề: tên = dải chữ liền mạch bắt đầu ở mép trái
                run = [line[0]] if line[0]["x0"] <= lead_x + 8 else []
                for w in line[1:]:
                    if run and w["x0"] - run[-1]["x1"] <= GAP_NEW_CELL and _col_of((w["x0"] + w["x1"]) / 2.0, bounds) < pct_i:
                        run.append(w)
                    else:
                        break
                name = " ".join(w["text"] for w in run)
            pct_txt = text.get(pct_i, "")
            if not header and _PAGE_RE.match(whole):          # trang không lặp tiêu đề: bỏ dòng "Page x of y"
                prev_bottom = bottom
                continue
            if _is_total(unaccent_upper(name)) or (not pct_txt and _is_total(unaccent_upper(whole))):
                done = True
                break
            if _NUM_RE.match(pct_txt):
                nm = clean_ingredient(name)
                if nm and re.search(r"[A-Za-z]", nm) and len(nm) > 1 and not _is_header_row(unaccent_upper(nm)):
                    items.append([nm, clean_pct(pct_txt)])
                    running = sum((parse_pct(x[1])[0] or 0.0) for x in items)
                    if running >= 99.999:                    # đã đủ 100%: các dòng sau (vd bảng phụ) không tính
                        done = True
                        break
            elif name and items and prev_bottom is not None and top - prev_bottom < WRAP_GAP \
                    and not _is_header_row(unaccent_upper(name)):
                items[-1][0] = clean_ingredient(items[-1][0] + " " + name)
            prev_bottom = bottom
    return [(n, p) for n, p in items]


# ---------------- OCR tùy chọn (PDF dạng ảnh) - cần cài Tesseract ----------------
def find_tesseract(custom=""):
    import shutil
    cands = [custom] if custom else []
    cands.append(shutil.which("tesseract") or "")
    cands += [r"C:\Program Files\Tesseract-OCR\tesseract.exe",
              r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
              os.path.expanduser(r"~\AppData\Local\Programs\Tesseract-OCR\tesseract.exe"),
              "/usr/bin/tesseract", "/usr/local/bin/tesseract", "/opt/homebrew/bin/tesseract"]
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return ""


def ocr_pages_words(pdf, tesseract_cmd, dpi=220, max_pages=12, lang="eng"):
    """Đọc chữ bằng Tesseract: trả về [[word...] mỗi trang], toạ độ quy về đơn vị pt (1/72 inch)."""
    import subprocess
    import tempfile
    scale = 72.0 / dpi
    out = []
    for page in pdf.pages[:max_pages]:
        img = page.to_image(resolution=dpi).original
        fd, png = tempfile.mkstemp(suffix=".png")
        os.close(fd)
        try:
            img.save(png)
            kw = {}
            if sys.platform.startswith("win"):
                kw["creationflags"] = 0x08000000                     # CREATE_NO_WINDOW
            r = subprocess.run([tesseract_cmd, png, "stdout", "-l", lang, "--psm", "6", "tsv"],
                               capture_output=True, timeout=180, **kw)
        finally:
            try:
                os.remove(png)
            except OSError:
                pass
        if r.returncode != 0:
            raise ValueError("Tesseract báo lỗi: %s" % r.stderr.decode("utf-8", "replace").strip()[:200])
        words = []
        for line in r.stdout.decode("utf-8", "replace").splitlines()[1:]:
            f = line.split("\t")
            if len(f) < 12 or f[0] != "5" or not f[11].strip():
                continue
            left, top, wd, ht = (float(f[6]), float(f[7]), float(f[8]), float(f[9]))
            txt = f[11].strip().strip("|").strip()
            if not re.search(r"[A-Za-z0-9%]", txt):               # bỏ ký tự rác của đường kẻ bảng (| = ...)
                continue
            if wd > (24 * len(txt) + 30) * dpi / 220.0:           # 'từ' quá rộng so với số ký tự = OCR đọc nhầm đường kẻ
                continue                                          # (chữ in hoa đậm rộng tới ~20 px/ký tự ở 220 dpi)
            words.append({"text": txt, "x0": left * scale, "x1": (left + wd) * scale,
                          "top": top * scale, "bottom": (top + ht) * scale})
        out.append(words)
    return out


# ---- OCR có nhận dạng KHUNG BẢNG (PDF scan có đường kẻ): tìm đường kẻ -> xóa đường kẻ -> OCR -> xếp chữ vào ô ----
OCR_DPI = 300                # độ phân giải dựng ảnh trang
OCR_SCALE = 1.5              # phóng thêm trước khi OCR (chữ trong bảng rất nhỏ)
BIN_THRESHOLD = 175          # điểm xám <= ngưỡng này = nét chữ / đường kẻ (nền, dấu watermark nhạt bị bỏ)


def _binarize(img, threshold=BIN_THRESHOLD):
    """Ảnh xám -> đen/trắng (0 = nét). Chỉ dùng Pillow."""
    return img.convert("L").point(lambda p: 0 if p <= threshold else 255)


def _darkness(bw, horizontal):
    """Độ đậm (0..1) của từng dòng ngang (horizontal=True) hoặc từng cột dọc của ảnh đen/trắng."""
    from PIL import Image
    w, h = bw.size
    r = bw.resize((1, h) if horizontal else (w, 1), Image.BOX)
    return [1.0 - v / 255.0 for v in r.getdata()]


def _runs(flags, gap=2):
    """Gom các vị trí liền nhau (cách nhau <= gap) có cờ True thành các dải (đầu, cuối)."""
    out, start, last = [], None, None
    for i, f in enumerate(flags):
        if f:
            if start is None:
                start = i
            last = i
        elif start is not None and i - last > gap:
            out.append((start, last))
            start = None
    if start is not None:
        out.append((start, last))
    return out


def estimate_skew(bw, max_deg=2.0):
    """Góc nghiêng của trang scan (độ): chọn góc làm các đường kẻ ngang thẳng nhất (tổng bình phương độ đậm theo dòng lớn nhất)."""
    from PIL import Image
    small = bw.resize((max(1, bw.size[0] // 4), max(1, bw.size[1] // 4)), Image.BOX)

    def score(a):
        r = small.rotate(a, resample=Image.BILINEAR, fillcolor=255)
        return sum(v * v for v in _darkness(r, True))

    best, step = 0.0, 0.25
    cands = [i * step for i in range(-int(max_deg / step), int(max_deg / step) + 1)]
    best = max(cands, key=score)
    for a in [best + d * 0.05 for d in range(-4, 5)]:           # tinh chỉnh quanh góc tốt nhất
        if score(a) > score(best):
            best = a
    return best


def find_table_lines(bw):
    """Tìm đường kẻ bảng. Trả về (cột dọc [(a,b)], dòng ngang [(a,b)]) theo pixel hoặc None nếu không thấy khung bảng.
    Dòng ngang trong ô gộp chỉ chạy một phần chiều rộng bảng nên ngưỡng thấp hơn đường dọc."""
    w, h = bw.size
    rows0 = _runs([d >= 0.30 for d in _darkness(bw, True)])
    if len(rows0) < 4:
        return None
    y0, y1 = rows0[0][0], rows0[-1][1]
    cols = _runs([d >= 0.5 for d in _darkness(bw.crop((0, y0, w, y1 + 1)), False)])
    if len(cols) < 4:
        return None
    x0, x1 = cols[0][0], cols[-1][1]
    rows = _runs([d >= 0.4 for d in _darkness(bw.crop((x0, 0, x1 + 1, h)), True)])
    rows = [r for r in rows if y0 - 3 <= r[0] and r[1] <= y1 + 3]
    if len(rows) < 4:
        return None
    return cols, rows


def erase_table_lines(bw, cols, rows, target=None):
    """Xóa đường kẻ (chỉ xóa đoạn thực sự là nét liền) để chữ sát đường kẻ không bị OCR đọc sai.
    Vị trí đường kẻ đo trên ảnh đen/trắng `bw`; xóa trên `target` (ảnh xám để OCR giữ nét chữ mịn) hoặc bản sao của bw."""
    from PIL import ImageDraw
    out = (target if target is not None else bw).copy()
    dr = ImageDraw.Draw(out)
    xs = [(a + b) / 2.0 for a, b in cols]
    ys = [(a + b) / 2.0 for a, b in rows]

    def mean_dark(box):
        from PIL import Image
        if box[2] <= box[0] or box[3] <= box[1]:
            return 0.0
        return 1.0 - bw.crop(box).resize((1, 1), Image.BOX).getpixel((0, 0)) / 255.0

    for a, b in rows:
        for i in range(len(xs) - 1):
            box = (int(xs[i]), max(0, a - 1), int(xs[i + 1]) + 1, b + 2)
            if mean_dark(box) >= 0.7:
                dr.rectangle([box[0], box[1], box[2], box[3] - 1], fill=255)
    for a, b in cols:
        for i in range(len(ys) - 1):
            box = (max(0, a - 1), int(ys[i]), b + 2, int(ys[i + 1]) + 1)
            if mean_dark(box) >= 0.7:
                dr.rectangle([box[0], box[1], box[2] - 1, box[3]], fill=255)
    return out


def _tesseract_words(img, tesseract_cmd, dpi, lang="eng", psm=11):
    """Chạy Tesseract trên ảnh PIL; trả về danh sách từ với toạ độ theo pixel của ảnh."""
    import subprocess
    import tempfile
    fd, png = tempfile.mkstemp(suffix=".png")
    os.close(fd)
    try:
        img.save(png, dpi=(dpi, dpi))
        kw = {}
        if sys.platform.startswith("win"):
            kw["creationflags"] = 0x08000000                         # CREATE_NO_WINDOW
        r = subprocess.run([tesseract_cmd, png, "stdout", "-l", lang, "--psm", str(psm), "tsv"],
                           capture_output=True, timeout=240, **kw)
    finally:
        try:
            os.remove(png)
        except OSError:
            pass
    if r.returncode != 0:
        raise ValueError("Tesseract báo lỗi: %s" % r.stderr.decode("utf-8", "replace").strip()[:200])
    words = []
    for line in r.stdout.decode("utf-8", "replace").splitlines()[1:]:
        f = line.split("\t")
        if len(f) < 12 or f[0] != "5" or not f[11].strip():
            continue
        left, top, wd, ht = (float(f[6]), float(f[7]), float(f[8]), float(f[9]))
        txt = f[11].strip().strip("|").strip()
        if not re.search(r"[A-Za-z0-9%]", txt):
            continue
        if wd > (24 * len(txt) + 30) * dpi / 220.0:
            continue
        words.append({"text": txt, "x0": left, "x1": left + wd, "top": top, "bottom": top + ht})
    return words


def _words_to_grid(words, cols, rows):
    """Xếp chữ vào ô theo vị trí tâm chữ. Ô gộp: chữ nằm ở dòng nào thì ở dòng đó (các dòng khác để trống)."""
    from bisect import bisect_right
    xs = [(a + b) / 2.0 for a, b in cols]
    ys = [(a + b) / 2.0 for a, b in rows]
    cells = [[[] for _ in range(len(xs) - 1)] for _ in range(len(ys) - 1)]
    for w in words:
        cx, cy = (w["x0"] + w["x1"]) / 2.0, (w["top"] + w["bottom"]) / 2.0
        if cx < xs[0] or cx >= xs[-1] or cy < ys[0] or cy >= ys[-1]:
            continue
        cells[bisect_right(ys, cy) - 1][bisect_right(xs, cx) - 1].append(w)
    grid = []
    for row in cells:
        grid.append([clean_cell(" ".join(" ".join(x["text"] for x in ln) for ln in _group_lines(c, tol=8)))
                     if c else "" for c in row])
    return grid


_DEC_RE = re.compile(r"^\d+[.,](\d+)$")


def _fix_grid_decimals(grid):
    """OCR hay làm rơi dấu thập phân của số nhỏ (36.47880000 -> 3647880000). Mỗi cột số có số chữ số thập phân
    thống nhất (vd cột Actual Wt luôn 8 chữ số): ô chỉ gồm chữ số mà dài hơn mức đó thì chèn lại dấu chấm."""
    if not grid:
        return grid
    ncol = max(len(r) for r in grid)
    for c in range(ncol):
        decs = {}
        for r in grid:
            if c < len(r):
                m = _DEC_RE.match(r[c].strip())
                if m:
                    decs[len(m.group(1))] = decs.get(len(m.group(1)), 0) + 1
        total = sum(decs.values())
        if total < 5:
            continue
        d, cnt = max(decs.items(), key=lambda kv: kv[1])
        if d < 1 or cnt < 0.5 * total:
            continue
        for r in grid:
            if c < len(r):
                t = r[c].strip()
                if t.isdigit() and len(t) > d:
                    r[c] = t[:-d] + "." + t[-d:]
                elif _DEC_RE.match(t) and "," in t:
                    r[c] = t.replace(",", ".")
    return grid


def ocr_pages_grid(pdf, tesseract_cmd, dpi=OCR_DPI, scale=OCR_SCALE, max_pages=12, lang="eng", psm=11):
    """OCR cho PDF scan. Trả về (words_pt, grids): words_pt = [[từ (toạ độ pt)] mỗi trang];
    grids = [lưới ô (list dòng) hoặc None mỗi trang] - lưới dựng từ đường kẻ bảng, dùng chung bộ đọc bảng kẻ ô.
    Trang scan bị nghiêng được xoay thẳng lại trước khi tìm đường kẻ."""
    from PIL import Image
    pages_words, grids = [], []
    for page in pdf.pages[:max_pages]:
        img = page.to_image(resolution=dpi).original.convert("L")
        angle = estimate_skew(_binarize(img))
        if abs(angle) >= 0.05:
            img = img.rotate(angle, resample=Image.BICUBIC, fillcolor=255)
        bw = _binarize(img)
        # ảnh xám để OCR: nền và dấu watermark nhạt -> trắng, giữ nét chữ mịn (Tesseract tự phân ngưỡng tốt hơn ảnh đã nhị phân)
        gray = img.point(lambda p: 255 if p > 200 else p)
        lines = find_table_lines(bw)
        if lines:
            gray = erase_table_lines(bw, lines[0], lines[1], gray)
        big = gray.resize((int(gray.size[0] * scale), int(gray.size[1] * scale)), Image.LANCZOS) if scale != 1 else gray
        words = _tesseract_words(big, tesseract_cmd, dpi * scale, lang, psm)
        px = [{"text": w["text"], "x0": w["x0"] / scale, "x1": w["x1"] / scale,        # toạ độ pixel ảnh (dpi)
               "top": w["top"] / scale, "bottom": w["bottom"] / scale} for w in words]
        grids.append(_fix_grid_decimals(_words_to_grid(px, lines[0], lines[1])) if lines else None)
        k = 72.0 / dpi
        pages_words.append([{"text": w["text"], "x0": w["x0"] * k, "x1": w["x1"] * k,
                             "top": w["top"] * k, "bottom": w["bottom"] * k} for w in px])
    return pages_words, grids


# Các cấu hình OCR thử lần lượt (dpi, phóng, psm): kết quả OCR dao động theo cấu hình, nên chọn cấu hình cho tổng hàm lượng gần 100 nhất
OCR_VARIANTS = [(300, 1.5, 11), (400, 1.0, 11), (300, 1.5, 4), (400, 2.0, 11), (300, 2.0, 11), (400, 1.5, 11), (300, 1.0, 4), (400, 1.0, 4)]


def _pct_sum(items):
    return sum((parse_pct(x[1])[0] or 0.0) for x in items)


def ocr_best_variant(pdf, tesseract_cmd, hints=None):
    """Chạy OCR với nhiều cấu hình, dừng khi tổng hàm lượng = 100 (sai số 0.001). Trả về (page_words, grids, items, tổng)."""
    best, empty = None, 0
    for dpi, scale, psm in OCR_VARIANTS:
        words, grids = ocr_pages_grid(pdf, tesseract_cmd, dpi, scale, psm=psm)
        tables = [g for g in grids if g]
        items = _items_from_ruled_tables(tables, hints) if tables else []
        if not items:
            items = positional_items(words, hints)
        total = _pct_sum(items) if items else 0.0
        err = abs(total - 100.0) if items else 1e9
        key = (err, -len(items))
        if best is None or key < best[0]:
            best = (key, words, grids, items, total)
        if items and err < 0.001:
            break
        empty += 0 if items else 1
        if empty >= 2:                                   # hai cấu hình liền không ra bảng nào: không phải do nhiễu OCR
            break
    return best[1], best[2], best[3], best[4]


def _words_to_text(pages_words):
    return ["\n".join(" ".join(w["text"] for w in ln) for ln in _group_lines(ws)) for ws in pages_words]


def _preview_from_texts(texts, limit=60):
    lines = []
    for t in texts[:2]:
        lines += [clean_cell(l) for l in t.splitlines() if clean_cell(l)]
    return lines[:limit]


_MASTER_NAMES = None


def _master_names():
    """Tên INCI chuẩn (bảng master trong regdb.json) dùng để chỉnh lỗi chính tả do OCR. Không có file -> rỗng."""
    global _MASTER_NAMES
    if _MASTER_NAMES is None:
        _MASTER_NAMES = {}
        try:
            import json
            fp = os.path.join(os.path.dirname(os.path.abspath(__file__)), "regdb.json")
            with open(fp, encoding="utf-8") as fh:
                for e in json.load(fh).get("master", []):
                    nm = clean_cell(e.get("name", ""))
                    if nm:
                        _MASTER_NAMES[nm.lower()] = nm
        except Exception:
            _MASTER_NAMES = {}
    return _MASTER_NAMES


def _edit_distance(a, b, limit=3):
    """Khoảng cách chỉnh sửa (Levenshtein); dừng sớm khi vượt `limit`."""
    if abs(len(a) - len(b)) > limit:
        return limit + 1
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        if min(cur) > limit:
            return limit + 1
        prev = cur
    return prev[-1]


def snap_ocr_names(items):
    """Chỉ dùng cho kết quả OCR: tên chưa có trong danh sách INCI chuẩn mà gần giống MỘT tên chuẩn (độ giống >= 0.9,
    cùng số từ, sai khác tối đa 2 ký tự) -> coi là lỗi OCR và đổi sang tên chuẩn. Trả về (items mới, [(tên OCR, tên chuẩn)])."""
    import difflib
    master = _master_names()
    if not master:
        return items, []
    keys = list(master.keys())
    out, changes = [], []
    for n, p in items:
        low = n.lower()
        if low in master:
            out.append((n, p))
            continue
        m = [k for k in difflib.get_close_matches(low, keys, n=3, cutoff=0.9) if _edit_distance(low, k) <= 2]
        if len(m) == 1 and len(m[0].split()) == len(low.split()):
            std = master[m[0]]
            if std.isupper() and not n.isupper():              # bảng master có tên viết hoa toàn bộ: giữ kiểu viết như file khách
                std = std.title()
            changes.append((n, std))
            out.append((std, p))
        else:
            out.append((n, p))
    return out, changes


def read_pdf(path, hints=None, tesseract=""):
    try:
        import pdfplumber
    except ImportError:
        raise ReadError("Đọc PDF cần thư viện pdfplumber (pip install pdfplumber)")
    notes = []
    with pdfplumber.open(path) as pdf:
        page_texts, page_tables, text_tables, page_words, chars = [], [], [], [], 0
        table_pages = []                                     # trang (0-based) của từng bảng trong page_tables
        for pno, page in enumerate(pdf.pages):
            text = page.extract_text() or ""
            chars += len(text.strip())
            page_texts.append(text)
            page_words.append(page.extract_words(x_tolerance=2, y_tolerance=2, keep_blank_chars=False))
            tbs = page.extract_tables()
            for t in tbs:
                page_tables.append([[clean_cell(c) for c in row] for row in t])
                table_pages.append(pno)
            if not tbs and re.search(r"INCI|INGREDIENT|THANH PHAN|THÀNH PHẦN", text, re.I):
                # bảng không kẻ ô: chỉ dùng làm phương án cuối (đọc theo vị trí chữ chính xác hơn)
                for t in page.extract_tables({"vertical_strategy": "text", "horizontal_strategy": "text",
                                              "text_x_tolerance": 2, "text_y_tolerance": 2}):
                    text_tables.append([[clean_cell(c) for c in row] for row in t])
        used_ocr = False
        if chars == 0:                                       # PDF dạng ảnh -> thử OCR
            cmd = find_tesseract(tesseract)
            if not cmd:
                raise ReadError("PDF dạng ảnh (scan): cần cài Tesseract OCR để đọc "
                                "(xem HUONG_DAN.txt mục OCR)", ["(PDF dạng ảnh, không có lớp chữ)"])
            try:
                page_words, ocr_grids, _its, ocr_total = ocr_best_variant(pdf, cmd, hints)
            except ReadError:
                raise
            except Exception as ex:
                raise ReadError("OCR lỗi: %s" % ex, ["(PDF dạng ảnh)"])
            page_texts = _words_to_text(page_words)
            # trang có khung bảng: dùng lưới ô (chính xác hơn đọc theo vị trí chữ); không có khung thì đọc theo vị trí
            page_tables = [g for g in ocr_grids if g]
            text_tables, used_ocr = [], True
            if _its and abs(ocr_total - 100.0) > 0.001:
                notes.append("OCR: tổng hàm lượng đọc được = %s (khác 100) - có số bị đọc sai, hãy đối chiếu với file PDF"
                             % ("%.6f" % ocr_total).rstrip("0").rstrip("."))

    if page_tables and not used_ocr:
        multi = _pdf_multi_tables(path, page_tables, table_pages, page_words, page_texts, hints)
        if len(multi) >= 2:
            names = [t.product for t in multi]
            notes.append("file có %d bảng thành phần -> mỗi bảng một sheet" % len(multi))
            if len(set(names)) < len(names):
                notes.append("có bảng trùng tên sản phẩm (không tìm thấy mã màu để phân biệt)")
            for t in multi:
                t.notes = notes
            return multi, notes
    items = _items_from_ruled_tables(page_tables, hints) if page_tables else []
    if not items:
        items = positional_items(page_words, hints)
    if not items and text_tables:
        items = _items_from_ruled_tables(text_tables, hints)
    if not items:
        alltext = "\n".join(page_texts)
        if re.search(r"INCI\s*NAME|INGREDIENT", alltext, re.I) and not re.search(r"%|\bWT\b|ACTUAL|CONTENT|HAM LUONG|HÀM LƯỢNG", alltext, re.I):
            raise ReadError("file PDF chỉ có danh sách thành phần (INCI Name, CAS No., Function...) mà KHÔNG có cột hàm lượng (%) "
                            "nên không dựng được BTP. Hãy xin khách file có cột % (Wt / Actual Wt)",
                            _preview_from_texts(page_texts))
        raise ReadError("không tìm thấy bảng thành phần (cần dòng tiêu đề có cột thành phần và cột %). "
                        "Hãy nhập tên cột đúng của file này vào ô 'Tên cột' rồi đọc lại",
                        _preview_from_texts(page_texts))
    if used_ocr:
        items, snapped = snap_ocr_names(items)
        notes.append("đọc bằng OCR - hãy kiểm tra kỹ số liệu")
        if snapped:
            notes.append("OCR: đã sửa %d tên gần giống tên INCI chuẩn (%s%s)" % (
                len(snapped), "; ".join("%s -> %s" % c for c in snapped[:5]), " ..." if len(snapped) > 5 else ""))
    product = (_pdf_name_by_keys(page_words, getattr(hints, "name", None)) or _pdf_product_name(page_texts)
               or file_stem(path))
    t = Table(path, clean_cell(product), [(n, p) for n, p in items])
    t.notes = notes
    return [t], notes


# ---------------- PDF nhiều bảng thành phần (mỗi bảng một sheet, kèm mã màu) ----------------
_COLOUR_WORDS = ("COLOUR", "COLOR", "COLORAZIONE", "SHADE", "NUANCE", "TONALITA", "TEINTE", "MAU", "MAU SAC")
_FILL_RE = re.compile(r"\b(ADD(ED)? TO|AD|ADD|QS|Q S|QSP|Q S P|CSP|QUANTUM SATIS|BALANCE|TO MAKE|FILL)\b|^\s*100\s*-\s*SUM|\bTO 100\b")


def _is_fill(p):
    """Ô hàm lượng kiểu 'Add to 100', 'q.s. 100', 'qsp', 'ad 100' (phần bù cho đủ 100)?"""
    u = " ".join(re.sub(r"[^A-Z0-9]+", " ", unaccent_upper(p or "")).split())
    return bool(u) and bool(_FILL_RE.search(u)) and not re.fullmatch(r"[\d ]+", u)


def _pdf_colour(words, extra_keys=None):
    """Mã màu trên một trang: tìm nhãn 'Colour / Colorazione:' rồi lấy chữ cùng dải dọc (bên phải nhãn, hoặc chữ to
    nằm cùng hàng ở bên trái). Trả về chuỗi hoặc ''."""
    keys = set(_COLOUR_WORDS) | set(extra_keys or [])
    for w in words:
        if not w["text"].endswith(":") or _norm_hdr(w["text"]) not in keys:
            continue
        mid = (w["top"] + w["bottom"]) / 2.0
        line = [x for x in words if abs((x["top"] + x["bottom"]) / 2.0 - mid) <= 3.0]
        line.sort(key=lambda x: x["x0"])
        i = line.index(w)
        group = [w]
        k = i - 1                                         # các chữ nhãn đứng trước: 'Colour', '/'
        while k >= 0 and (_norm_hdr(line[k]["text"]) in keys or line[k]["text"] in ("/", "-", "|")):
            group.insert(0, line[k])
            k -= 1
        ids = {id(x) for x in group}
        band = [x for x in words if id(x) not in ids
                and x["top"] - 1 <= mid <= x["bottom"] + 1 and (x["bottom"] - x["top"]) >= 0]
        right = [x for x in band if x["x0"] >= w["x1"] - 1]
        left = [x for x in band if x["x1"] <= group[0]["x0"] + 1]
        pick = right or left
        if pick:
            # chỉ lấy các chữ sát nhau (khoảng cách ngang nhỏ) bắt đầu từ chữ gần nhãn nhất
            pick.sort(key=lambda x: x["x0"])
            if not right:
                pick = pick[::-1]
            out = [pick[0]]
            for x in pick[1:]:
                prev = out[-1]
                gap = (x["x0"] - prev["x1"]) if right else (prev["x0"] - x["x1"])
                if gap <= GAP_NEW_CELL:
                    out.append(x)
                else:
                    break
            if not right:
                out = out[::-1]
            val = clean_cell(" ".join(x["text"] for x in out))
            if val:
                return val
    return ""


def _has_fill(items):
    return any(_is_fill(p) for _n, p in items)


def _numeric_total(items):
    tot = 0.0
    for _n, p in items:
        v, _a = parse_pct(p)
        if v is not None:
            tot += v
    return tot


def _cut_bilingual(name):
    """'Tên EN 100ml / Tên IT 100ml' -> phần đầu (trước ' / ')."""
    parts = re.split(r"\s+/\s+", name, maxsplit=1)
    return parts[0].strip() if len(parts) == 2 and parts[0].strip() else name


def _pdf_multi_tables(path, page_tables, table_pages, page_words, page_texts, hints=None):
    """Tách PDF chứa nhiều bảng thành phần. Mỗi bảng có dòng tiêu đề riêng; một bảng mới bắt đầu khi:
    - trang có mã màu khác trang trước, hoặc
    - bảng trước đã 'đóng' (có dòng Total, hoặc tổng % ~ 100 / có dòng 'Add to 100') và không có mã màu để so.
    Bảng không có dòng tiêu đề (trang nối tiếp) được nối vào bảng đang đọc. Trả về list Table (có thể rỗng / 1 bảng)."""
    add_colour = getattr(hints, "add_colour", True)
    colour_keys = getattr(hints, "colour", None)
    groups = []                      # mỗi phần tử: dict(items, active, done, page, colour)
    cur = None
    colour_cache = {}

    def colour_of(pno):
        if pno not in colour_cache:
            colour_cache[pno] = _pdf_colour(page_words[pno], colour_keys)
        return colour_cache[pno]

    for tb, pno in zip(page_tables, table_pages):
        has_hdr = any(all(detect_header(row, hints)) for row in tb)
        if has_hdr:
            colour = colour_of(pno)
            new = cur is None
            if not new:
                if colour or cur["colour"]:
                    new = colour != cur["colour"]
                else:
                    total = _numeric_total(cur["items"])
                    new = cur["done"] or abs(total - 100) <= TOTAL_TOL or (
                        _has_fill(cur["items"]) and cur["page"] != pno)
            if new:
                cur = {"items": [], "active": None, "done": False, "page": pno, "colour": colour}
                groups.append(cur)
        elif cur is None or cur["done"] or cur["active"] is None:
            continue
        cur["active"], done = _ruled_scan([tb], hints, cur["items"], cur["active"])
        cur["done"] = cur["done"] or done
    tables = []
    for g in groups:
        if not g["items"]:
            continue
        pno = g["page"]
        name = (_pdf_name_by_keys([page_words[pno]], getattr(hints, "name", None))
                or _pdf_product_name([page_texts[pno]]) or file_stem(path))
        name = clean_cell(_cut_bilingual(name))
        if add_colour and g["colour"] and g["colour"].upper() not in name.upper().split():
            name = "%s - %s" % (name, g["colour"])
        items = _resolve_fill(g["items"])
        tables.append(Table(path, name, items))
    return tables


def _resolve_fill(items):
    """Ô hàm lượng kiểu 'Add to 100' / 'q.s.' (bù cho đủ 100) -> số = 100 - tổng các dòng còn lại (nếu chỉ có 1 dòng như vậy
    và mọi dòng khác đọc được)."""
    fill = [i for i, (_n, p) in enumerate(items) if _is_fill(p)]
    if len(fill) != 1:
        return list(items)
    others = [(n, p) for i, (n, p) in enumerate(items) if i != fill[0]]
    if any(parse_pct(p)[0] is None for _n, p in others):
        return list(items)
    rest = 100.0 - sum(parse_pct(p)[0] for _n, p in others)
    if rest <= 0:
        return list(items)
    out = list(items)
    out[fill[0]] = (items[fill[0]][0], format_number(round(rest, 6)))
    return out


def _items_from_ruled_tables(page_tables, hints=None):
    """Bảng có đường kẻ: lấy bảng thành phần đầu tiên, nối các trang tiếp theo (cùng số cột)."""
    items = []
    _ruled_scan(page_tables, hints, items, None)
    return items


def _ruled_scan(page_tables, hints, items, active):
    """Đọc các bảng kẻ ô vào `items` (nối thêm). Trả về (active, done): active = (cột %, cột tên, số cột) của bảng đang
    đọc dở (để nối trang sau), done = đã gặp dòng Total / hết bảng."""
    done = False
    for tb in page_tables:
        if done:
            break
        start, hdr = 0, None
        for r, row in enumerate(tb):
            pct, ing = detect_header(row, hints)
            if pct and ing:
                hdr = (r, pct, ing)
                break
        if hdr:
            start, pct, ing = hdr[0] + 1, hdr[1], hdr[2]
            active = (pct, ing, max(len(row) for row in tb))
        elif active and tb and max(len(row) for row in tb) == active[2]:
            pct, ing = active[0], active[1]
        else:
            continue
        blanks, first_data = 0, True
        for row in tb[start:]:
            name = clean_ingredient(row[ing - 1]) if ing - 1 < len(row) else ""
            if first_data and items and name:
                first_data = False
                others = [clean_cell(c) for k, c in enumerate(row) if k != ing - 1]
                if not any(others):                         # phần cuối tên bị ngắt trang
                    items[-1] = (items[-1][0] + " " + name, items[-1][1])
                    continue
            first_data = False
            if not name:
                blanks += 1
                if blanks >= MAX_BLANKS:
                    done = True
                    break
                continue
            u = unaccent_upper(name)
            if _is_total(u):
                done = True
                break
            if _is_header_row(u) or len(name) <= 2 or not re.search(r"[A-Za-z]", name):
                continue
            blanks = 0
            items.append((name, clean_pct(row[pct - 1]) if pct - 1 < len(row) else ""))
    return active, done


def make_preview(path, limit=60):
    """Các dòng đầu của file (để người dùng nhìn thấy tên cột thực tế)."""
    ext = os.path.splitext(path)[1].lower()
    lines = []
    try:
        if ext in (".xlsx", ".xlsm", ".xls"):
            for _name, grid in _excel_grids(path):
                for row in grid:
                    cells = [c for c in row if c]
                    if cells:
                        lines.append(" | ".join(cells))
                    if len(lines) >= limit:
                        break
                break
        elif ext == ".csv":
            lines = [clean_cell(l) for l in _read_csv_text(path).splitlines() if clean_cell(l)]
        elif ext == ".docx":
            with zipfile.ZipFile(path) as z:
                root = ET.fromstring(z.read("word/document.xml"))
            body = root.find(_W + "body")
            for child in list(body) if body is not None else []:
                if child.tag == _W + "p":
                    t = _tc_text(child)
                    if t:
                        lines.append(t)
                elif child.tag == _W + "tbl":
                    for row in _tbl_grid(child):
                        cells = [c for c in row if c]
                        if cells:
                            lines.append(" | ".join(cells))
        elif ext == ".pdf":
            import pdfplumber
            with pdfplumber.open(path) as pdf:
                lines = _preview_from_texts([(pg.extract_text() or "") for pg in pdf.pages[:2]], limit)
    except Exception:
        pass
    return lines[:limit]


def suggest_header_line(lines):
    """Đoán dòng tiêu đề bảng: dòng chữ ngay trên dòng dữ liệu đầu tiên (có chữ và số thập phân;
    nếu không có số thập phân nào thì dùng dòng có chữ và số)."""
    for pattern in (r"\d+[.,]\d+", r"\d"):
        for k, ln in enumerate(lines):
            if k and re.search(r"[A-Za-z]{3,}", ln) and re.search(pattern, ln):
                if not re.search(pattern, lines[k - 1]):
                    return k - 1
    return -1


def read_source(path, hints=None, tesseract=""):
    """Đọc một file khách hàng. Trả về (list[Table], [ghi chú]). Ném ReadError (kèm xem trước) nếu không đọc được.
    hints: ColumnHints - tên cột người dùng nhập; tesseract: đường dẫn Tesseract (tuỳ chọn, cho PDF scan)."""
    ext = os.path.splitext(path)[1].lower()
    if ext in UNSUPPORTED_HINT:
        raise ReadError(UNSUPPORTED_HINT[ext])
    kind = SUPPORTED.get(ext)
    if kind is None:
        raise ReadError("định dạng '%s' chưa hỗ trợ" % ext)
    try:
        if kind == "excel":
            tables, notes = read_excel(path, hints)
        elif kind == "csv":
            tables, notes = read_csv_file(path, hints)
        elif kind == "word":
            tables, notes = read_docx(path, hints)
        else:
            tables, notes = read_pdf(path, hints, tesseract)
    except ReadError:
        raise
    except ValueError as ex:
        raise ReadError(str(ex), make_preview(path))
    if not tables:
        raise ReadError("không tìm thấy bảng thành phần (cần dòng tiêu đề có cột thành phần và cột %). "
                        "Hãy nhập tên cột đúng của file này vào ô 'Tên cột' rồi đọc lại", make_preview(path))
    return tables, notes


def find_files(folder, recursive=True):
    out = []
    for root, _dirs, files in (os.walk(folder) if recursive else [(folder, [], os.listdir(folder))]):
        for fn in files:
            if fn.startswith("~$"):
                continue
            if os.path.splitext(fn)[1].lower() in SUPPORTED:
                out.append(os.path.join(root, fn))
    return sorted(out)


# ----------------------------------------------------------------------------
# Ghi file BTP
# ----------------------------------------------------------------------------
class WriteOptions:
    def __init__(self, start=1, normalize=True, merge_duplicates=False, sort_desc=False, sequential=False,
                 fill_notes=True, note_index=None):
        self.fill_notes = fill_notes            # điền ghi chú theo tên thành phần vào cột E (bảng ghi chú, xem note_engine.py)
        self.note_index = note_index            # None = dùng bảng ghi chú đã lưu của người dùng
        self.start = start                      # số thứ tự file đầu tiên
        self.sequential = sequential            # đánh số sheet liên tục start..start+n-1 (không dùng 1.1, 1.2...)
        self.normalize = normalize              # bỏ %, đổi dấu chấm thập phân thành dấu phẩy
        self.merge_duplicates = merge_duplicates
        self.sort_desc = sort_desc


def sheet_names_for(tables, start=1, sequential=False):
    """Gán tên sheet: file thứ k -> start+k-1; bảng thứ 2 trở đi trong cùng file -> k.1, k.2...
    sequential=True: mọi bảng đánh số liên tục start, start+1, ... (file nhiều sheet không còn dạng 1.1, 1.2)."""
    if sequential:
        return [str(start + i) for i in range(len(tables))]
    names, idx_of, counter = [], {}, {}
    next_idx = start
    for t in tables:
        key = t.source_path
        if key not in idx_of:
            idx_of[key] = next_idx
            counter[key] = 0
            next_idx += 1
        j = counter[key]
        counter[key] += 1
        names.append(str(idx_of[key]) if j == 0 else "%d.%d" % (idx_of[key], j))
    return names


def prepare_items(items, opts):
    rows = [(n, normalize_pct(p) if opts.normalize else clean_pct(p)) for n, p in items]
    if opts.merge_duplicates:
        order, acc, texts = [], {}, {}
        for n, p in rows:
            k = n.casefold()
            v, _a = parse_pct(p)
            if k not in acc:
                acc[k] = [n, v, p]
                order.append(k)
            elif v is not None:
                acc[k][1] = (acc[k][1] or 0.0) + v
                acc[k][2] = None
        rows = []
        for k in order:
            n, v, p = acc[k]
            if p is None and v is not None:
                p = format_number(round(v, 10))
                if opts.normalize:
                    p = normalize_pct(p)
            rows.append((n, p or ""))
    if opts.sort_desc:
        rows.sort(key=lambda x: -(parse_pct(x[1])[0] or 0.0))
    return rows


def write_btp(tables, path, opts=None):
    """Ghi các bảng đã chọn ra file BTP. Trả về [(tên sheet, Table, tổng %)]."""
    opts = opts or WriteOptions()
    chosen = [t for t in tables if t.selected]
    if not chosen:
        raise ValueError("chưa chọn bảng nào để xuất")
    names = sheet_names_for(chosen, opts.start, getattr(opts, "sequential", False))
    notes = None
    if getattr(opts, "fill_notes", True):
        import note_engine
        notes = opts.note_index if getattr(opts, "note_index", None) is not None else note_engine.get_index()
    wb = Workbook()
    wb.remove(wb.active)
    font = Font(name="Times New Roman", size=12)
    result = []
    for name, t in zip(names, chosen):
        ws = wb.create_sheet(name)
        rows = prepare_items(t.items, opts)
        label = "%s. %s" % (name, t.product)
        total = 0.0
        for i, (ing, pct) in enumerate(rows, start=1):
            v, _a = parse_pct(pct)
            total += v or 0.0
            ws.cell(i, 1, label)
            ws.cell(i, 2, i)
            ws.cell(i, 3, ing)
            d = ws.cell(i, 4, pct)
            d.number_format = "@"
            note = notes.lookup(ing) if notes else ""
            if note:
                ws.cell(i, 5, note)
            if v is not None:
                ws.cell(i, 7, v)
        ok = abs(total - 100) <= TOTAL_TOL
        ws.cell(1, 8, "OK (100)" if ok else "Lệch: tổng %s" % format_number(round(total, 6)))
        if not ok:
            ws.sheet_properties.tabColor = "FFC7CE"
        for row in ws.iter_rows():
            for c in row:
                c.font = font
        for col, w in (("A", 52), ("B", 6), ("C", 48), ("D", 20), ("E", 24), ("G", 14), ("H", 22)):
            ws.column_dimensions[col].width = w
        ws["D1"].alignment = Alignment(horizontal="left")
        result.append((name, t, total))
    wb.save(path)
    return result


# ----------------------------------------------------------------------------
# Đổi tên chất hàng loạt (vd 'Aqua' -> 'Aqua (Water)')
# ----------------------------------------------------------------------------
def _rename_key(name):
    return " ".join(name_clean.clean_name(name).casefold().split())


def apply_rename_map(tables, mapping):
    """Đổi tên thành phần trong các bảng theo `mapping` [(tên cũ, tên mới), ...]: so khớp NGUYÊN TÊN (không phân biệt hoa/thường,
    khoảng trắng và ký tự thừa), không đổi một phần chuỗi. Lần đổi đầu tiên lưu bản gốc vào `t.items_original` để khôi phục.
    Trả về (số tên đã đổi, số bảng bị ảnh hưởng)."""
    rules = {}
    for old, new in mapping or []:
        k = _rename_key(old)
        if k and clean_cell(new):
            rules[k] = clean_cell(new)
    n_names = n_tables = 0
    if not rules:
        return 0, 0
    for t in tables:
        changed, items = 0, []
        for name, pct in t.items:
            new = rules.get(_rename_key(name))
            if new is not None and new != name:
                items.append((new, pct))
                changed += 1
            else:
                items.append((name, pct))
        if changed:
            if not hasattr(t, "items_original"):
                t.items_original = list(t.items)
            t.items = items
            n_names += changed
            n_tables += 1
    return n_names, n_tables


def restore_original_names(tables):
    n = 0
    for t in tables:
        if hasattr(t, "items_original"):
            t.items = list(t.items_original)
            del t.items_original
            n += 1
    return n


def distinct_names(tables):
    """Tên thành phần khác nhau trong các bảng, kèm số bảng chứa: [(tên, số bảng)] theo thứ tự xuất hiện đầu tiên."""
    count, first = {}, {}
    for t in tables:
        seen = set()
        for name, _p in t.items:
            k = _rename_key(name)
            if not k:
                continue
            first.setdefault(k, name)
            if k not in seen:
                count[k] = count.get(k, 0) + 1
                seen.add(k)
    return [(first[k], count[k]) for k in first]
