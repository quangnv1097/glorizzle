# -*- coding: utf-8 -*-
"""Cửa sổ "Gom dữ liệu mẫu": gom Tên SP | Công dụng | Thành phần từ thư mục file đã dựng."""
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import dung_engine as eng
import gom_data


class GomWindow(tk.Toplevel):
    def __init__(self, master, settings, start_dir=""):
        super().__init__(master)
        self.title("Gom dữ liệu mẫu")
        self.geometry("720x520")
        self.minsize(620, 440)
        self.settings = settings
        self.folder_var = tk.StringVar(value=start_dir or settings.get("gom_dir", ""))
        self.opt_sub = tk.BooleanVar(value=True)
        self.opt_cd = tk.BooleanVar(value=True)
        self.opt_pct = tk.BooleanVar(value=False)

        ttk.Label(self, wraplength=680, justify="left", text=(
            "Quét thư mục chứa các file Form dựng mẫu đã hoàn chỉnh và xuất một bảng Excel nhỏ "
            "gồm 3 thông tin: Tên sản phẩm (I2), Công dụng (B32), Thành phần (sheet 4). "
            "Các sheet/ô khác trong file không được đọc.")).pack(fill="x", padx=12, pady=(12, 6))

        box = ttk.LabelFrame(self, text="Thư mục chứa các file mẫu")
        box.pack(fill="x", padx=12, pady=6)
        box.columnconfigure(0, weight=1)
        ttk.Entry(box, textvariable=self.folder_var).grid(row=0, column=0, sticky="ew", padx=8, pady=8)
        ttk.Button(box, text="Chọn…", command=self._pick).grid(row=0, column=1, padx=8)

        ob = ttk.LabelFrame(self, text="Tùy chọn")
        ob.pack(fill="x", padx=12, pady=6)
        ttk.Checkbutton(ob, text="Quét cả thư mục con", variable=self.opt_sub).pack(anchor="w", padx=10, pady=1)
        ttk.Checkbutton(ob, text="Chỉ lấy file đã có công dụng (B32 không trống)",
                        variable=self.opt_cd).pack(anchor="w", padx=10, pady=1)
        ttk.Checkbutton(ob, text="Kèm hàm lượng (%) sau tên từng thành phần (bảng sẽ nặng hơn)",
                        variable=self.opt_pct).pack(anchor="w", padx=10, pady=1)

        rb = ttk.Frame(self)
        rb.pack(fill="x", padx=12, pady=6)
        self.run_btn = ttk.Button(rb, text="Gom và xuất bảng…", command=self.run)
        self.run_btn.pack(side="left")
        self.progress = ttk.Progressbar(rb, mode="determinate")
        self.progress.pack(side="left", fill="x", expand=True, padx=10)

        lf = ttk.Frame(self)
        lf.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.log = tk.Text(lf, height=10, wrap="word", state="disabled", font=("Consolas", 9))
        sc = ttk.Scrollbar(lf, orient="vertical", command=self.log.yview)
        self.log.configure(yscrollcommand=sc.set)
        self.log.pack(side="left", fill="both", expand=True)
        sc.pack(side="right", fill="y")
        self.log.tag_configure("ok", foreground="#0B7A2B")
        self.log.tag_configure("err", foreground="#B00020")

    def _pick(self):
        p = filedialog.askdirectory(parent=self, title="Chọn thư mục chứa file mẫu",
                                    initialdir=self.folder_var.get() or None)
        if p:
            self.folder_var.set(p)

    def _log(self, text, tag=None):
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n", tag or ())
        self.log.see("end")
        self.log.configure(state="disabled")

    def run(self):
        folder = self.folder_var.get().strip()
        if not os.path.isdir(folder):
            messagebox.showwarning("Thiếu thư mục", "Hãy chọn thư mục chứa file mẫu.", parent=self)
            return
        self.settings["gom_dir"] = folder
        eng.save_settings(self.settings)
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")
        self.run_btn.config(state="disabled")
        self.config(cursor="watch")

        def progress(i, n, name):
            self.progress.config(maximum=max(n, 1), value=i)
            if i % 10 == 0:
                self.update_idletasks()

        try:
            rows, skipped, errors = gom_data.collect(
                folder, recursive=self.opt_sub.get(),
                only_with_congdung=self.opt_cd.get(), progress=progress)
        finally:
            self.config(cursor="")
            self.run_btn.config(state="normal")

        self._log("Đọc xong: %d file lấy được, %d file bỏ qua (chưa có công dụng), %d file lỗi."
                  % (len(rows), len(skipped), len(errors)), "ok" if rows else "err")
        for fn, ex in errors[:20]:
            self._log("  ✖ %s: %s" % (fn, ex), "err")
        if skipped:
            self._log("  Ví dụ file bỏ qua: " + ", ".join(skipped[:5]) + (" …" if len(skipped) > 5 else ""))
        if not rows:
            messagebox.showinfo("Gom dữ liệu", "Không có file nào đủ dữ liệu để xuất.", parent=self)
            return
        out = filedialog.asksaveasfilename(
            parent=self, title="Lưu bảng dữ liệu mẫu", defaultextension=".xlsx",
            initialfile="du_lieu_mau_cong_dung.xlsx", filetypes=[("Excel", "*.xlsx")])
        if not out:
            self._log("Đã hủy lưu bảng.")
            return
        try:
            gom_data.export_xlsx(rows, out, with_percent=self.opt_pct.get())
        except Exception as ex:
            messagebox.showerror("Không lưu được", str(ex), parent=self)
            return
        size = os.path.getsize(out) / 1024.0
        self._log("Đã lưu %d dòng (%.0f KB): %s" % (len(rows), size, out), "ok")
        messagebox.showinfo("Hoàn tất", "Đã xuất %d sản phẩm (%.0f KB).\nBạn kiểm tra nội dung trước khi "
                                        "gửi." % (len(rows), size), parent=self)
