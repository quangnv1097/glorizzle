#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Công cụ chỉnh hàng loạt thông tin dạng sản phẩm cho nhiều file Excel
theo mẫu "Form dựng mẫu".

Sheet đầu tiên của mỗi file:
    I2          : Tên sản phẩm (hiển thị làm tiêu đề cột)
    B4..B30     : Dạng sản phẩm        -> I4..I30  : "Có" / "Không"
    A31 / B31   : Dạng sản phẩm khác   -> ô văn bản (tối đa 500 ký tự)
    A32 / B32   : Mục đích sử dụng     -> ô văn bản (tối đa 500 ký tự)
    B33..B37    : Dạng trình bày       -> I33..I37 : "Có" / "Không"
    A38 / B38   : Dạng trình bày khác  -> ô văn bản (tối đa 500 ký tự)

Giao diện: mỗi file là một cột, mỗi mục là một dòng.
    Ô hồng = "Không", ô xanh = "Có"; ô văn bản nhập trực tiếp.
Khi lưu, chỉ sửa đúng các ô đã thay đổi trong XML của file .xlsx
=> giữ nguyên định dạng, data validation, công thức, các sheet khác.

Yêu cầu: Python 3.8+, openpyxl (pip install openpyxl). Tkinter có sẵn.
"""

import html
import os
import re
import shutil
import tempfile
import warnings
import zipfile
import xml.etree.ElementTree as ET

from openpyxl import load_workbook

# ----------------------------------------------------------------------------
# CẤU TRÚC FORM (muốn thêm/bớt mục chỉ cần sửa các hằng số dưới đây)
# ----------------------------------------------------------------------------
YES, NO = "Có", "Không"
MAX_TEXT = 500                      # Excel đang giới hạn < 501 ký tự

# (loại, số dòng): "check" = ô Có/Không ở cột I (nhãn ở cột B)
#                  "text"  = ô văn bản ở cột B (nhãn ở cột A)
FORM_ROWS = ([("check", r) for r in range(4, 31)]
             + [("text", 31), ("text", 32)]
             + [("check", r) for r in range(33, 38)]
             + [("text", 38)])
# Dòng đứng đầu mỗi nhóm -> hiện thanh tiêu đề nhóm (lấy chữ từ cột A của dòng đó)
SECTION_BEFORE = (4, 33)
LAST_ROW = max(r for _, r in FORM_ROWS)


def clean_text(v):
    """Chuẩn hóa chuỗi: bỏ ký tự điều khiển không hợp lệ trong XML, thống nhất xuống dòng."""
    if v is None:
        return ""
    v = str(v).replace("\r\n", "\n").replace("\r", "\n")
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", v)


# ----------------------------------------------------------------------------
# PHẦN LÕI: đọc / ghi file Excel
# ----------------------------------------------------------------------------
def read_form(path):
    """Đọc 1 file. Trả về dict:
       name   : tên sản phẩm (I2)
       labels : {dòng: nhãn}            (B với ô check, A với ô text)
       titles : {dòng: tiêu đề nhóm}    (cột A của các dòng SECTION_BEFORE)
       values : {dòng: bool | str}      (check -> bool, text -> str)"""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            ws = wb.worksheets[0]
            data = {}
            for r, row in enumerate(
                    ws.iter_rows(min_row=2, max_row=LAST_ROW, min_col=1, max_col=9,
                                 values_only=True), start=2):
                data[r] = tuple(row) + (None,) * (9 - len(row))
        finally:
            wb.close()

    def cell(r, idx):
        return data.get(r, (None,) * 9)[idx]       # idx: 0=A, 1=B, 8=I

    name = clean_text(cell(2, 8)).strip()
    labels, values, titles = {}, {}, {}
    for kind, r in FORM_ROWS:
        if kind == "check":
            labels[r] = clean_text(cell(r, 1)).strip()
            values[r] = clean_text(cell(r, 8)).strip().casefold() == YES.casefold()
        else:
            labels[r] = clean_text(cell(r, 0)).strip()
            values[r] = clean_text(cell(r, 1))
    for r in SECTION_BEFORE:
        titles[r] = clean_text(cell(r, 0)).strip()
    return {"name": name, "labels": labels, "titles": titles, "values": values}


def sheet_path_by_index(zin, index):
    """Đường dẫn XML của sheet thứ `index` (đếm từ 0, theo thứ tự trong workbook)."""
    wb_xml = zin.read("xl/workbook.xml").decode("utf-8")
    ids = re.findall(r'<sheet\b[^>]*?\br:id="([^"]+)"', wb_xml)
    if index >= len(ids):
        raise ValueError("File chỉ có %d sheet, cần ít nhất %d" % (len(ids), index + 1))
    rid = ids[index]
    rels = ET.fromstring(zin.read("xl/_rels/workbook.xml.rels"))
    for rel in rels:
        if rel.get("Id") == rid:
            target = rel.get("Target")
            if target.startswith("/"):
                return target.lstrip("/")
            return "xl/" + target
    raise ValueError("Không tìm thấy đường dẫn của sheet số %d" % (index + 1))


def _first_sheet_path(zin):
    return sheet_path_by_index(zin, 0)


def _col_to_num(letters):
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n


def set_cell_text(sheet_xml, ref, text):
    """Ghi chuỗi `text` vào ô `ref` (vd "B47") dưới dạng TEXT (giữ số 0 đầu của số điện thoại).
    Ô/dòng chưa có trong XML sẽ được chèn đúng thứ tự. Giữ style (s=) của ô nếu có."""
    m = re.fullmatch(r"([A-Z]+)(\d+)", ref)
    if not m:
        raise ValueError("Địa chỉ ô không hợp lệ: %s" % ref)
    col, row = m.group(1), int(m.group(2))
    cnum = _col_to_num(col)
    txt = clean_text(text)

    def build(attrs):
        attrs = re.sub(r'\s+t="[^"]*"', "", attrs)
        if txt == "":
            return '<c r="%s"%s/>' % (ref, attrs)
        esc = html.escape(txt, quote=False)
        return ('<c r="%s"%s t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>'
                % (ref, attrs, esc))

    # 1. ô đã tồn tại
    cm = re.search(r'<c\s+r="%s"([^>]*?)(?:/>|>.*?</c>)' % ref, sheet_xml, re.S)
    if cm:
        return sheet_xml[:cm.start()] + build(cm.group(1)) + sheet_xml[cm.end():]

    # 2. dòng đã tồn tại -> chèn ô đúng vị trí cột
    rm = re.search(r'<row\b([^>]*?\br="%d"[^>]*?)(/>|>(.*?)</row>)' % row, sheet_xml, re.S)
    if rm:
        attrs = re.sub(r'\s+spans="[^"]*"', "", rm.group(1))
        body = rm.group(3) or ""
        pos = len(body)
        for c in re.finditer(r'<c\s+r="([A-Z]+)\d+"', body):
            if _col_to_num(c.group(1)) > cnum:
                pos = c.start()
                break
        body = body[:pos] + build("") + body[pos:]
        new_row = "<row%s>%s</row>" % (attrs, body)
        return sheet_xml[:rm.start()] + new_row + sheet_xml[rm.end():]

    # 3. dòng chưa có -> chèn dòng mới đúng thứ tự
    new_row = '<row r="%d">%s</row>' % (row, build(""))
    sd = re.search(r"<sheetData\s*/>", sheet_xml)
    if sd:
        return sheet_xml[:sd.start()] + "<sheetData>%s</sheetData>" % new_row + sheet_xml[sd.end():]
    for r in re.finditer(r'<row\b[^>]*?\br="(\d+)"', sheet_xml):
        if int(r.group(1)) > row:
            return sheet_xml[:r.start()] + new_row + sheet_xml[r.start():]
    end = sheet_xml.index("</sheetData>")
    return sheet_xml[:end] + new_row + sheet_xml[end:]


def count_sheets(zin):
    wb_xml = zin.read("xl/workbook.xml").decode("utf-8")
    return len(re.findall(r'<sheet\b[^>]*?\br:id="[^"]+"', wb_xml))


def _sst_index(sst_xml, text):
    """Tìm chỉ số shared string thuần `text`; không có thì thêm mới.
    Trả về (index, sst_xml_mới)."""
    idx = 0
    for m in re.finditer(r"<si>(.*?)</si>", sst_xml, re.S):
        body = m.group(1)
        t = re.fullmatch(r'<t(?:\s+xml:space="preserve")?>(.*?)</t>', body, re.S)
        if t and html.unescape(t.group(1)) == text:
            return idx, sst_xml
        idx += 1
    new_item = "<si><t>%s</t></si>" % html.escape(text, quote=False)
    sst_xml = sst_xml.replace("</sst>", new_item + "</sst>")

    def bump(attr):
        nonlocal sst_xml
        sst_xml = re.sub(
            r'(<sst\b[^>]*?\b%s=")(\d+)(")' % attr,
            lambda mm: mm.group(1) + str(int(mm.group(2)) + 1) + mm.group(3),
            sst_xml, count=1)
    bump("uniqueCount")
    bump("count")
    return idx, sst_xml


def _replace_cell(sheet_xml, ref, build):
    """Thay thẻ <c r="ref" ...> bằng chuỗi do build(attrs_không_có_t) tạo ra."""
    pat = re.compile(r'<c\s+r="%s"([^>]*?)(?:/>|>.*?</c>)' % ref, re.S)
    m = pat.search(sheet_xml)
    if not m:
        raise ValueError("Không tìm thấy ô %s trong file" % ref)
    attrs = re.sub(r'\s+t="[^"]*"', "", m.group(1))
    return sheet_xml[:m.start()] + build(attrs) + sheet_xml[m.end():]


def write_changes(path, changes, max_len=MAX_TEXT):
    """Ghi các thay đổi {số_dòng: bool | str}.
       bool -> ô I (Có/Không);  str -> ô B (văn bản);
       khóa chuỗi (vd "I2" tên SP, "B2" nhãn hàng, "B3" danh sách dạng/màu) -> ô văn bản bất kỳ ở sheet 1.
       max_len: giới hạn độ dài ô văn bản (None = không giới hạn).
    Sửa trực tiếp XML nên không làm mất định dạng/validation.
    Ghi ra file tạm, đọc lại kiểm tra rồi mới thay file gốc."""
    if not changes:
        return
    kinds = dict((r, k) for k, r in FORM_ROWS)
    with zipfile.ZipFile(path) as zin:
        sheet_path = _first_sheet_path(zin)
        sheet_xml = zin.read(sheet_path).decode("utf-8")
        sst_xml = zin.read("xl/sharedStrings.xml").decode("utf-8")
        sst_changed = False

        idx_yes = idx_no = None
        if any(kinds.get(r) == "check" for r in changes):
            idx_yes, sst_xml = _sst_index(sst_xml, YES)
            idx_no, sst_xml = _sst_index(sst_xml, NO)
            sst_changed = True

        for r, val in changes.items():
            if isinstance(r, str):                       # ô văn bản tự do ở sheet 1, vd "I2", "B3"
                sheet_xml = set_cell_text(sheet_xml, r, val)
            elif kinds.get(r) == "check":
                i = idx_yes if val else idx_no
                sheet_xml = _replace_cell(
                    sheet_xml, "I%d" % r,
                    lambda a, r=r, i=i: '<c r="I%d"%s t="s"><v>%d</v></c>' % (r, a, i))
            elif kinds.get(r) == "text":
                txt = clean_text(val)
                if max_len and len(txt) > max_len:
                    raise ValueError("Dòng %d dài quá %d ký tự" % (r, max_len))
                if txt == "":
                    build = lambda a, r=r: '<c r="B%d"%s/>' % (r, a)
                else:
                    esc = html.escape(txt, quote=False)
                    build = lambda a, r=r, esc=esc: (
                        '<c r="B%d"%s t="inlineStr"><is><t xml:space="preserve">%s'
                        '</t></is></c>' % (r, a, esc))
                sheet_xml = _replace_cell(sheet_xml, "B%d" % r, build)
            else:
                raise ValueError("Dòng %s không nằm trong cấu trúc form" % r)

        ET.fromstring(sheet_xml.encode("utf-8"))        # đảm bảo XML hợp lệ
        ET.fromstring(sst_xml.encode("utf-8"))

        fd, tmp = tempfile.mkstemp(suffix=".xlsx", dir=os.path.dirname(path) or ".")
        os.close(fd)
        try:
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
                for item in zin.infolist():
                    if item.filename == sheet_path:
                        data = sheet_xml.encode("utf-8")
                    elif item.filename == "xl/sharedStrings.xml" and sst_changed:
                        data = sst_xml.encode("utf-8")
                    else:
                        data = zin.read(item.filename)
                    zout.writestr(item, data)
        except Exception:
            os.remove(tmp)
            raise

    # kiểm tra lại file tạm trước khi thay file gốc
    try:
        chk = read_form(tmp)
        check = chk["values"]
        for r, val in changes.items():
            if isinstance(r, str):
                if r == "I2":
                    if chk["name"] != clean_text(val).strip():
                        raise ValueError("Kiểm tra sau khi ghi không khớp ở ô I2")
                continue
            want = val if kinds[r] == "check" else clean_text(val)
            if check[r] != want:
                raise ValueError("Kiểm tra sau khi ghi không khớp ở dòng %d" % r)
        os.replace(tmp, path)
    except Exception:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise


