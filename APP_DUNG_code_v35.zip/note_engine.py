# -*- coding: utf-8 -*-
"""
Bảng GHI CHÚ theo tên thành phần (vd Citric acid -> pH adjuster).

  - Người dùng tự quản lý trong app (nút "Bảng Ghi chú" ở màn hình chính): thêm / sửa / xóa / nạp từ Excel.
  - Lưu ở thư mục .app_dung của người dùng (ghi_chu.json); lần đầu chạy lấy bảng mẫu có sẵn bên dưới.
  - Dùng ở 2 nơi:
      * Tạo file BTP  : ghi chú ghi vào cột E của từng sheet BTP.
      * Dựng file     : ghi chú ghi vào cột D (từ dòng 5) sheet 4 "Danh sách thành phần"
                         (ô cột E của BTP đã có chữ thì giữ nguyên, chỉ điền vào ô còn trống).
  - Khớp tên: không phân biệt hoa/thường, bỏ khoảng trắng thừa; không khớp được thì thử lại bỏ phần trong ngoặc
    ("Aqua (Water)" khớp dòng "Aqua"). Tên trùng trong bảng: dòng đầu tiên được dùng.
"""
import json
import os
import re
import warnings
from datetime import datetime

import name_clean

USER_DIR = os.path.join(os.path.expanduser("~"), ".app_dung")
FILE_NAME = "ghi_chu.json"

# Bảng mẫu (lấy từ sheet "Thao Tac" của file TH check TP Tools) - dùng cho lần chạy đầu tiên
DEFAULT_ITEMS = [
    ("Citric acid", "pH adjuster"),
    ("Sodium Hydroxide", "pH adjuster"),
    ("BEHENTRIMONIUM CHLORIDE", "Hair conditioning"),
    ("STEARTRIMONIUM CHLORIDE", "Hair conditioning"),
    ("CETRIMONIUM CHLORIDE", "Hair conditioning"),
    ("SODIUM SULFITE", "Antioxidant"),
    ("RESORCINOL", "Hair colorant"),
    ("Potassium Hydroxide", "pH adjuster"),
    ("Tromethamine", "pH adjuster"),
    ("Sodium Citrate", "pH adjuster"),
    ("Urea", "pH adjuster"),
    ("Succinic Acid", "pH adjuster"),
]

_PAREN = re.compile(r"\([^)]*\)|\[[^\]]*\]")


def norm_key(name):
    """Khóa khớp chính xác: làm sạch tên, chữ thường, gộp khoảng trắng."""
    return " ".join(name_clean.clean_name(name or "").casefold().split())


def loose_key(name):
    """Khóa khớp lỏng: bỏ phần trong ngoặc, chỉ giữ chữ-số."""
    s = _PAREN.sub(" ", name_clean.clean_name(name or "").casefold())
    return re.sub(r"[^a-z0-9]+", "", s)


def clean_note(text):
    return " ".join(str(text if text is not None else "").replace("\r", " ").replace("\n", " ").replace("\t", " ").split())


def clean_items(items):
    """[(tên, ghi chú)] -> bỏ dòng trống (không có tên), làm sạch chuỗi. KHÔNG bỏ dòng trùng (người dùng tự xử lý)."""
    out = []
    for it in items or []:
        name = " ".join(str(it[0] if it[0] is not None else "").split())
        note = clean_note(it[1] if len(it) > 1 else "")
        if name:
            out.append((name, note))
    return out


def duplicates(items):
    """Danh sách tên xuất hiện từ 2 lần (theo norm_key) mà ghi chú khác nhau."""
    seen, bad = {}, []
    for n, t in items:
        k = norm_key(n)
        if k in seen and seen[k][1] != t and n not in bad:
            bad.append(n)
        seen.setdefault(k, (n, t))
    return bad


# ----------------------------------------------------------------------------
# Lưu / nạp
# ----------------------------------------------------------------------------
def _path():
    os.makedirs(USER_DIR, exist_ok=True)
    return os.path.join(USER_DIR, FILE_NAME)


def load_items():
    """Bảng ghi chú hiện tại: [(tên, ghi chú)]. Chưa có file lưu -> bảng mẫu."""
    try:
        with open(_path(), encoding="utf-8") as f:
            data = json.load(f)
        return clean_items([(d.get("name", ""), d.get("note", "")) for d in data.get("items", [])])
    except FileNotFoundError:
        return list(DEFAULT_ITEMS)
    except Exception:
        return list(DEFAULT_ITEMS)


def save_items(items):
    items = clean_items(items)
    data = {"version": 1, "updated": datetime.now().isoformat(timespec="seconds"),
            "items": [{"name": n, "note": t} for n, t in items]}
    with open(_path(), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    global _cache
    _cache = None
    return items


class NoteIndex:
    def __init__(self, items):
        self.items = clean_items(items)
        self.exact, self.loose = {}, {}
        for n, t in self.items:
            if not t:
                continue                              # dòng chưa có ghi chú không dùng để điền
            self.exact.setdefault(norm_key(n), t)
            self.loose.setdefault(loose_key(n), t)

    def __len__(self):
        return len(self.exact)

    def lookup(self, name):
        """Ghi chú của thành phần `name` ('' nếu không có)."""
        if not name or not self.exact:
            return ""
        t = self.exact.get(norm_key(name))
        if t is None:
            lk = loose_key(name)
            t = self.loose.get(lk) if lk else None
        return t or ""


_cache = None            # (mtime, NoteIndex)


def get_index():
    """Chỉ mục ghi chú hiện hành (tự nạp lại khi file lưu đổi)."""
    global _cache
    try:
        mtime = os.path.getmtime(_path())
    except OSError:
        mtime = None
    if _cache is None or _cache[0] != mtime:
        _cache = (mtime, NoteIndex(load_items()))
    return _cache[1]


def fill_notes(rows, index=None, overwrite=False):
    """rows: [(tên, hàm lượng, ghi chú[, ...])] -> cùng dạng, ô ghi chú trống được điền theo bảng.
    Trả về (rows mới, số dòng đã điền)."""
    index = index if index is not None else get_index()
    out, n = [], 0
    for it in rows:
        it = tuple(it)
        cur = "" if it[2] is None else str(it[2]).strip()
        if len(it) >= 3 and (overwrite or not cur):
            note = index.lookup(it[0])
            if note:
                it = it[:2] + (note,) + it[3:]
                n += 1
        out.append(it)
    return out, n


# ----------------------------------------------------------------------------
# Excel: nạp / xuất
# ----------------------------------------------------------------------------
def _cell(v):
    return "" if v is None else str(v).strip()


def read_xlsx(path):
    """Đọc cặp cột (tên thành phần | ghi chú ngắn) từ file Excel; tự tìm cặp cột phù hợp nhất trong các sheet.
    Trả về (items, mô tả nguồn 'Sheet!F:G')."""
    from openpyxl import load_workbook
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        wb = load_workbook(path, read_only=True, data_only=True)
    best = (0, None, None, [])
    try:
        for ws in wb.worksheets:
            rows = [[_cell(c) for c in r[:30]] for r in ws.iter_rows(min_row=1, max_row=3000, values_only=True)]
            ncol = max((len(r) for r in rows), default=0)
            for c in range(ncol - 1):
                pairs = []
                for r in rows:
                    a = r[c] if c < len(r) else ""
                    b = r[c + 1] if c + 1 < len(r) else ""
                    if a and b and len(a) <= 80 and len(b) <= 80 and not a.startswith("="):
                        pairs.append((a, b))
                if len(pairs) > best[0]:
                    best = (len(pairs), ws.title, c, pairs)
    finally:
        wb.close()
    n, sheet, c, pairs = best
    if n < 1:
        return [], ""
    if pairs and re.match(r"(?i)^(tên|ten|name|ingredient|inci|thành phần|thanh phan)\b", pairs[0][0]):
        pairs = pairs[1:]                                        # bỏ dòng tiêu đề
    from openpyxl.utils import get_column_letter
    return clean_items(pairs), "%s!%s:%s" % (sheet, get_column_letter(c + 1), get_column_letter(c + 2))


def write_xlsx(items, path):
    from openpyxl import Workbook
    from openpyxl.styles import Font
    wb = Workbook()
    ws = wb.active
    ws.title = "Ghi chu"
    ws.append(["Tên thành phần", "Ghi chú"])
    for n, t in clean_items(items):
        ws.append([n, t])
    for c in ws[1]:
        c.font = Font(bold=True)
    ws.column_dimensions["A"].width = 46
    ws.column_dimensions["B"].width = 34
    wb.save(path)


def merge_items(base, new):
    """Gộp `new` vào `base`: trùng tên (norm_key) thì cập nhật ghi chú, chưa có thì thêm cuối.
    Trả về (danh sách mới, số thêm, số cập nhật)."""
    out = list(base)
    pos = {}
    for i, (n, _t) in enumerate(out):
        pos.setdefault(norm_key(n), i)
    added = updated = 0
    for n, t in new:
        k = norm_key(n)
        if k in pos:
            if out[pos[k]][1] != t:
                out[pos[k]] = (out[pos[k]][0], t)
                updated += 1
        else:
            pos[k] = len(out)
            out.append((n, t))
            added += 1
    return out, added, updated
