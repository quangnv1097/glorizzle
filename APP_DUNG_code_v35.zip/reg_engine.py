# -*- coding: utf-8 -*-
"""
Kiểm tra ngưỡng hàm lượng thành phần mỹ phẩm theo ASEAN Cosmetic Directive.

Nguồn dữ liệu (đóng gói sẵn trong regdb.json, tạo bằng tools/build_regdb.py):
  Annex II (cấm), Annex III (hạn chế), Annex IV Part 1 (chất tạo màu), Annex VI (chất bảo quản),
  Annex VII (chất chống nắng) + bảng tổng hợp tự lập của người dùng.
Nguyên tắc: Annex được ƯU TIÊN hơn bảng của người dùng; mâu thuẫn được ghi rõ để người dùng quyết.

Nhóm kết quả:  CAM = cấm | GH = giới hạn nồng độ (bắt buộc ghi %) | GT = cần giải trình | KGH = không giới hạn |
               ? = chưa xác định (cần người dùng xác nhận, KHÔNG tự coi là không giới hạn).
"""
import json
import os
import re
import sys
import unicodedata

import master_table
import name_clean

_MODDIR = os.path.dirname(os.path.abspath(__file__))
# regdb.json nằm cạnh mã (kể cả mã được cập nhật tải về); không có thì tìm trong gói đóng sẵn
HERE = _MODDIR if os.path.isfile(os.path.join(_MODDIR, "regdb.json")) else (getattr(sys, "_MEIPASS", None) or _MODDIR)

# ----------------------------------------------------------------------------
# Chuẩn hóa tên
# ----------------------------------------------------------------------------
_DATE_NOISE = re.compile(r"\b\d{4}-\d+,?\s*\d{1,2}(?:st|nd|rd|th)?\s+\w+\s+\d{4}\b|\b\d{1,2}(?:st|nd|rd|th)\s+\w+\s+\d{4}\b", re.I)


def nkey(s):
    s = unicodedata.normalize("NFKC", str(s or "")).lower()
    s = s.replace("’", "'")
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return " ".join(s.split())


def strip_cas(s):
    s = _DATE_NOISE.sub(" ", s)               # bỏ ngày phát hành TRƯỚC (tránh nuốt số '22' của '22nd June' vào CAS)
    s = re.sub(r"(?i)\(?\s*cas\s*(?:no\.?|number)?\s*[\d\-/ ,;]*\)?", " ", s)
    s = re.sub(r"\(\s*(?:inn|inci|ban|usan)\s*\)", " ", s, flags=re.I)
    return _DATE_NOISE.sub(" ", s)


SYNONYMS = {   # tên thường gặp (không chuẩn INCI) -> tên INCI. Mở rộng qua ~/.app_dung/dong_nghia.json
    "peppermint oil": "Mentha Piperita Oil", "carbamide peroxide": "Urea Peroxide", "vitamin c": "Ascorbic Acid",
    "vitamin e": "Tocopherol", "vitamin b3": "Niacinamide", "vitamin b5": "Panthenol", "vitamin a": "Retinol",
    "fragrance": "Parfum", "perfume": "Parfum", "aloe vera": "Aloe Barbadensis Leaf Extract",
    "aloe vera gel": "Aloe Barbadensis Leaf Juice", "tea tree oil": "Melaleuca Alternifolia Leaf Oil",
    "lavender oil": "Lavandula Angustifolia Oil", "rose water": "Rosa Damascena Flower Water",
    "green tea extract": "Camellia Sinensis Leaf Extract", "shea butter": "Butyrospermum Parkii Butter",
    "argan oil": "Argania Spinosa Kernel Oil", "jojoba oil": "Simmondsia Chinensis Seed Oil",
    "coconut oil": "Cocos Nucifera Oil", "olive oil": "Olea Europaea Fruit Oil",
    "sweet almond oil": "Prunus Amygdalus Dulcis Oil", "baking soda": "Sodium Bicarbonate",
    "caustic soda": "Sodium Hydroxide", "spearmint oil": "Mentha Viridis Leaf Oil", "lemon oil": "Citrus Limon Peel Oil",
    "orange oil": "Citrus Aurantium Dulcis Peel Oil", "eucalyptus oil": "Eucalyptus Globulus Leaf Oil",
    "hydrogen peroxide solution": "Hydrogen Peroxide", "h2o2": "Hydrogen Peroxide", "ppd": "p-Phenylenediamine",
    "vitamin b6": "Pyridoxine HCl", "vitamin b12": "Cyanocobalamin", "vitamin h": "Biotin",
    "salicylate": "Salicylic Acid", "sls": "Sodium Lauryl Sulfate", "edta": "Disodium EDTA",
}
_USER_SYN = None


def _synonyms():
    global _USER_SYN
    if _USER_SYN is None:
        _USER_SYN = {nkey(k): v for k, v in SYNONYMS.items()}
        extra = _load_json(os.path.join(os.path.expanduser("~"), ".app_dung", "dong_nghia.json"), {})
        if isinstance(extra, dict):
            _USER_SYN.update({nkey(k): v for k, v in extra.items() if k and v})
    return _USER_SYN


def name_variants(name, split=True):
    """Các khóa có thể dùng để tra một tên thành phần: đầy đủ, bỏ ngoặc, phần trong ngoặc, bỏ '(nano)'."""
    name = name_clean.split_name_pct(name_clean.clean_name(name))[0]       # bỏ '5%' dính cuối tên nếu có
    out = []

    def add(x):
        k = nkey(x)
        if k and k not in out:
            out.append(k)
    add(name)
    add(re.sub(r"\(.*?\)", " ", name))
    for inner in re.findall(r"\((.*?)\)", name):
        if not re.fullmatch(r"(?i)\s*(nano|inn|ci\s*\d+|\d+)\s*", inner):
            add(inner)
    add(re.sub(r"(?i)\(\s*nano\s*\)", " ", name))
    syn = _synonyms()
    for k in list(out):
        if k in syn:
            add(syn[k])
    if split and "/" in name:                # "Water/Aqua/Eau", "Parfum/Fragrance": thử từng phần (chỉ để tra bảng của bạn)
        parts = [p.strip() for p in name.split("/")]
        if any(len(nkey(p)) >= 4 for p in parts):
            for p in parts:
                if len(nkey(p)) >= 4:
                    add(p)
                    for k in [x for x in (nkey(p),) if x in syn]:
                        add(syn[k])
    return out


_GENERIC = {"salts", "and its salts", "its salts", "esters", "and", "or", "acid", "oil", "extract", "water", "salt"}


def alias_keys(entry):
    """Tên gọi của một mục Annex dùng để khớp: tách theo dấu phẩy, chấm phẩy, gạch chéo; bỏ CAS và ghi chú."""
    keys = []
    for raw in entry.get("names", []):
        t = strip_cas(raw)
        for inner in re.findall(r"\(([^()]{6,40})\)", t):          # tên INCI/thông dụng nằm trong ngoặc, vd (chlorphenesin)
            k1 = nkey(inner)
            if re.fullmatch(r"[a-z ]{6,}", k1) and not re.match(r"^(inn|inci|nano|cas|sum|as |acid|expressed|salts?|and|of|the|see|for|in|use)\b", k1) \
                    and k1 not in keys and k1 not in _GENERIC:
                keys.append(k1)
        if entry.get("annex") != "II":
            pm = re.match(r"^([A-Za-z][A-Za-z0-9 \-]{5,40}),\s+(?:its|their|borates|salts?|esters?|derivatives?|and|or)\b", t.strip())
            if pm:
                kp = nkey(pm.group(1))
                if kp not in keys:
                    keys.append(kp)
        hm = re.match(r"^(.*?),\s+(?:if|except|unless|when|only|with|excluding|containing|including)\b", t, re.I)
        if hm:
            k0 = nkey(hm.group(1))
            if len(k0) >= 4 and k0 not in keys:
                keys.append(k0)
        for part in re.split(r"[;/]|,\s+(?=[A-Z][a-z])|\band its (?:salts|esters)\b|\(\s*\d+\s*\)|\[\s*\d+\s*\]", t):
            part = re.sub(r"\([^)]*\)", lambda m: " " + m.group(0)[1:-1] + " " if len(m.group(0)) < 25 else " ", part)
            k = nkey(part)
            if len(k) >= 5 and k not in _GENERIC and not re.fullmatch(r"[\d ]+", k) and k not in keys:
                keys.append(k)
    return keys


_COND_BAN = re.compile(r"\b(except|unless|if |when |only|unavoidable|other than|provided|with the exception|≥|>\s*\d|\d\s*%)", re.I)
_SUBST = re.compile(r"(?:di|tri)?(?:methoxy|hydroxy|amino|acetyl|chloro|bromo|nitro|methyl|ethyl|propyl|butyl|phenyl|fluoro|iodo|oxo|carboxy)+")
SEVERITY_ANNEX = {"II": 0, "III": 1, "VII": 2, "VI": 3}
_BINOMIAL = re.compile(r"^([A-Z][a-z]{3,}) ([a-z]{4,})\b")

# ----------------------------------------------------------------------------
# Quy đổi hàm lượng (theo khối lượng phân tử): hệ số = (khối lượng dạng quy chiếu) / (khối lượng dạng đang dùng)
# ----------------------------------------------------------------------------
CONVERSIONS = {
    # khóa: (dạng quy chiếu, hệ số, từ khóa trong ngưỡng cho biết cần quy đổi)
    "sodium benzoate": ("acid benzoic", 122.12 / 144.10, ("acid",)),
    "potassium sorbate": ("acid sorbic", 112.13 / 150.22, ("acid",)),
    "sodium sorbate": ("acid sorbic", 112.13 / 134.11, ("acid",)),
    "calcium sorbate": ("acid sorbic", 224.26 / 262.33, ("acid",)),
    "sodium salicylate": ("acid salicylic", 138.12 / 160.10, ("acid", "base")),
    "sodium dehydroacetate": ("acid dehydroacetic", 168.15 / 190.13, ("acid",)),
    "methylparaben": ("acid 4-hydroxybenzoic", 138.12 / 152.15, ("acid",)),
    "ethylparaben": ("acid 4-hydroxybenzoic", 138.12 / 166.17, ("acid",)),
    "propylparaben": ("acid 4-hydroxybenzoic", 138.12 / 180.20, ("acid",)),
    "butylparaben": ("acid 4-hydroxybenzoic", 138.12 / 194.23, ("acid",)),
    "sodium methylparaben": ("acid 4-hydroxybenzoic", 138.12 / 174.13, ("acid",)),
    "sodium metabisulfite": ("SO2", 128.13 / 190.10, ("so2", "so 2")),
    "sodium sulfite": ("SO2", 64.07 / 126.04, ("so2", "so 2")),
    "potassium metabisulfite": ("SO2", 128.13 / 222.32, ("so2", "so 2")),
    "ammonium hydroxide": ("NH3", 17.03 / 35.05, ("nh3",)),
}

# ----------------------------------------------------------------------------
# Hợp chất ("bắc cầu"): nguyên liệu là hỗn hợp -> tính chất giới hạn nằm bên trong
#   aliases: các tên gọi có thể gặp;  components: [(tên INCI, tỉ lệ khối lượng trong nguyên liệu)]
# ĐÂY LÀ DỮ LIỆU THAM KHẢO CHUNG; thành phần chính xác nên theo CoA/TDS của nhà cung cấp.
# ----------------------------------------------------------------------------
COMPOUNDS = [
    {"aliases": ["Phenoxyethanol (and) Ethylhexylglycerin", "Phenoxyethanol & Ethylhexylglycerin", "Euxyl PE 9010",
                 "EHG 9010", "PE 9010"],
     "components": [("Phenoxyethanol", 0.90), ("Ethylhexylglycerin", 0.10)],
     "note": "Euxyl PE 9010: phenoxyethanol 90% + ethylhexylglycerin 10% (TDS Ashland/Schülke)."},
    {"aliases": ["Methylchloroisothiazolinone (and) Methylisothiazolinone", "Methylchloroisothiazolinone/Methylisothiazolinone",
                 "Kathon CG", "MCI/MI", "CMIT/MIT"],
     "components": [("Methylchloroisothiazolinone", 0.0113), ("Methylisothiazolinone", 0.0037)],
     "note": "Kathon CG: 1,5% hoạt chất, tỉ lệ 3:1 (CMIT ~1,13% / MIT ~0,37%, TDS LANXESS). Ngưỡng Annex VI mục 39 tính trên hỗn hợp 3:1."},
]

_USER_DIR = os.path.join(os.path.expanduser("~"), ".app_dung")


def _load_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


# ----------------------------------------------------------------------------
# Kho quy định
# ----------------------------------------------------------------------------
class Finding:
    def __init__(self, name, pct):
        self.name = name
        self.pct = pct                  # hàm lượng trong công thức (số) hoặc None
        self.pct_text = ""
        self.group = "?"                # CAM | GH | GT | KGH | ?
        self.status = ""                # mã trạng thái (xem STATUS_TEXT)
        self.effective = None           # hàm lượng quy đổi để so ngưỡng
        self.limits = []                # các ngưỡng số rút từ văn bản
        self.limit_text = ""
        self.sources = []               # ["Annex III #98", "Bảng của bạn", ...]
        self.notes = []
        self.from_compound = ""         # tên hợp chất nếu chất này được tính bắc cầu
        self.conflict = ""
        self.multi_role = False
        self.master_only = False
        self.ctx = ""
        self.master_limits = []

    @property
    def needs_pct(self):
        return self.group in ("GH", "CAM")


STATUS_TEXT = {
    "CAM": "CẤM",
    "CAMDK": "CẤM CÓ ĐIỀU KIỆN - đọc nguyên văn",
    "VUOT": "VƯỢT NGƯỠNG",
    "THIEU": "THIẾU % (bắt buộc ghi)",
    "XEM": "CẦN XÁC NHẬN NGỮ CẢNH",
    "DAT": "Đạt (ghi %)",
    "KT": "KIỂM TRA THỦ CÔNG",
    "GT": "CẦN GIẢI TRÌNH",
    "KGH": "Không giới hạn",
    "UNK": "CHƯA XÁC ĐỊNH",
    "KGHS": "Không thấy trong Annex (suy ra KGH)",
}
SEVERITY = {"KGHS": 8, "CAM": 0, "CAMDK": 1, "VUOT": 1, "THIEU": 2, "UNK": 3, "XEM": 4, "KT": 5, "GT": 6, "DAT": 7, "KGH": 8}


class RegDB:
    def __init__(self, path=None):
        data = _load_json(path or os.path.join(HERE, "regdb.json"), {"entries": [], "master": [], "version": ""})
        self.version = data.get("version", "")
        self.entries = data.get("entries", [])
        self.notes = data.get("master_notes", [])
        self._builtin_master = list(data.get("master", []))
        self._builtin_notes = list(data.get("master_notes", []))
        self.index = {}                 # khóa tên -> list[(entry, 'exact')]
        self.cas = {}
        self.contains = []              # (khóa 'genus species', entry) cho thực vật bị cấm
        self.ci = {}                    # số CI -> entry Annex IV
        self.master = {}
        self.user = _load_json(os.path.join(_USER_DIR, "user_status.json"), {})
        self.compounds = list(COMPOUNDS) + [c for c in _load_json(os.path.join(_USER_DIR, "hop_chat.json"), [])
                                           if isinstance(c, dict) and c.get("aliases") and c.get("components")]
        self._compound_idx = {}
        self._compound_sets = {}
        for c in self.compounds:
            for a in c["aliases"]:
                self._compound_idx[nkey(a)] = c
            comp_keys = frozenset(nkey(n) for n, _f in c["components"])
            if len(comp_keys) > 1:
                self._compound_sets[comp_keys] = c
        self._build(data)
        um = master_table.load_user_master() if path is None else None      # bảng người dùng đã nạp (nhớ giữa các lần mở app)
        if um:
            self.set_master(um["rows"], um.get("notes", []), {"builtin": False, "source": um.get("source", ""),
                            "mtime": um.get("mtime", 0), "loaded_at": um.get("loaded_at", ""), "count": len(um["rows"])})
        else:
            self.set_master(self._builtin_master, self._builtin_notes, {"builtin": True, "count": len(self._builtin_master)})

    def set_master(self, rows, notes=None, meta=None):
        """Thay bảng 'Tổng hợp thành phần' đang dùng (tại chỗ - các cửa sổ đang mở dùng luôn bản mới)."""
        self.master = {}
        self.master_rows = list(rows)
        self.notes = list(notes or [])
        self.master_meta = meta or {"builtin": False, "count": len(rows)}
        for row in self.master_rows:
            st = row.get("status", "") or ""
            for k in name_variants(row["name"], split=False):
                self.master.setdefault(k, {"name": row["name"], "status": st, "note": row.get("note", "")})

    _CATIONS = ("sodium", "potassium", "calcium", "magnesium", "ammonium", "mea", "tea")

    def _salt_aliases(self, e, keys):
        txt = " ".join(e.get("names", [])).lower()
        if e["annex"] == "II" or not ("its salts" in txt or (e["annex"] == "VI" and "salt" in txt)):
            return []
        out = []
        for k in keys:
            m = re.fullmatch(r"([a-z]+?)ic acid", k)
            if m:
                for c in self._CATIONS:
                    out.append("%s %sate" % (c, m.group(1)))
        return out

    # Tên INCI hiện hành khác tên hóa học ghi trong Annex -> gắn thêm tên INCI vào mục có cùng CAS (kiểm chứng bằng CAS)
    INCI_BY_CAS = {
        "70356-09-1": ["Butyl Methoxydibenzoylmethane", "Avobenzone"],
        "5466-77-3": ["Ethylhexyl Methoxycinnamate", "Octinoxate", "Octyl Methoxycinnamate"],
        "118-60-5": ["Ethylhexyl Salicylate", "Octisalate", "Octyl Salicylate"],
        "88122-99-0": ["Ethylhexyl Triazone", "Octyl Triazone"],
        "154702-15-5": ["Diethylhexyl Butamido Triazone", "Iscotrizinol"],
        "187393-00-6": ["Bis-Ethylhexyloxyphenol Methoxyphenyl Triazine", "Bemotrizinol", "Tinosorb S"],
        "103597-45-1": ["Methylene Bis-Benzotriazolyl Tetramethylbutylphenol", "Bisoctrizole", "Tinosorb M"],
        "27503-81-7": ["Phenylbenzimidazole Sulfonic Acid", "Ensulizole"],
        "21245-02-3": ["Ethylhexyl Dimethyl PABA", "Padimate O", "Octyl Dimethyl PABA"],
        "116242-27-4": ["PEG-25 PABA"],
        "38102-62-4": ["4-Methylbenzylidene Camphor", "Enzacamene"],
        "302776-68-7": ["Diethylamino Hydroxybenzoyl Hexyl Benzoate", "Uvinul A Plus"],
        "180898-37-7": ["Disodium Phenyl Dibenzimidazole Tetrasulfonate", "Bisdisulizole Disodium"],
        "207574-74-1": ["Polysilicone-15", "Dimethicodiethylbenzalmalonate"],
        "52793-97-2": ["Camphor Benzalkonium Methosulfate"],
        "56039-58-8": ["Benzylidene Camphor Sulfonic Acid"],
        "113783-61-2": ["Polyacrylamidomethyl Benzylidene Camphor"],
        "31274-51-8": ["Tris-Biphenyl Triazine"],
        "55514-22-2": ["Phenylene Bis-Diphenyltriazine"],
        "60372-77-2": ["Ethyllauroyl Arginate HCl", "Ethyl Lauroyl Arginate HCl"],
        "6440-58-0": ["DMDM Hydantoin"],
        "78491-02-8": ["Diazolidinyl Urea"],
        "39236-46-9": ["Imidazolidinyl Urea"],
        "1314-13-2": ["Zinc Oxide"],
        "13463-67-7": ["Titanium Dioxide"],
    }

    def _build(self, data):
        for e in self.entries:
            if e["annex"] == "IV":
                m = re.search(r"\d{5}", e["names"][0])
                if m:
                    self.ci.setdefault(m.group(), e)
                continue
            keys = alias_keys(e)
            if e["annex"] != "II":
                keys = keys + [re.sub(r"^\d+[a-z]? ", "", k) for k in keys if re.match(r"^\d+[a-z]? [a-z]{6,}", k)]
            for k in keys + self._salt_aliases(e, keys):
                self.index.setdefault(k, []).append(e)
            for c in e.get("cas", []):
                self.cas.setdefault(c, []).append(e)
            if e["annex"] == "II":
                for raw in e["names"]:
                    mm = _BINOMIAL.match(strip_cas(raw).strip())
                    if mm:
                        self.contains.append((nkey(mm.group(1) + " " + mm.group(2)), e))
        for cas, names in self.INCI_BY_CAS.items():          # chỉ gắn vào Annex VI/VII/III có đúng CAS đó
            for e in self.cas.get(cas, []):
                if e["annex"] in ("III", "VI", "VII"):
                    for nm in names:
                        k = nkey(nm)
                        if e not in self.index.setdefault(k, []):
                            self.index[k].append(e)
        for e in self.entries:                              # các muối borat dùng tên INCI riêng
            if e["annex"] == "III" and "tetraborates" in " ".join(e.get("names", [])).lower() and e["ref"] == "1a":
                for nm in ("Sodium Borate", "Borax", "Sodium Tetraborate", "Disodium Tetraborate", "Potassium Borate",
                           "Sodium Metaborate", "Magnesium Borate", "Calcium Borate", "Ammonium Borate"):
                    k = nkey(nm)
                    if e not in self.index.setdefault(k, []):
                        self.index[k].append(e)
        # (bảng 'Tổng hợp thành phần' được lập chỉ mục trong set_master)

    # ------------------------------------------------------------ gần giống
    def _build_token_index(self):
        """token lõi -> [(tập token lõi của tên gọi, mục Annex)] cho Annex II/III/VI/VII. Dẫn xuất muối: 'lactic' -> 'lactate'."""
        self._tok = {}
        seen = set()
        for k, ents in self.index.items():
            core = _core_tokens(k)
            if not core:
                continue
            for e in ents:
                if e["annex"] not in ("II", "III", "VI", "VII"):
                    continue
                txt = " ".join(e.get("names", [])).lower() + " " + (e.get("text", "") or "").lower()
                salty = any(w in txt for w in ("salt", "derivative", "ester"))
                variants = {frozenset(core)}
                if " and " in " " + k + " " and "acid" in k.split():
                    for part in re.split(r"\band\b", k):
                        pc = _core_tokens(part)
                        if pc:
                            variants.add(frozenset(pc))
                if salty:
                    for base in list(variants):
                        alt = {(t[:-2] + "ate") if (t.endswith("ic") and len(t) >= 6) else t for t in base}
                        if alt != set(base):
                            variants.add(frozenset(alt))
                for v in variants:
                    sig = (v, e["annex"], e["ref"])
                    if sig in seen:
                        continue
                    seen.add(sig)
                    for t in v:
                        self._tok.setdefault(t, []).append((v, e))
        self._tok_df = {t: len({id(e) for _v, e in lst}) for t, lst in self._tok.items()}
        self._tok_long = [t for t in self._tok if len(t) >= 7]

    def near_matches(self, name, limit=3):
        """Mục Annex mà tên thành phần chứa đủ các token lõi của tên gọi (hoặc ngược lại) - dùng để cảnh báo 'gần giống'."""
        if not hasattr(self, "_tok"):
            self._build_token_index()
        n = name_clean.split_name_pct(name_clean.clean_name(name))[0]
        N = set()
        for key in name_variants(n, split=False)[:1]:
            N |= _core_tokens(key)
        if not N:
            return []
        for n_tok in list(N):                       # dẫn xuất thế: "methoxysalicylate" ~ "salicylate" (không áp dụng cho "polysorbate")
            for tau in self._tok_long:
                if n_tok != tau and n_tok.endswith(tau) and _SUBST.fullmatch(n_tok[:-len(tau)]):
                    N.add(tau)
        out, seen = [], set()
        for t in N:
            for v, e in self._tok.get(t, []):
                sig = (e["annex"], e["ref"])
                if sig in seen:
                    continue
                wv = _word_tokens(v)
                if not wv:
                    continue
                if v <= N:
                    one = next(iter(wv))
                    ok = len(v) >= 2 or (len(one) >= 6 and self._tok_df.get(one, 99) <= 6)
                elif len(_word_tokens(N)) >= 2 and N <= v:
                    ok = True
                else:
                    ok = False
                if ok and e["annex"] == "II" and re.search(r"polymer", n, re.I):
                    ok = False                         # polymer của monomer bị cấm không phải chính monomer
                if ok:
                    seen.add(sig)
                    out.append((SEVERITY_ANNEX.get(e["annex"], 9), -len(v), e))
        out.sort(key=lambda x: (x[0], x[1]))
        return [e for _a, _b, e in out[:limit]]

    # ------------------------------------------------------------ tra cứu
    def lookup(self, name, cas=None):
        """Trả về (list mục Annex, dòng bảng của bạn hoặc None, cách khớp)."""
        hits, how = [], ""
        for k in name_variants(name, split=False):   # Annex: KHÔNG tách theo '/' (vd 'Styrene/Acrylates Copolymer' khác 'Styrene')
            if k in self.index:
                hits = self.index[k]
                how = "tên"
                break
        if not hits and cas and cas in self.cas:
            hits, how = self.cas[cas], "CAS"
        master = None
        for k in name_variants(name):
            if k in self.master:
                master = self.master[k]
                break
        if not master:
            user = self.user.get(nkey(name))
            if user:
                master = {"name": name, "status": user.get("status", ""), "_user": True}
        return hits, master, how


_NUM = re.compile(r"(?<![\w.,])(\d+(?:[.,]\d+)?)\s*(?:%|phần trăm)")
_NUM_BARE = re.compile(r"[<≤]\s*=?\s*(\d+(?:[.,]\d+)?)")


def numeric_limits(text):
    """Các ngưỡng % rút ra từ văn bản (ví dụ '(a) 3.0 %  (b) 2.0%' -> [3.0, 2.0])."""
    vals = []
    t = text or ""
    for m in _NUM.finditer(t):
        try:
            vals.append(float(m.group(1).replace(",", ".")))
        except ValueError:
            pass
    if not vals:
        for m in _NUM_BARE.finditer(t):
            try:
                vals.append(float(m.group(1).replace(",", ".")))
            except ValueError:
                pass
    return vals


def parse_pct(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    t = str(v).replace("%", "").replace(" ", "").replace(",", ".")
    t = t.lstrip("<>~≤≥")
    try:
        return float(t)
    except ValueError:
        return None


_BASIS_HINT = ("acid", "so2", "so 2", "nh3", "base")


def classify(db, name, pct, context):
    """Phân loại 1 thành phần. context: dict(mix_ratio=float|0, ...)."""
    f = Finding(name, pct)
    cas = None
    hits, master, how = db.lookup(name, cas)
    mtext = (master or {}).get("status", "") or ""
    mlow = mtext.lower()
    if master and master.get("note"):
        f.notes.append("Ghi chú trong bảng của bạn: " + master["note"][:200])

    # --- 1. Annex II (cấm)
    banned = [e for e in hits if e["annex"] == "II"]
    nk = nkey(name)
    if not banned and re.match(r"^rh[- ]", str(name).strip().lower()):
        f.group, f.status = "CAM", "CAM"
        f.sources.append("Bảng của bạn: tiền tố 'rh-' bị cấm")
        return f
    if not banned:
        for key, e in db.contains:
            if " " + key + " " in " " + nk + " ":
                banned = [e]
                f.notes.append("tên loài thực vật nằm trong Annex II - cần xem chi tiết (có thể chỉ cấm một phần/chế phẩm)")
                break
    if banned:
        e = banned[0]
        by_species = bool(f.notes)
        f.group, f.status = "CAM", ("CAMDK" if (by_species or _COND_BAN.search(e["names"][0])) else "CAM")
        f.sources.append("Annex II #%s" % e["ref"])
        f.limit_text = e["names"][0][:160]
        return f

    # --- 2. Annex hạn chế (III, VI, VII) và chất tạo màu (IV)
    restricted = [e for e in hits if e["annex"] in ("III", "VI", "VII")]
    ci = re.search(r"\bci\s*(\d{5})\b", str(name), re.I)
    if ci and ci.group(1) in db.ci:
        e4 = db.ci[ci.group(1)]
        if e4.get("other"):
            restricted = restricted or [e4]
        else:
            f.notes.append("CI %s có trong Annex IV Part 1 (trường hợp áp dụng %s)" % (ci.group(1), e4.get("field") or "?"))
    elif ci:
        f.notes.append("CI %s KHÔNG có trong Annex IV Part 1 - kiểm tra Annex III (thuốc nhuộm tóc) hoặc bị cấm" % ci.group(1))
        f.group, f.status = "?", "UNK"
    if restricted:
        f.group = "GH"
        texts = []
        for e in restricted:
            f.sources.append("Annex %s #%s" % (e["annex"], e["ref"]))
            t = e.get("max", "")
            if e["annex"] == "IV":
                t = e.get("other", "")
            texts.append(t)
        f.limit_text = " | ".join(t.replace("\n", " ") for t in texts if t)[:300]
        f.ctx = " ".join(t for t in texts if t) + " " + " ".join(e.get("other", "") + " " + e.get("field", "") for e in restricted)
        eT = " ".join(e.get("other", "") for e in restricted if e["annex"] in ("III", "VII"))
        f.limits = numeric_limits(" ".join(texts))
        for v in numeric_limits(eT):                      # ngưỡng ghi ở cột 'điều kiện khác' (vd 1,25% sau khi trộn)
            if v not in f.limits:
                f.limits.append(v)
        if not f.limits:
            f.limits = numeric_limits(" ".join(e.get("field", "") for e in restricted if e["annex"] == "III"))
        if all(e["annex"] == "VI" for e in restricted) and any(re.search(r"\(\+\)|\(\d{1,2}\)", e["names"][0]) for e in restricted):
            f.multi_role = True
            f.notes.append("Annex VI chỉ áp dụng khi dùng làm chất bảo quản; chức năng khác xem Annex III")
        if not f.limits and master and mtext:
            f.limits = numeric_limits(mtext)
            if f.limits:
                f.master_only = True
                f.notes.append("ngưỡng lấy từ bảng của bạn")
        other = " ".join(e.get("other", "") + " " + e.get("warn", "") for e in restricted if e["annex"] != "IV").lower()
        if master and mlow.startswith("kgh") and not master.get("_user"):
            f.conflict = "Bảng của bạn ghi 'kgh' nhưng Annex có giới hạn - ưu tiên Annex"
        if mtext and not mlow.startswith("kgh"):
            f.notes.append("Bảng của bạn: " + mtext[:160])
            f.master_limits = numeric_limits(mtext)
    elif master:
        f.sources.append("Bảng của bạn" if not master.get("_user") else "Bạn đã xác nhận")
        if mlow.startswith(("cấm", "cam")):
            f.group = "CAM"
            f.status = "CAM" if mlow.strip(" .") in ("cấm", "cam") else "CAMDK"
            f.limit_text = mtext
            return f
        if mlow.startswith("kgh") and "," not in mlow[:6]:
            f.group = "KGH"
            if "," in mtext:
                f.notes.append(mtext[:160])
        elif mlow.startswith(("gt", "gtrinh", "gtr")):
            f.group = "GT"
            f.limit_text = mtext
        else:
            f.group = "GH"
            f.limit_text = mtext
            f.limits = numeric_limits(mtext)
            f.master_only = True
    else:
        f.group, f.status = ("?", "UNK") if not f.status else (f.group, f.status)

    if f.group == "?" and not f.status.startswith("UNK_KEEP") and not ci:
        _resolve_unmatched(db, f, name)
        if f.status in ("XEM", "GT", "KGHS", "UNK"):
            return f

    if f.group == "?":
        f.status = "UNK"
        return f
    if f.group == "KGH":
        f.status = "KGH"
        return f
    if f.group == "GT":
        f.status = "GT"
        return f

    # --- 3. Giới hạn số: quy đổi + ngữ cảnh trộn
    _evaluate(f, name, context)
    return f


_STOP = set("""acid acids oil oils extract extracts water sodium potassium calcium magnesium ammonium seed seeds leaf leaves root roots
flower flowers fruit fruits bark juice butter wax glycol alcohol salt salts and its their of the with in from for as other than
derivative derivatives ester esters compound compounds hydrolyzed hydrogenated polymer copolymer crosspolymer peg ppg hydroxide
chloride sulfate phosphate lauryl cetyl stearyl glyceryl caprylic capric triglyceride amino hydroxy methyl ethyl propyl butyl
dioxide oxide nitrate citrate acetate cell powder complex mixture mixtures fatty natural vegetable plant
isethionate diacetate digluconate dihydrochloride hydrochloride hydrobromide mesylate tosylate succinate tartrate fumarate maleate
carbonate bicarbonate""".split())
_DYE_LIKE = re.compile(r"\b(?:basic|acid|direct|disperse|solvent|hc|d&c|fd&c|ext\.? d&c|pigment)\s+(?:red|blue|yellow|green|orange|violet|brown|black|white)\b"
                       r"|\b(?:red|blue|yellow|green|orange|violet|brown|black)\s*\d{1,3}\b", re.I)
_PRESERV_UV_LIKE = re.compile(r"benzophenone|cinnamate|triazin|camphor|benzotriazol|anthranilate|\bpaba\b|isothiazolinone|paraben|"
                              r"hydantoin|formaldehyde|iodopropynyl|chlorphenesin|dehydroacet|sorbate|benzoate|triclosan|"
                              r"imidazolidinyl|thiocyanate|pyrithione|hexamidine|chlorhexidine|bronopol|glutaral", re.I)
_GT_PATTERNS = (   # nhóm "giải trình" suy từ tên, theo cách phân loại trong bảng của người dùng
    ("peptide", re.compile(r"peptide|fibronectin|growth factor|\begf\b|\bfgf\b", re.I)),
    ("nguồn gốc", re.compile(r"keratin|collagen|elastin|placenta|heparin|casein|sericin|milk protein|\bdna\b|\brna\b|\bsilk\b", re.I)),
    ("vi sinh", re.compile(r"ferment|lysate|filtrate|lactobacillus|lacticaseibacillus|ligilactobacillus|bifida|bifido|bacillus|"
                           r"saccharomyces|streptococcus|alcaligenes|leuconostoc|lactococcus|\byeast\b|cell culture", re.I)),
    ("citrus", re.compile(r"\bcitrus\b|\borange\b|\blemon\b|\blime\b|bergamot|grapefruit|mandarin|tangerine|\byuzu\b", re.I)),
    ("amin", re.compile(r"amine\b|amide (?:dea|mea)|\bdea\b|\btea\b|olamine|ethanolamine|\b(?:alanine|glycine|citrulline|lysine|proline|"
                        r"serine|threonine|valine|leucine|histidine|phenylalanine|tyrosine|tryptophan|methionine|ornithine|taurine)\b", re.I)),
    ("lecithin", re.compile(r"lecithin", re.I)),
)


def _core_tokens(key):
    """Token lõi: từ có nghĩa (>=4 ký tự, không phải từ phổ thông) + số (để 'Basic Blue 99' khác 'Basic Blue 26')."""
    return {t for t in key.split() if (t not in _STOP and len(t) >= 4) or (t.isdigit() and len(t) <= 4)}


def _word_tokens(toks):
    return {t for t in toks if not t.isdigit()}


def _resolve_unmatched(db, f, name):
    """Chất không khớp Annex và không có trong bảng của người dùng. KHÔNG mặc định coi là không giới hạn:
    1) tên gần giống mục Annex (muối / dẫn xuất / biến thể tên) -> CẦN XEM;
    2) chất tạo màu hoặc có dạng chất bảo quản/chống nắng mà không khớp -> CHƯA XÁC ĐỊNH;
    3) thuộc nhóm cần giải trình (peptide, vi sinh, nguồn gốc...) suy từ tên -> GIẢI TRÌNH;
    4) còn lại: Annex II/III không có -> SUY RA không giới hạn (đánh dấu riêng, cần người xác nhận)."""
    near = db.near_matches(name)
    if near:
        f.group, f.status = "?", "XEM"
        top = near[0]
        f.sources.append("gần giống Annex %s #%s" % (top["annex"], top["ref"]))
        f.limit_text = (top.get("max") or top["names"][0] or "")[:200].replace("\n", " ")
        f.notes.append("tên gần giống mục Annex %s #%s (%s) - có thể là muối/dẫn xuất/biến thể tên; cần xác nhận" % (
            top["annex"], top["ref"], top["names"][0][:60].replace("\n", " ")))
        return
    s = str(name)
    if _DYE_LIKE.search(s) or re.search(r"\bci\s*\d{5}\b", s, re.I):
        f.group, f.status = "?", "UNK"
        f.notes.append("giống chất tạo màu: chỉ được dùng nếu có trong Annex IV Part 1 (hoặc Annex III cho thuốc nhuộm tóc)")
        return
    if _PRESERV_UV_LIKE.search(s):
        f.group, f.status = "?", "UNK"
        f.notes.append("có dạng chất bảo quản / chống nắng nhưng không khớp Annex VI/VII - cần kiểm tra thủ công")
        return
    for label, rx in _GT_PATTERNS:
        if rx.search(s):
            f.group, f.status = "GT", "GT"
            f.sources.append("suy từ tên: nhóm GT %s" % label)
            f.limit_text = "GT %s (suy từ tên, chưa có trong bảng của bạn)" % label
            return
    f.group, f.status = "KGH", "KGHS"
    f.sources.append("không có trong Annex II/III/VI/VII")
    f.notes.append("Không thấy trong Annex II, III, IV, VI, VII và chưa có trong bảng của bạn -> theo Annex là không bị cấm/hạn chế "
                   "(suy luận). Bấm phải để xác nhận 'Không giới hạn' và lần sau app coi như đã biết.")


def _evaluate(f, name, context):
    if f.pct is None:
        f.status = "THIEU"
        return
    eff = f.pct
    conv = CONVERSIONS.get(nkey(name))
    text = (f.limit_text + " " + f.ctx).lower().replace("\n", " ")
    if conv and any(h in text for h in conv[2]):
        eff = eff * conv[1]
        f.notes.append("quy đổi theo %s: ×%.4f" % (conv[0], conv[1]))
    ratio = float(context.get("mix_ratio") or 0)
    mixing = any(k in text for k in ("sau khi trộn", "trộn với oxy", "trộn với oxi", "after mixing", "mixing under"))
    if ratio > 0 and mixing:
        eff = eff / (1.0 + ratio)
        f.notes.append("sau khi trộn tỉ lệ 1:%g -> ×%.4f" % (ratio, 1.0 / (1.0 + ratio)))
    f.effective = eff
    if not f.limits:
        f.status = "KT"
        return
    hi, lo = max(f.limits), min(f.limits)
    hi_all = max(f.limits + f.master_limits)
    if eff > hi_all * 1.0000001:
        f.status = "XEM" if (f.multi_role or f.master_only) else "VUOT"
        if mixing and ratio <= 0 and not f.master_only:
            f.status = "XEM"
            f.notes.append("ngưỡng tính SAU KHI TRỘN - hãy nhập tỉ lệ trộn để kiểm tra chính xác")
    elif eff > hi * 1.0000001:
        f.status = "XEM"
        f.notes.append("vượt ngưỡng Annex nhưng nằm trong ngưỡng ghi ở bảng của bạn - xác nhận ngữ cảnh")
    elif eff > lo * 1.0000001:
        f.status = "XEM"
    else:
        f.status = "DAT"


# ----------------------------------------------------------------------------
# Kiểm tra cả công thức
# ----------------------------------------------------------------------------
def expand_compounds(db, rows):
    """rows: [(tên, hàm lượng số|None, text)]. Trả về danh sách dòng đã cộng dồn kèm thành phần bắc cầu."""
    acc, order = {}, []

    def add(name, pct, via=""):
        k = nkey(name)
        if k not in acc:
            acc[k] = {"name": name, "pct": pct, "via": [via] if via else []}
            order.append(k)
        else:
            a = acc[k]
            if pct is not None:
                a["pct"] = (a["pct"] or 0.0) + pct
            if via:
                a["via"].append(via)
    for name, pct, _t in rows:
        comp = None
        for k in name_variants(name, split=False):
            if k in db._compound_idx:
                comp = db._compound_idx[k]
                break
        if comp is None:
            parts = re.split(r"\(\s*and\s*\)|\s+and\s+|\s*&\s*|\s*\+\s*", name_clean.clean_name(name), flags=re.I)
            if len(parts) > 1:
                comp = db._compound_sets.get(frozenset(nkey(p) for p in parts if p.strip()))
        if comp and pct is not None:
            for cname, frac in comp["components"]:
                add(cname, pct * frac, "%s (%s)" % (name, "×%g" % frac))
        else:
            add(name, pct)
    return [acc[k] for k in order]


def check_formula(db, rows, context=None):
    """rows: [(tên, hàm lượng dạng chữ hoặc số)]. Trả về list[Finding] theo thứ tự công thức (đã bắc cầu)."""
    context = context or {}
    parsed = []
    for name, pct in rows:
        v = parse_pct(pct)
        parsed.append((name, v, pct))
    merged = expand_compounds(db, parsed)
    texts = {nkey(n): t for n, _v, t in parsed}
    out = []
    for m in merged:
        f = classify(db, m["name"], m["pct"], context)
        f.pct_text = texts.get(nkey(m["name"]), "") if not m["via"] else ""
        if m["via"]:
            f.from_compound = "; ".join(m["via"])
            f.notes.append("tính bắc cầu từ hợp chất: " + f.from_compound)
        out.append(f)
    _group_rules(out)
    return out


def _group_rules(findings):
    """Quy tắc cộng nhóm: hỗn hợp MCI + MI (Annex VI mục 39) tính tổng hai chất, ngưỡng 0,0015% (3:1, chỉ rửa trôi)."""
    by = {nkey(f.name): f for f in findings}
    a, b = by.get("methylchloroisothiazolinone"), by.get("methylisothiazolinone")
    if a and b and a.pct is not None and b.pct is not None and (a.from_compound or b.from_compound):
        total = a.pct + b.pct
        note = "tổng MCI+MI = %.5g%% (ngưỡng hỗn hợp 3:1: 0,0015%%, chỉ sản phẩm rửa trôi)" % total
        for f in (a, b):
            f.notes.append(note)
            if total > 0.0015 * 1.0000001:
                f.status = "VUOT"
            elif f.status in ("KT", "XEM"):
                f.status = "DAT"


def summarize(findings):
    s = {k: 0 for k in STATUS_TEXT}
    for f in findings:
        s[f.status or "UNK"] = s.get(f.status or "UNK", 0) + 1
    return s


_DB = None


def get_db():
    global _DB
    if _DB is None:
        _DB = RegDB()
    return _DB


def reload_master():
    """Đọc lại bảng của người dùng từ bộ nhớ (sau khi nạp file mới); trả về RegDB đang dùng."""
    db = get_db()
    um = master_table.load_user_master()
    if um:
        db.set_master(um["rows"], um.get("notes", []), {"builtin": False, "source": um.get("source", ""),
                      "mtime": um.get("mtime", 0), "loaded_at": um.get("loaded_at", ""), "count": len(um["rows"])})
    else:
        db.set_master(db._builtin_master, db._builtin_notes, {"builtin": True, "count": len(db._builtin_master)})
    return db


def needs_pct(name):
    """Dùng ở Dựng BTP: chất nào cần ghi % trong phiếu (giới hạn, cấm, chưa xác định). KGH/GT thì không."""
    f = classify(get_db(), name, None, {})
    return f.group in ("GH", "CAM", "?") or f.status in ("KGHS", "XEM")


def save_user_status(db, name, status, note=""):
    os.makedirs(_USER_DIR, exist_ok=True)
    db.user[nkey(name)] = {"status": status if not note else (status + " " + note).strip(), "name": name}
    with open(os.path.join(_USER_DIR, "user_status.json"), "w", encoding="utf-8") as f:
        json.dump(db.user, f, ensure_ascii=False, indent=2)
