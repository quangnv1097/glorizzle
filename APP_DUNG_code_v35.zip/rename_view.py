# -*- coding: utf-8 -*-
"""Cửa sổ nhỏ "Đổi tên chất hàng loạt": đổi tên thành phần trong các bảng đã đọc (vd Aqua -> Aqua (Water))."""
import tkinter as tk
from tkinter import messagebox, ttk

import btp_engine as be
import dung_engine as eng
import ui_kit


class RenameDialog(tk.Toplevel):
    """get_tables(): trả về (tất cả các bảng, các bảng đang chọn). on_applied(): gọi sau khi đổi / khôi phục để vẽ lại."""

    def __init__(self, master, settings, get_tables, on_applied):
        super().__init__(master)
        self.title("Đổi tên chất hàng loạt")
        self.geometry("900x560")
        self.minsize(760, 460)
        self.settings = settings
        self.get_tables = get_tables
        self.on_applied = on_applied
        self.scope_var = tk.StringVar(value="all")
        self.auto_var = tk.BooleanVar(value=bool(settings.get("btp_rename_auto", False)))
        self.old_var = tk.StringVar()
        self.new_var = tk.StringVar()
        self.filter_var = tk.StringVar()
        self.pairs = [list(p) for p in settings.get("btp_rename_map", []) if len(p) == 2]
        self._names = []
        self._build_ui()
        self._load_names()
        self._draw_pairs()

    # ------------------------------------------------------------------ giao diện
    def _build_ui(self):
        ttk.Label(self, foreground="#555", wraplength=860, justify="left", text=(
            "Đổi tên NGUYÊN TÊN thành phần (không phân biệt hoa/thường), không đổi một phần chuỗi. Bấm đúp một chất ở danh sách bên trái "
            "để điền vào ô 'Tên hiện tại', gõ tên mới rồi bấm 'Thêm / cập nhật'. Ví dụ: Aqua  →  Aqua (Water).")
                  ).pack(fill="x", padx=12, pady=(10, 4))
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True, padx=12, pady=4)
        body.columnconfigure(0, weight=1, uniform="c")
        body.columnconfigure(1, weight=1, uniform="c")
        body.rowconfigure(0, weight=1)

        left = ttk.LabelFrame(body, text="Chất có trong các bảng đã đọc (bấm đúp để chọn)")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        fb = ttk.Frame(left)
        fb.pack(fill="x", padx=6, pady=(4, 0))
        ttk.Label(fb, text="Lọc:").pack(side="left")
        e = ttk.Entry(fb, textvariable=self.filter_var)
        e.pack(side="left", fill="x", expand=True, padx=4)
        self.filter_var.trace_add("write", lambda *a: self._draw_names())
        lh = ttk.Frame(left)
        lh.pack(fill="both", expand=True, padx=6, pady=6)
        self.names_tree = ttk.Treeview(lh, columns=("ten", "n"), show="headings", selectmode="browse")
        self.names_tree.heading("ten", text="Tên thành phần")
        self.names_tree.heading("n", text="Số bảng")
        self.names_tree.column("ten", width=260, anchor="w")
        self.names_tree.column("n", width=60, anchor="center", stretch=False)
        vs = ttk.Scrollbar(lh, orient="vertical", command=self.names_tree.yview)
        self.names_tree.configure(yscrollcommand=vs.set)
        self.names_tree.pack(side="left", fill="both", expand=True)
        vs.pack(side="right", fill="y")
        self.names_tree.bind("<Double-Button-1>", self._pick_name)

        right = ttk.LabelFrame(body, text="Danh sách đổi tên")
        right.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        form = ttk.Frame(right)
        form.pack(fill="x", padx=6, pady=(6, 2))
        form.columnconfigure(1, weight=1)
        ttk.Label(form, text="Tên hiện tại:").grid(row=0, column=0, sticky="w")
        ttk.Entry(form, textvariable=self.old_var).grid(row=0, column=1, sticky="ew", padx=4, pady=2)
        ttk.Label(form, text="Đổi thành:").grid(row=1, column=0, sticky="w")
        self.new_entry = ttk.Entry(form, textvariable=self.new_var)
        self.new_entry.grid(row=1, column=1, sticky="ew", padx=4, pady=2)
        self.new_entry.bind("<Return>", lambda e: self._add_pair())
        bf = ttk.Frame(right)
        bf.pack(fill="x", padx=6, pady=(2, 4))
        ttk.Button(bf, text="Thêm / cập nhật", command=self._add_pair).pack(side="left")
        ttk.Button(bf, text="Xóa dòng đang chọn", command=self._del_pair).pack(side="left", padx=6)
        rh = ttk.Frame(right)
        rh.pack(fill="both", expand=True, padx=6, pady=(0, 6))
        self.pairs_tree = ttk.Treeview(rh, columns=("old", "new"), show="headings", selectmode="browse")
        self.pairs_tree.heading("old", text="Tên hiện tại")
        self.pairs_tree.heading("new", text="Đổi thành")
        self.pairs_tree.column("old", width=190, anchor="w")
        self.pairs_tree.column("new", width=190, anchor="w")
        vs2 = ttk.Scrollbar(rh, orient="vertical", command=self.pairs_tree.yview)
        self.pairs_tree.configure(yscrollcommand=vs2.set)
        self.pairs_tree.pack(side="left", fill="both", expand=True)
        vs2.pack(side="right", fill="y")
        self.pairs_tree.bind("<<TreeviewSelect>>", self._load_pair)

        opt = ttk.Frame(self)
        opt.pack(fill="x", padx=12, pady=(4, 0))
        ttk.Label(opt, text="Phạm vi:").pack(side="left")
        ttk.Radiobutton(opt, text="Tất cả các bảng", value="all", variable=self.scope_var).pack(side="left", padx=6)
        ttk.Radiobutton(opt, text="Chỉ các bảng đang chọn (☑)", value="sel", variable=self.scope_var).pack(side="left")
        ttk.Checkbutton(opt, text="Tự áp dụng danh sách này cho các file nạp sau", variable=self.auto_var).pack(side="right")

        bot = ttk.Frame(self)
        bot.pack(fill="x", padx=12, pady=(8, 10))
        self.apply_btn = ui_kit.PrimaryButton(bot, text="Áp dụng đổi tên", command=self._apply, font_size=11)
        self.apply_btn.pack(side="left", ipady=2)
        ttk.Button(bot, text="Khôi phục tên gốc", command=self._restore).pack(side="left", padx=8)
        self.result = ttk.Label(bot, text="", foreground="#0B7A2B")
        self.result.pack(side="left", padx=10)
        ttk.Button(bot, text="Đóng", command=self._close).pack(side="right")

    # ------------------------------------------------------------------ dữ liệu
    def _scope_tables(self):
        all_t, sel_t = self.get_tables()
        return sel_t if self.scope_var.get() == "sel" else all_t

    def _load_names(self):
        all_t, _sel = self.get_tables()
        self._names = be.distinct_names(all_t)
        self._draw_names()

    def _draw_names(self):
        self.names_tree.delete(*self.names_tree.get_children())
        flt = self.filter_var.get().strip().casefold()
        for i, (name, n) in enumerate(self._names):
            if flt and flt not in name.casefold():
                continue
            self.names_tree.insert("", "end", iid=str(i), values=(name, n))

    def _draw_pairs(self):
        self.pairs_tree.delete(*self.pairs_tree.get_children())
        for i, (old, new) in enumerate(self.pairs):
            self.pairs_tree.insert("", "end", iid=str(i), values=(old, new))

    def _pick_name(self, _e=None):
        sel = self.names_tree.selection()
        if not sel:
            return
        name = self._names[int(sel[0])][0]
        self.old_var.set(name)
        self.new_var.set(name)                    # điền sẵn, bạn chỉ cần thêm phần đổi (vd ' (Water)')
        self.new_entry.focus_set()
        try:
            self.new_entry.icursor("end")
        except Exception:
            pass

    def _load_pair(self, _e=None):
        sel = self.pairs_tree.selection()
        if sel:
            old, new = self.pairs[int(sel[0])]
            self.old_var.set(old)
            self.new_var.set(new)

    def _add_pair(self):
        old, new = be.clean_cell(self.old_var.get()), be.clean_cell(self.new_var.get())
        if not old or not new:
            messagebox.showwarning("Thiếu thông tin", "Hãy nhập cả 'Tên hiện tại' và 'Đổi thành'.", parent=self)
            return
        key = be._rename_key(old)
        for p in self.pairs:
            if be._rename_key(p[0]) == key:
                p[0], p[1] = old, new
                break
        else:
            self.pairs.append([old, new])
        self._draw_pairs()
        self._save()
        self.old_var.set("")
        self.new_var.set("")

    def _del_pair(self):
        sel = self.pairs_tree.selection()
        if sel:
            del self.pairs[int(sel[0])]
            self._draw_pairs()
            self._save()

    def _save(self):
        self.settings["btp_rename_map"] = [list(p) for p in self.pairs]
        self.settings["btp_rename_auto"] = bool(self.auto_var.get())
        eng.save_settings(self.settings)

    # ------------------------------------------------------------------ hành động
    def _apply(self):
        if be.clean_cell(self.old_var.get()) and be.clean_cell(self.new_var.get()):
            self._add_pair()                      # dòng đang gõ dở cũng được tính
        if not self.pairs:
            messagebox.showinfo("Đổi tên", "Danh sách đổi tên đang trống.", parent=self)
            return
        n_names, n_tables = be.apply_rename_map(self._scope_tables(), self.pairs)
        self._save()
        self.result.config(text="Đã đổi %d tên ở %d bảng." % (n_names, n_tables))
        self._load_names()
        self.on_applied()

    def _restore(self):
        n = be.restore_original_names(self._scope_tables())
        self.result.config(text="Đã khôi phục tên gốc ở %d bảng." % n)
        self._load_names()
        self.on_applied()

    def _close(self):
        self._save()
        self.destroy()
