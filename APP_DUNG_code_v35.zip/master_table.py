# -*- coding: utf-8 -*-
"""
Bảng "Tổng hợp thành phần" do người dùng tự quản lý (file Excel).

  - Nạp một lần trong app; app LƯU lại (thư mục .app_dung của người dùng) và tự dùng từ các lần mở sau.
  - Khi sửa / bổ sung file Excel: nạp lại (hoặc bấm "Nạp lại" từ đường dẫn đã nhớ). File là NGUỒN CHUẨN: bản nạp mới
    thay thế hoàn toàn bản cũ; app báo thêm / bớt / đổi những dòng nào.
  - Cấu trúc file: sheet đầu tiên; cột A = tên thành phần, cột B = trạng thái (kgh, GT..., <x%, CẤM ...),
    cột C-E = ghi chú (tuỳ chọn). Dòng 1 có thể là các ghi chú chung (dài) hoặc dòng tiêu đề - app tự nhận.
"""
import json
import os
import re
import unicodedata
import warnings
from datetime import datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font

USER_DIR = os.path.join(os.path.expanduser("~"), ".app_dung")
FILE_NAME = "master_user.json"

_HEADER_WORDS = re.compile(r"(?i)^\s*(tên|ten|name|ingredient|inci|thành phần|thanh phan)\b")
_STATUS_LIKE = re.compile(r"(?i)^\s*(kgh|gt\b|cấm|cam\b|[<≤]|\d|bq|uv|sp\b|\(\d\))")


def key_of(name):
    s = unicodedata.normalize("NFKC", str(name or "")).lower()
    return " ".join(re.sub(r"[^a-z0-9]+", " ", s).split())


def _cell(v):
    return "" if v is None else str(v).strip()


def parse_xlsx(path):
    """Trả về dict: rows [{name,status,note}], notes [str], duplicates [name], no_status [name], sheet."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            ws = wb.worksheets[0]
            try:
                ws.reset_dimensions()
            except Exception:
                pass
            raw = [tuple(r) + (None,) * (6 - len(r)) for r in ws.iter_rows(values_only=True)]
            sheet = ws.title
        finally:
            wb.close()
    notes, start = [], 0
    if raw:
        a1, b1 = _cell(raw[0][0]), _cell(raw[0][1])
        if len(a1) > 50 or len(b1) > 50:                           # dòng 1 là ghi chú chung (như file của bạn)
            notes = [_cell(c) for c in raw[0] if _cell(c)]
            start = 1
        elif _HEADER_WORDS.match(a1) and not _STATUS_LIKE.match(b1):
            start = 1                                               # dòng tiêu đề
    rows, seen, dup, nostat = [], {}, [], []
    for r in raw[start:]:
        name = _cell(r[0])
        if not name:
            continue
        k = key_of(name)
        if not k:
            continue
        if k in seen:
            dup.append(name)                                        # trùng tên: giữ dòng đầu, báo để bạn dọn
            continue
        status = _cell(r[1])
        note = " ".join(x for x in (_cell(c) for c in r[2:5]) if x)
        seen[k] = len(rows)
        rows.append({"name": name, "status": status, "note": note})
        if not status:
            nostat.append(name)
    return {"rows": rows, "notes": notes, "duplicates": dup, "no_status": nostat, "sheet": sheet}


def summary(rows):
    c = {"kgh": 0, "gt": 0, "cam": 0, "gioihan": 0, "trong": 0}
    for r in rows:
        s = (r.get("status") or "").strip().lower()
        if not s:
            c["trong"] += 1
        elif s.startswith("kgh"):
            c["kgh"] += 1
        elif s.startswith(("gt", "gtrinh", "gtr")):
            c["gt"] += 1
        elif s.startswith(("cấm", "cam")):
            c["cam"] += 1
        else:
            c["gioihan"] += 1
    return c


def diff(old_rows, new_rows):
    """So sánh bản đang dùng với bản sắp nạp: thêm / bớt / đổi trạng thái."""
    old = {key_of(r["name"]): r for r in old_rows}
    new = {key_of(r["name"]): r for r in new_rows}
    added = [new[k]["name"] for k in new if k not in old]
    removed = [old[k]["name"] for k in old if k not in new]
    changed = [(new[k]["name"], old[k].get("status", ""), new[k].get("status", ""))
               for k in new if k in old and (old[k].get("status", "").strip() != new[k].get("status", "").strip())]
    return {"added": added, "removed": removed, "changed": changed}


# ----------------------------------------------------------------------------
# Lưu / nạp bản của người dùng
# ----------------------------------------------------------------------------
def user_file():
    return os.path.join(USER_DIR, FILE_NAME)


def save_user_master(parsed, source):
    os.makedirs(USER_DIR, exist_ok=True)
    try:
        mtime = os.path.getmtime(source)
    except OSError:
        mtime = 0
    data = {"source": os.path.abspath(source), "mtime": mtime, "loaded_at": datetime.now().isoformat(timespec="seconds"),
            "rows": parsed["rows"], "notes": parsed["notes"]}
    tmp = user_file() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, user_file())
    return data


def load_user_master():
    try:
        with open(user_file(), encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict) and isinstance(d.get("rows"), list) and d["rows"]:
            return d
    except Exception:
        pass
    return None


def clear_user_master():
    try:
        os.remove(user_file())
    except OSError:
        pass


def source_state(meta):
    """'ok' | 'changed' (file nguồn mới hơn bản đã nạp) | 'missing' (không còn file nguồn)."""
    src = (meta or {}).get("source", "")
    if not src or not os.path.isfile(src):
        return "missing"
    try:
        return "changed" if os.path.getmtime(src) > float(meta.get("mtime", 0)) + 1 else "ok"
    except OSError:
        return "missing"


def export_confirmed(path, user_status):
    """Xuất các chất bạn đã 'Xác nhận' trong app ra Excel cùng cấu trúc để dán vào file Tổng hợp thành phần."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Da xac nhan"
    ws.append(["Tên thành phần", "Trạng thái", "Ghi chú"])
    for _k, v in sorted(user_status.items(), key=lambda kv: str(kv[1].get("name", kv[0])).lower()):
        ws.append([v.get("name", ""), v.get("status", ""), "xác nhận trong app"])
    for c in ws[1]:
        c.font = Font(bold=True)
        c.alignment = Alignment(horizontal="center")
    ws.column_dimensions["A"].width = 48
    ws.column_dimensions["B"].width = 22
    ws.column_dimensions["C"].width = 26
    ws.freeze_panes = "A2"
    wb.save(path)
