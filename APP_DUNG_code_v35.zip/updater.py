# -*- coding: utf-8 -*-
"""Tự cập nhật mã app: kiểm tra file version.json trên mạng, tải gói mã mới (.zip), kiểm tra SHA-256, giải nén vào thư mục riêng của người dùng.
Chỉ dùng thư viện chuẩn. Bộ chạy (launcher.py) sẽ chọn thư mục mã mới nhất mỗi lần mở app.

Định dạng version.json đặt trên mạng:
  {"version": 30, "url": "https://.../APP_DUNG_code_v30.zip", "sha256": "<hex>", "notes": "Ghi chú ngắn", "min_launcher": 1}
"""
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import time
import urllib.request
import zipfile

CODE_DIR = os.path.dirname(os.path.abspath(__file__))
KEEP_VERSIONS = 2            # giữ lại bản mới nhất + 1 bản trước để quay lại khi cần


def home():
    """Thư mục dữ liệu cập nhật của người dùng (ghi đè bằng biến môi trường APP_DUNG_HOME khi thử nghiệm)."""
    env = os.environ.get("APP_DUNG_HOME")
    if env:
        return env
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
    return os.path.join(base, "APP_DUNG")


def current_version():
    from version import APP_VERSION
    return int(APP_VERSION)


def launcher_api():
    """Phiên bản bộ chạy do launcher.py báo qua biến môi trường (0 nếu chạy từ mã nguồn)."""
    try:
        return int(os.environ.get("APP_DUNG_LAUNCHER", "0"))
    except ValueError:
        return 0


def can_self_update():
    """Chỉ bật tự cập nhật khi chạy qua bộ chạy .exe (hoặc khi thử nghiệm đặt APP_DUNG_FORCE_UPDATE=1)."""
    return launcher_api() > 0 or os.environ.get("APP_DUNG_FORCE_UPDATE") == "1"


def manifest_url(settings=None):
    url = (settings or {}).get("update_url", "").strip()
    if url:
        return url
    try:
        with open(os.path.join(CODE_DIR, "update_config.json"), encoding="utf-8") as f:
            return str(json.load(f).get("manifest_url", "")).strip()
    except Exception:
        return ""


def _open(url, timeout):
    req = urllib.request.Request(url, headers={"User-Agent": "APP_DUNG-updater", "Cache-Control": "no-cache"})
    return urllib.request.urlopen(req, timeout=timeout)


def fetch_manifest(url, timeout=8):
    """Đọc version.json. Trả về dict đã kiểm tra; ném lỗi nếu không đọc được / sai định dạng."""
    sep = "&" if "?" in url else "?"
    with _open(url + sep + "t=%d" % int(time.time()), timeout) as r:
        data = json.loads(r.read().decode("utf-8-sig"))
    for k in ("version", "url", "sha256"):
        if not data.get(k):
            raise ValueError("version.json thiếu mục '%s'" % k)
    data["version"] = int(data["version"])
    data["min_launcher"] = int(data.get("min_launcher", 1))
    data["notes"] = str(data.get("notes", ""))
    return data


def check(settings=None, timeout=8):
    """Trả về (manifest hoặc None nếu đã mới nhất, thông báo)."""
    url = manifest_url(settings)
    if not url:
        raise ValueError("Chưa cấu hình địa chỉ cập nhật (update_config.json hoặc settings 'update_url').")
    m = fetch_manifest(url, timeout)
    cur = current_version()
    if m["version"] <= cur:
        return None, "Đang dùng bản mới nhất (v%d)." % cur
    if m["min_launcher"] > launcher_api() and launcher_api() > 0:
        raise ValueError("Bản v%d cần bộ chạy .exe mới hơn - hãy nhận lại file APP_DUNG.exe." % m["version"])
    return m, "Có phiên bản mới v%d (đang dùng v%d)." % (m["version"], cur)


def _safe_members(zf):
    for info in zf.infolist():
        name = info.filename.replace("\\", "/")
        if name.startswith("/") or re.match(r"^[A-Za-z]:", name) or ".." in name.split("/"):
            raise ValueError("Gói cập nhật chứa đường dẫn không an toàn: %s" % info.filename)
    return zf.namelist()


def install(manifest, progress=None, timeout=30):
    """Tải + kiểm tra + giải nén bản mới. Trả về thư mục mã mới. progress(đã_tải, tổng) tuỳ chọn."""
    ver = int(manifest["version"])
    root = home()
    code_root = os.path.join(root, "code")
    os.makedirs(code_root, exist_ok=True)
    fd, tmp_zip = tempfile.mkstemp(suffix=".zip", dir=root)
    os.close(fd)
    stage = os.path.join(code_root, "_tmp_v%d" % ver)
    try:
        h = hashlib.sha256()
        with _open(manifest["url"], timeout) as r, open(tmp_zip, "wb") as out:
            total = int(r.headers.get("Content-Length") or 0)
            done = 0
            while True:
                chunk = r.read(65536)
                if not chunk:
                    break
                out.write(chunk)
                h.update(chunk)
                done += len(chunk)
                if progress:
                    progress(done, total)
        if h.hexdigest().lower() != str(manifest["sha256"]).strip().lower():
            raise ValueError("Gói tải về không khớp mã SHA-256 (tải lỗi hoặc bị thay đổi) - không cài.")
        shutil.rmtree(stage, ignore_errors=True)
        with zipfile.ZipFile(tmp_zip) as zf:
            names = _safe_members(zf)
            if "app_dung.py" not in names or "version.py" not in names:
                raise ValueError("Gói cập nhật không đúng cấu trúc (thiếu app_dung.py / version.py).")
            zf.extractall(stage)
        with open(os.path.join(stage, "version.py"), encoding="utf-8") as f:
            m = re.search(r"APP_VERSION\s*=\s*(\d+)", f.read())
        if not m or int(m.group(1)) != ver:
            raise ValueError("Số phiên bản trong gói không khớp version.json.")
        final = os.path.join(code_root, "v%d" % ver)
        shutil.rmtree(final, ignore_errors=True)
        os.replace(stage, final)
        _write_json_atomic(os.path.join(root, "current.json"), {"version": ver, "dir": "v%d" % ver})
        _clear_bad(root, ver)
        _prune(code_root, ver)
        return final
    finally:
        shutil.rmtree(stage, ignore_errors=True)
        try:
            os.remove(tmp_zip)
        except OSError:
            pass


def _write_json_atomic(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f)
    os.replace(tmp, path)


def _clear_bad(root, ver):
    p = os.path.join(root, "bad.json")
    try:
        with open(p, encoding="utf-8") as f:
            bad = [v for v in json.load(f) if int(v) != ver]
        _write_json_atomic(p, bad)
    except Exception:
        pass


def _prune(code_root, newest):
    dirs = []
    for d in os.listdir(code_root):
        m = re.fullmatch(r"v(\d+)", d)
        if m:
            dirs.append((int(m.group(1)), d))
    dirs.sort(reverse=True)
    for _v, d in dirs[KEEP_VERSIONS:]:
        shutil.rmtree(os.path.join(code_root, d), ignore_errors=True)


def restart_app():
    """Mở lại app (bộ chạy sẽ chọn mã mới nhất). Gọi xong thì thoát tiến trình hiện tại."""
    import subprocess
    if getattr(sys, "frozen", False):
        subprocess.Popen([sys.executable])
    else:
        subprocess.Popen([sys.executable, os.path.join(CODE_DIR, "app_dung.py")])
