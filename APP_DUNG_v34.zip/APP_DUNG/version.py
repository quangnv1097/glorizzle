# -*- coding: utf-8 -*-
"""Số phiên bản của MÃ app (tăng mỗi lần phát hành bản cập nhật). Bộ chạy .exe đọc file này bằng regex nên giữ đúng dạng 'APP_VERSION = <số>'."""
APP_VERSION = 34
# Bộ chạy .exe tối thiểu cần có để chạy mã này (tăng khi mã dùng thư viện mới mà bộ chạy cũ chưa đóng gói sẵn)
MIN_LAUNCHER = 2
