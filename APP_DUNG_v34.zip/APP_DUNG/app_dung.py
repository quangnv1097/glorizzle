#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
APP DỰNG – màn hình chính.

  DỮ LIỆU ĐẦU VÀO   Tạo file BTP từ dữ liệu khách hàng (Excel/CSV/Word/PDF) - đã gồm kiểm tra ngưỡng  |  Nạp file BTP có sẵn
  QUY TRÌNH         1. Dựng BTP -> 2. Check Có / Không -> 3. Thay đổi các Info
  CÔNG CỤ KHÁC      Gom dữ liệu mẫu (xuất bảng Tên SP | Công dụng | Thành phần)

Chạy:  pip install openpyxl pdfplumber   rồi   python app_dung.py
"""
import os
import threading
import tkinter as tk
from tkinter import filedialog, messagebox

import dung_engine as eng
import master_table
import reg_engine
import ui_kit
import updater
from version import APP_VERSION
from btp_view import BtpWindow
from check_view import CheckWindow
from dung_view import DungWindow
from gom_view import GomWindow
from info_view import InfoWindow
from note_view import NoteWindow
import note_engine

FONT = "Segoe UI"
P = {
    "bg": "#F2F4F8",            # nền cửa sổ
    "card": "#FFFFFF",          # nền thẻ
    "border": "#D8DEE9",        # viền thẻ
    "header": "#1F3A5F",        # thanh tiêu đề (xanh navy)
    "header_sub": "#B8C7DD",
    "primary": "#2F6DB5",       # màu nhấn chính
    "primary_active": "#265A96",
    "hover": "#EAF2FB",         # nền thẻ khi rê chuột
    "text": "#1C2733",
    "muted": "#667085",
    "ok": "#2E8B67",
    "off": "#A7AFBC",
    "tool": "#6B7686",
}


def _style_button(btn, primary):
    """Nút phẳng có hiệu ứng rê chuột."""
    if primary:
        base, hover, fg = P["primary"], P["primary_active"], "#FFFFFF"
        btn.config(bg=base, fg=fg, activebackground=hover, activeforeground=fg,
                   highlightbackground=base)
    else:
        base, hover, fg = P["card"], P["hover"], P["primary"]
        btn.config(bg=base, fg=fg, activebackground=hover, activeforeground=fg,
                   highlightbackground=P["primary"])
    btn.config(relief="flat", bd=0, highlightthickness=1, cursor="hand2", font=(FONT, 10, "bold"),
               padx=12, pady=9)
    btn.bind("<Enter>", lambda e: btn.config(bg=hover) if str(btn["state"]) == "normal" else None)
    btn.bind("<Leave>", lambda e: btn.config(bg=base))


class ActionCard(tk.Frame):
    """Thẻ bấm được: huy hiệu số + tiêu đề + mô tả ngắn + dấu ›. Đổi màu khi rê chuột."""

    def __init__(self, master, badge, title, desc, command, badge_color=None):
        super().__init__(master, bg=P["card"], highlightthickness=1, highlightbackground=P["border"],
                         cursor="hand2")
        self.command = command
        self.badge = tk.Canvas(self, width=40, height=40, bg=P["card"], highlightthickness=0)
        self.badge.create_oval(3, 3, 37, 37, fill=badge_color or P["primary"], outline="")
        self.badge.create_text(20, 20, text=badge, fill="#FFFFFF", font=(FONT, 13, "bold"))
        self.title = tk.Label(self, text=title, font=(FONT, 12, "bold"), fg=P["text"], bg=P["card"], anchor="w")
        self.desc = tk.Label(self, text=desc, font=(FONT, 9), fg=P["muted"], bg=P["card"],
                             anchor="nw", justify="left", wraplength=340)
        self.chev = tk.Label(self, text="\u203A", font=(FONT, 22), fg=P["muted"], bg=P["card"])
        self.badge.grid(row=0, column=0, rowspan=2, padx=(14, 12), pady=10)
        self.title.grid(row=0, column=1, sticky="sw", pady=(10, 0))
        self.desc.grid(row=1, column=1, sticky="nw", pady=(1, 10))
        self.chev.grid(row=0, column=2, rowspan=2, padx=(8, 16))
        self.columnconfigure(1, weight=1)
        self._parts = [self, self.badge, self.title, self.desc, self.chev]
        for w in self._parts:
            w.bind("<Enter>", self._enter)
            w.bind("<Leave>", self._leave)
            w.bind("<Button-1>", self._click)
        self.bind("<Configure>", self._on_configure)

    def _paint(self, hover):
        color = P["hover"] if hover else P["card"]
        for w in self._parts:
            w.config(bg=color)
        self.config(highlightbackground=P["primary"] if hover else P["border"])
        self.chev.config(fg=P["primary"] if hover else P["muted"])

    def _enter(self, _e=None):
        self._paint(True)

    def _leave(self, _e=None):
        x, y = self.winfo_pointerxy()
        left, top = self.winfo_rootx(), self.winfo_rooty()
        if not (left <= x < left + self.winfo_width() and top <= y < top + self.winfo_height()):
            self._paint(False)

    def _click(self, _e=None):
        self.command()

    def _on_configure(self, e):
        self.desc.config(wraplength=max(200, e.width - 130))


class Launcher(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("APP DỰNG")
        self.configure(bg=P["bg"])
        self.minsize(520, 600)

        self.settings = eng.load_settings()
        self.btp_path = ""
        self.btp_sheets = []
        self.dung_win = None
        self.check_win = None
        self.gom_win = None
        self.info_win = None
        self.btp_win = None
        self.note_win = None

        self._update_info = None            # manifest của bản mới (nếu có)
        self._update_q = []                 # kết quả từ luồng nền: (loại, dữ liệu)
        self._build_header()
        # chân trang đặt TRƯỚC thân để luôn còn chỗ khi cửa sổ thấp
        tk.Label(self, text="Nạp hoặc tạo file BTP trước, sau đó chạy lần lượt các bước 1 \u2192 3.",
                 font=(FONT, 9), fg=P["muted"], bg=P["bg"]).pack(side="bottom", pady=(0, 10))
        self.scroll = ui_kit.ScrollFrame(self, bg=P["bg"])
        self.scroll.pack(fill="both", expand=True, padx=(24, 10), pady=(12, 6))
        body = self.scroll.inner

        self._section(body, "DỮ LIỆU ĐẦU VÀO", first=True)
        self._build_input_card(body)
        self._build_master_card(body)
        self._build_note_card(body)

        self._section(body, "QUY TRÌNH DỰNG HỒ SƠ")
        ActionCard(body, "1", "Dựng BTP",
                   "Tạo hàng loạt file Form dựng mẫu: mỗi sheet, gộp một file hoặc gộp theo nhóm.",
                   self.open_dung).pack(fill="x", pady=(0, 8))
        ActionCard(body, "2", "Check Có / Không",
                   "Rà và chỉnh dạng sản phẩm, công dụng, dạng trình bày của nhiều file.",
                   self.open_check).pack(fill="x", pady=(0, 8))
        ActionCard(body, "3", "Thay đổi các Info",
                   "Cập nhật hàng loạt thông tin công ty, nhà sản xuất, đơn vị đóng gói.",
                   self.open_info).pack(fill="x")

        self._section(body, "CÔNG CỤ KHÁC")
        ActionCard(body, "+", "Gom dữ liệu mẫu",
                   "Gom tên sản phẩm, công dụng, thành phần từ các file đã dựng thành một bảng Excel.",
                   self.open_gom, badge_color=P["tool"]).pack(fill="x")

        self._place_window(560, 780)
        self._refresh_master_status()
        if updater.can_self_update() and self.settings.get("auto_update_check", True):
            self.after(1500, lambda: self._check_update(silent=True))

    # ------------------------------------------------------------ dựng giao diện
    def _build_header(self):
        bar = tk.Frame(self, bg=P["header"])
        bar.pack(fill="x")
        tk.Label(bar, text="APP DỰNG", font=(FONT, 22, "bold"), fg="#FFFFFF", bg=P["header"],
                 anchor="w").pack(fill="x", padx=26, pady=(18, 0))
        sub = tk.Frame(bar, bg=P["header"])
        sub.pack(fill="x", padx=26, pady=(0, 18))
        tk.Label(sub, text="Dựng hồ sơ công bố mỹ phẩm từ file BTP", font=(FONT, 10), fg=P["header_sub"],
                 bg=P["header"], anchor="w").pack(side="left")
        self.upd_btn = tk.Label(sub, text="v%d  ·  Kiểm tra cập nhật" % APP_VERSION, font=(FONT, 9, "underline"),
                                fg=P["header_sub"], bg=P["header"], cursor="hand2")
        self.upd_btn.pack(side="right")
        self.upd_btn.bind("<Button-1>", lambda _e: self._check_update(silent=False))
        # thanh báo có bản mới (ẩn cho tới khi phát hiện)
        self.upd_bar = tk.Frame(self, bg="#FFF4D6", highlightthickness=1, highlightbackground="#E8C766")
        self.upd_text = tk.Label(self.upd_bar, text="", bg="#FFF4D6", fg="#6B4E00", font=(FONT, 9), anchor="w",
                                 justify="left", wraplength=380)
        self.upd_text.pack(side="left", fill="x", expand=True, padx=(14, 6), pady=6)
        self.upd_go = tk.Button(self.upd_bar, text="Cập nhật ngay", command=self._do_update)
        _style_button(self.upd_go, primary=True)
        self.upd_go.config(padx=10, pady=4)
        self.upd_go.pack(side="right", padx=(6, 12), pady=6)

    def _section(self, parent, text, first=False):
        tk.Label(parent, text=text, font=(FONT, 9, "bold"), fg=P["muted"], bg=P["bg"], anchor="w").pack(
            fill="x", pady=(0 if first else 14, 6))

    def _build_input_card(self, parent):
        card = tk.Frame(parent, bg=P["card"], highlightthickness=1, highlightbackground=P["border"])
        card.pack(fill="x")
        top = tk.Frame(card, bg=P["card"])
        top.pack(fill="x", padx=16, pady=(12, 0))
        self.dot = tk.Canvas(top, width=14, height=14, bg=P["card"], highlightthickness=0)
        self.dot_id = self.dot.create_oval(2, 2, 12, 12, fill=P["off"], outline="")
        self.dot.pack(side="left", padx=(0, 8))
        self.btp_title = tk.Label(top, text="Chưa nạp file BTP", font=(FONT, 11, "bold"), fg=P["text"],
                                  bg=P["card"], anchor="w")
        self.btp_title.pack(side="left", fill="x", expand=True)
        self.info = tk.Label(card, text="Tạo từ Excel / CSV / Word / PDF của khách hàng, hoặc nạp file BTP có sẵn.",
                             font=(FONT, 9), fg=P["muted"], bg=P["card"], anchor="w", justify="left",
                             wraplength=440)
        self.info.pack(fill="x", padx=38, pady=(2, 10))
        card.bind("<Configure>", lambda e: self.info.config(wraplength=max(200, e.width - 76)))

        btns = tk.Frame(card, bg=P["card"])
        btns.pack(fill="x", padx=16, pady=(0, 14))
        btns.columnconfigure(0, weight=1, uniform="b")
        btns.columnconfigure(1, weight=1, uniform="b")
        self.make_btn = tk.Button(btns, text="Tạo BTP từ file khách hàng", command=self.open_btp_maker)
        self.load_btn = tk.Button(btns, text="Nạp file BTP có sẵn", command=self.load_btp)
        _style_button(self.make_btn, primary=True)
        _style_button(self.load_btn, primary=False)
        self.make_btn.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self.load_btn.grid(row=0, column=1, sticky="ew", padx=(6, 0))

    def _build_master_card(self, parent):
        """Thẻ 'Bảng tổng hợp thành phần': nạp một lần, app nhớ; sửa file rồi nạp lại để cập nhật."""
        card = tk.Frame(parent, bg=P["card"], highlightthickness=1, highlightbackground=P["border"])
        card.pack(fill="x", pady=(8, 0))
        top = tk.Frame(card, bg=P["card"])
        top.pack(fill="x", padx=16, pady=(10, 0))
        self.mdot = tk.Canvas(top, width=14, height=14, bg=P["card"], highlightthickness=0)
        self.mdot_id = self.mdot.create_oval(2, 2, 12, 12, fill=P["off"], outline="")
        self.mdot.pack(side="left", padx=(0, 8))
        self.master_title = tk.Label(top, text="Bảng tổng hợp thành phần", font=(FONT, 11, "bold"), fg=P["text"],
                                     bg=P["card"], anchor="w")
        self.master_title.pack(side="left", fill="x", expand=True)
        self.master_info = tk.Label(card, text="", font=(FONT, 9), fg=P["muted"], bg=P["card"], anchor="w",
                                    justify="left", wraplength=440)
        self.master_info.pack(fill="x", padx=38, pady=(2, 8))
        card.bind("<Configure>", lambda e: self.master_info.config(wraplength=max(200, e.width - 76)))
        btns = tk.Frame(card, bg=P["card"])
        btns.pack(fill="x", padx=16, pady=(0, 12))
        for c in range(3):
            btns.columnconfigure(c, weight=1, uniform="m")
        self.master_load_btn = tk.Button(btns, text="Nạp / cập nhật file…", command=self.load_master)
        self.master_reload_btn = tk.Button(btns, text="Nạp lại", command=self.reload_master)
        self.master_export_btn = tk.Button(btns, text="Xuất chất đã xác nhận…", command=self.export_confirmed)
        for b in (self.master_load_btn, self.master_reload_btn, self.master_export_btn):
            _style_button(b, primary=False)
            b.config(font=(FONT, 9, "bold"), pady=6, padx=6)
        self.master_load_btn.grid(row=0, column=0, sticky="ew", padx=(0, 4))
        self.master_reload_btn.grid(row=0, column=1, sticky="ew", padx=4)
        self.master_export_btn.grid(row=0, column=2, sticky="ew", padx=(4, 0))

    def _build_note_card(self, parent):
        """Thẻ 'Bảng Ghi chú': ghi chú theo tên thành phần, tự điền vào cột E của BTP và cột D sheet 4 khi dựng."""
        card = tk.Frame(parent, bg=P["card"], highlightthickness=1, highlightbackground=P["border"])
        card.pack(fill="x", pady=(8, 0))
        top = tk.Frame(card, bg=P["card"])
        top.pack(fill="x", padx=16, pady=(10, 0))
        self.ndot = tk.Canvas(top, width=14, height=14, bg=P["card"], highlightthickness=0)
        self.ndot.create_oval(2, 2, 12, 12, fill=P["ok"], outline="")
        self.ndot.pack(side="left", padx=(0, 8))
        self.note_title = tk.Label(top, text="Bảng Ghi chú thành phần", font=(FONT, 11, "bold"), fg=P["text"],
                                   bg=P["card"], anchor="w")
        self.note_title.pack(side="left", fill="x", expand=True)
        self.note_info = tk.Label(card, text="", font=(FONT, 9), fg=P["muted"], bg=P["card"], anchor="w",
                                  justify="left", wraplength=440)
        self.note_info.pack(fill="x", padx=38, pady=(2, 8))
        card.bind("<Configure>", lambda e: self.note_info.config(wraplength=max(200, e.width - 76)))
        btns = tk.Frame(card, bg=P["card"])
        btns.pack(fill="x", padx=16, pady=(0, 12))
        btns.columnconfigure(0, weight=1)
        self.note_btn = tk.Button(btns, text="Bảng Ghi chú", command=self.open_notes)
        _style_button(self.note_btn, primary=False)
        self.note_btn.config(font=(FONT, 9, "bold"), pady=6, padx=6)
        self.note_btn.grid(row=0, column=0, sticky="ew")
        self._refresh_note_status()

    def _refresh_note_status(self, n=None):
        if n is None:
            n = len(note_engine.get_index())
        self.note_info.config(text="%d thành phần có ghi chú. Tự điền vào cột E khi tạo BTP và vào cột D (từ dòng 5) sheet 4 khi Dựng. "
                                   "Bấm để xem, sửa, bổ sung." % n)

    def open_notes(self):
        if self.note_win is not None and self.note_win.winfo_exists():
            self.note_win.lift()
            self.note_win.focus_force()
            return
        self.note_win = NoteWindow(self, self.settings, on_change=self._refresh_note_status)

    def _refresh_master_status(self):
        meta = reg_engine.get_db().master_meta
        n = meta.get("count", 0)
        if meta.get("builtin"):
            self.mdot.itemconfig(self.mdot_id, fill=P["primary"])
            self.master_title.config(text="Bảng tổng hợp thành phần: bản tích hợp sẵn")
            self.master_info.config(fg=P["muted"], text="%d thành phần. Nạp file Excel \"Tổng hợp thành phần\" của bạn để thay thế - "
                                                         "app sẽ nhớ cho các lần mở sau." % n)
            self.master_reload_btn.config(state="disabled")
            return
        src = meta.get("source", "")
        state = master_table.source_state(meta)
        when = meta.get("loaded_at", "").replace("T", " ")[:16]
        self.master_title.config(text="Bảng tổng hợp thành phần: %s" % (os.path.basename(src) or "file của bạn"))
        text = "%d thành phần - nạp lúc %s." % (n, when or "?")
        color = P["muted"]
        if state == "changed":
            text += " File nguồn đã được sửa sau lần nạp - bấm 'Nạp lại' để cập nhật."
            color = "#B45F06"
            self.mdot.itemconfig(self.mdot_id, fill="#E8A33D")
        elif state == "missing":
            text += " Không còn thấy file nguồn tại đường dẫn cũ (app vẫn dùng bản đã nhớ); bấm 'Nạp / cập nhật file…' để chọn lại."
            self.mdot.itemconfig(self.mdot_id, fill=P["ok"])
        else:
            self.mdot.itemconfig(self.mdot_id, fill=P["ok"])
        self.master_info.config(text=text, fg=color)
        self.master_reload_btn.config(state="normal" if state != "missing" else "disabled")

    def load_master(self, path=None):
        p = path or filedialog.askopenfilename(
            parent=self, title="Chọn file Tổng hợp thành phần",
            initialdir=self.settings.get("master_dir") or None,
            filetypes=[("Excel", "*.xlsx *.xlsm"), ("Tất cả", "*.*")])
        if not p:
            return False
        return self._apply_master(p, ask=True)

    def reload_master(self):
        meta = reg_engine.get_db().master_meta
        src = meta.get("source", "")
        if meta.get("builtin") or not src or not os.path.isfile(src):
            return self.load_master()
        return self._apply_master(src, ask=False)

    def _apply_master(self, path, ask):
        self.config(cursor="watch")
        self.update_idletasks()
        try:
            parsed = master_table.parse_xlsx(path)
        except Exception as ex:
            self.config(cursor="")
            messagebox.showerror("Không đọc được file", "%s\n\n(Nếu file đang mở trong Excel, hãy lưu rồi thử lại.)" % ex, parent=self)
            return False
        self.config(cursor="")
        rows = parsed["rows"]
        if not rows:
            messagebox.showerror("File không hợp lệ", "Không đọc được dòng nào. Cột A là tên thành phần, cột B là trạng thái "
                                 "(kgh, GT..., <x%, CẤM...), sheet đầu tiên.", parent=self)
            return False
        db = reg_engine.get_db()
        d = master_table.diff(db.master_rows, rows)
        s = master_table.summary(rows)
        lines = ["Đọc được %d thành phần (không giới hạn %d, giới hạn %d, giải trình %d, cấm %d)." % (
            len(rows), s["kgh"], s["gioihan"], s["gt"], s["cam"])]
        lines.append("So với bảng đang dùng: thêm %d, bỏ %d, đổi trạng thái %d." % (len(d["added"]), len(d["removed"]), len(d["changed"])))
        if d["added"]:
            lines.append("  Thêm (vài dòng đầu): " + "; ".join(x[:28] for x in d["added"][:5]))
        if d["changed"]:
            lines.append("  Đổi: " + "; ".join("%s (%s → %s)" % (n[:22], (a or "-")[:10], (b or "-")[:10]) for n, a, b in d["changed"][:4]))
        if d["removed"]:
            lines.append("  Bỏ (vài dòng đầu): " + "; ".join(x[:28] for x in d["removed"][:5]))
        warn = []
        if parsed["duplicates"]:
            warn.append("%d tên trùng (giữ dòng đầu): %s" % (len(parsed["duplicates"]), "; ".join(x[:24] for x in parsed["duplicates"][:3])))
        if parsed["no_status"]:
            warn.append("%d dòng chưa có trạng thái ở cột B: %s" % (len(parsed["no_status"]), "; ".join(x[:24] for x in parsed["no_status"][:3])))
        if warn:
            lines.append("")
            lines += ["Lưu ý: " + w for w in warn]
        msg = "\n".join(lines)
        if ask:
            if not messagebox.askyesno("Nạp bảng tổng hợp thành phần", msg + "\n\nNạp bảng này thay cho bảng đang dùng?", parent=self):
                return False
        master_table.save_user_master(parsed, path)
        reg_engine.reload_master()
        self.settings["master_dir"] = os.path.dirname(os.path.abspath(path))
        eng.save_settings(self.settings)
        self._refresh_master_status()
        self._refresh_open_windows()
        if not ask:
            messagebox.showinfo("Đã nạp lại", msg, parent=self)
        return True

    def _refresh_open_windows(self):
        """Các cửa sổ đang mở tính lại ngưỡng theo bảng vừa nạp."""
        try:
            if self.btp_win is not None and self.btp_win.winfo_exists():
                self.btp_win.panel.apply_context()
            if self.dung_win is not None and self.dung_win.winfo_exists():
                self.dung_win.set_sheets(self.dung_win.btp_path, self.dung_win._all_sheets)
        except Exception:
            pass

    def export_confirmed(self):
        user = reg_engine.get_db().user
        if not user:
            messagebox.showinfo("Chất đã xác nhận", "Chưa có chất nào bạn xác nhận trong app (bấm phải vào chất 'chưa xác định' "
                                "hoặc 'suy ra KGH' ở bảng kiểm tra ngưỡng).", parent=self)
            return
        out = filedialog.asksaveasfilename(parent=self, title="Lưu danh sách chất đã xác nhận", defaultextension=".xlsx",
                                           initialfile="chat_da_xac_nhan.xlsx", filetypes=[("Excel", "*.xlsx")])
        if not out:
            return
        try:
            master_table.export_confirmed(out, user)
        except PermissionError:
            messagebox.showerror("Không ghi được", "Không ghi được file (đang mở trong Excel?).", parent=self)
            return
        messagebox.showinfo("Đã xuất", "Đã xuất %d chất. Hãy dán vào file Tổng hợp thành phần của bạn rồi nạp lại vào app." % len(user),
                            parent=self)

    def _place_window(self, w, h):
        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        h = min(h, sh - 80)
        x, y = max(0, (sw - w) // 2), max(0, (sh - h) // 3)
        self.geometry("%dx%d+%d+%d" % (w, h, x, y))

    def _set_btp_status(self, path=None, n_products=0, n_sheets=0):
        if path:
            self.dot.itemconfig(self.dot_id, fill=P["ok"])
            self.btp_title.config(text=os.path.basename(path))
            self.info.config(text="%d sheet sản phẩm trong %d sheet. Sẵn sàng để dựng." % (n_products, n_sheets))
        else:
            self.dot.itemconfig(self.dot_id, fill=P["off"])
            self.btp_title.config(text="Chưa nạp file BTP")
            self.info.config(text="Tạo từ Excel / CSV / Word / PDF của khách hàng, hoặc nạp file BTP có sẵn.")

    # ------------------------------------------------------------ nạp BTP
    def load_btp(self, path=None):
        p = path or filedialog.askopenfilename(
            parent=self, title="Chọn file BTP",
            initialdir=self.settings.get("btp_dir") or None,
            filetypes=[("Excel", "*.xlsx *.xlsm *.xls"), ("Tất cả", "*.*")])
        if not p:
            return False
        self.config(cursor="watch")
        self.update_idletasks()
        try:
            sheets = eng.read_btp(p)
        except Exception as ex:
            self.config(cursor="")
            messagebox.showerror("Không đọc được file BTP", str(ex), parent=self)
            return False
        self.config(cursor="")
        self.btp_path, self.btp_sheets = p, sheets
        self.settings["btp_dir"] = os.path.dirname(p)
        eng.save_settings(self.settings)
        self._set_btp_status(p, len(eng.product_sheets(sheets)), len(sheets))
        if self.dung_win is not None and self.dung_win.winfo_exists():
            self.dung_win.set_sheets(p, sheets)
        return True

    # ------------------------------------------------------------ cập nhật phiên bản
    def _check_update(self, silent):
        """Kiểm tra bản mới ở luồng nền. silent=True: chỉ báo khi CÓ bản mới (tự kiểm tra lúc mở app)."""
        if not updater.can_self_update():
            if not silent:
                messagebox.showinfo("Cập nhật", "Đang chạy từ mã nguồn nên không tự cập nhật.\n"
                                    "Chức năng này dùng khi mở app bằng file APP_DUNG.exe.", parent=self)
            return
        if not updater.manifest_url(self.settings):
            if not silent:
                messagebox.showinfo("Cập nhật", "Chưa cấu hình địa chỉ cập nhật.", parent=self)
            return
        if not silent:
            self.upd_btn.config(text="Đang kiểm tra…")

        def work():
            try:
                self._update_q.append(("check", (silent,) + updater.check(self.settings)))
            except Exception as ex:
                self._update_q.append(("check_err", (silent, str(ex))))
        threading.Thread(target=work, daemon=True).start()
        self.after(300, self._poll_update)

    def _poll_update(self):
        if not self._update_q:
            self.after(300, self._poll_update)
            return
        kind, data = self._update_q.pop(0)
        while kind == "progress" and self._update_q and self._update_q[0][0] == "progress":
            kind, data = self._update_q.pop(0)            # chỉ lấy mốc tải mới nhất
        self.upd_btn.config(text="v%d  ·  Kiểm tra cập nhật" % APP_VERSION)
        if kind == "check":
            silent, manifest, msg = data
            if manifest:
                self._update_info = manifest
                notes = ("\n" + manifest["notes"]) if manifest.get("notes") else ""
                self.upd_text.config(text="Có phiên bản mới v%d.%s" % (manifest["version"], notes))
                self.upd_bar.pack(fill="x", after=self.winfo_children()[0])
            elif not silent:
                messagebox.showinfo("Cập nhật", msg, parent=self)
        elif kind == "check_err":
            silent, msg = data
            if not silent:
                messagebox.showwarning("Cập nhật", "Không kiểm tra được bản mới:\n%s" % msg, parent=self)
        elif kind == "progress":
            done, total = data
            self.upd_text.config(text="Đang tải bản mới… %s" % (
                "%d%%" % (100 * done // total) if total else "%d KB" % (done // 1024)))
            self.after(200, self._poll_update)
        elif kind == "installed":
            messagebox.showinfo("Cập nhật", "Đã cập nhật lên v%d. App sẽ tự mở lại." % data, parent=self)
            updater.restart_app()
            self.destroy()
        elif kind == "install_err":
            self.upd_go.config(state="normal")
            self.upd_text.config(text="Cập nhật lỗi, bản hiện tại vẫn dùng bình thường.")
            messagebox.showerror("Cập nhật", "Không cập nhật được:\n%s" % data, parent=self)

    def _do_update(self):
        m = self._update_info
        if not m:
            return
        if any(w is not None and w.winfo_exists() for w in
               (self.dung_win, self.check_win, self.gom_win, self.info_win, self.btp_win)) and not messagebox.askyesno(
                "Cập nhật", "Các cửa sổ đang mở sẽ đóng khi app khởi động lại.\nTiếp tục cập nhật?", parent=self):
            return
        self.upd_go.config(state="disabled")

        def work():
            try:
                updater.install(m, progress=lambda d, t: self._update_q.append(("progress", (d, t))))
                self._update_q.append(("installed", m["version"]))
            except Exception as ex:
                self._update_q.append(("install_err", str(ex)))
        threading.Thread(target=work, daemon=True).start()
        self.after(300, self._poll_update)

    # ------------------------------------------------------------ các nút
    def open_dung(self):
        if not self.btp_sheets:
            if not messagebox.askyesno("Dựng BTP", "Chưa có file BTP. Nạp file BTP ngay bây giờ?", parent=self):
                return
            if not self.load_btp():
                return
        if self.dung_win is not None and self.dung_win.winfo_exists():
            self.dung_win.lift()
            self.dung_win.focus_force()
            return
        self.dung_win = DungWindow(self, self.btp_path, self.btp_sheets, self.settings,
                                   on_open_check=self.open_check, on_open_info=self.open_info)

    def open_check(self, paths=None):
        if self.check_win is not None and self.check_win.winfo_exists():
            self.check_win.lift()
            self.check_win.focus_force()
            if paths:
                self.check_win.add_paths(paths)
            return
        self.check_win = CheckWindow(self, paths=paths)

    def open_gom(self):
        if self.gom_win is not None and self.gom_win.winfo_exists():
            self.gom_win.lift()
            self.gom_win.focus_force()
            return
        self.gom_win = GomWindow(self, self.settings, self.settings.get("out_dir", ""))

    def open_btp_maker(self):
        if self.btp_win is not None and self.btp_win.winfo_exists():
            self.btp_win.lift()
            self.btp_win.focus_force()
            return
        self.btp_win = BtpWindow(self, self.settings, on_use_btp=self.load_btp)

    def open_info(self, paths=None):
        if self.info_win is not None and self.info_win.winfo_exists():
            self.info_win.lift()
            self.info_win.focus_force()
            if paths:
                self.info_win.add_paths(paths)
            return
        self.info_win = InfoWindow(self, self.settings, paths=paths)


if __name__ == "__main__":
    Launcher().mainloop()
