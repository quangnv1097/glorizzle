# -*- coding: utf-8 -*-
"""Cửa sổ "Tạo file BTP": đọc Excel/CSV, Word, PDF của khách hàng và xuất file BTP."""
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from datetime import date
from tkinter import filedialog, messagebox, simpledialog, ttk

import btp_engine as be
import dung_engine as eng
import reg_view
import rename_view
import ui_kit
from ui_kit import ScrollFrame

CHK, UNCHK = "☑", "☐"
FILE_TYPES = [("Dữ liệu khách hàng", "*.xlsx *.xlsm *.xls *.csv *.docx *.pdf"),
              ("Excel / CSV", "*.xlsx *.xlsm *.xls *.csv"), ("Word", "*.docx"), ("PDF", "*.pdf"),
              ("Tất cả", "*.*")]


class BtpWindow(tk.Toplevel):
    def __init__(self, master, settings, on_use_btp=None):
        super().__init__(master)
        self.title("Tạo file BTP")
        self.geometry("1180x820")
        self.minsize(900, 520)
        self.settings = settings
        self.on_use_btp = on_use_btp
        self.tables = []                 # list[be.Table]
        self.fails = []                  # file không đọc được: dict(path, reason, preview)
        self.source_paths = []           # mọi file đã thêm (theo thứ tự) - dùng cho "Đọc lại tất cả"
        self.known = set()               # đường dẫn đã thêm
        self.saved_path = ""
        self.busy = False

        self.ing_hint_var = tk.StringVar(value=settings.get("btp_hint_ing", ""))
        self.pct_hint_var = tk.StringVar(value=settings.get("btp_hint_pct", ""))
        self.name_hint_var = tk.StringVar(value=settings.get("btp_hint_name", ""))
        self.rename_win = None
        self.colour_var = tk.BooleanVar(value=bool(settings.get("btp_add_colour", True)))
        self.start_var = tk.StringVar(value="1")
        self.opt_norm = tk.BooleanVar(value=True)
        self.opt_merge = tk.BooleanVar(value=True)
        self.opt_sort = tk.BooleanVar(value=True)
        self.opt_notes = tk.BooleanVar(value=True)     # ghi chú theo Bảng Ghi chú vào cột E
        self.opt_seq = tk.BooleanVar(value=True)       # đánh số cột Sheet liên tục 1..n (không dùng 1.1, 1.2...)
        self._build_ui()

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        pad = {"padx": 10, "pady": 4}
        bottom = ttk.Frame(self)                        # thanh dưới CỐ ĐỊNH: luôn thấy nút Xuất file BTP
        bottom.pack(side="bottom", fill="x")
        self.scroll = ScrollFrame(self)
        self.scroll.pack(side="top", fill="both", expand=True)
        body = self.scroll.inner
        self.desc_label = ttk.Label(body, wraplength=1040, justify="left", foreground="#555", text=(
            "Chọn các file Excel/CSV, Word (.docx) hoặc PDF của khách hàng. App tìm bảng thành phần "
            "(dòng tiêu đề có cột INCI/Ingredient và cột %), cho bạn xem trước rồi xuất ra một file BTP "
            "(mỗi bảng là một sheet 1, 2, 3...). File BTP này dùng được ngay cho chức năng Dựng BTP."))
        self.desc_label.pack(fill="x", padx=12, pady=(8, 2))

        sb = ttk.LabelFrame(body, text="1. Thêm file dữ liệu khách hàng")
        sb.pack(fill="x", **pad)
        row = ttk.Frame(sb)
        row.pack(fill="x", padx=8, pady=6)
        self.add_btn = ttk.Button(row, text="Thêm file…", command=self._pick_files)
        self.add_btn.pack(side="left")
        self.add_dir_btn = ttk.Button(row, text="Thêm cả thư mục…", command=self._pick_folder)
        self.add_dir_btn.pack(side="left", padx=6)
        self.clear_btn = ttk.Button(row, text="Xóa hết", command=self._clear)
        self.clear_btn.pack(side="left")
        self.scan_label = ttk.Label(row, text="")
        self.scan_label.pack(side="right")
        self.progress = ttk.Progressbar(sb, mode="determinate")
        self.progress.pack(fill="x", padx=8, pady=(0, 6))

        hb_wrap = ttk.Frame(body)
        hb_wrap.pack(fill="x", **pad)
        self.hb_toggle = ttk.Button(hb_wrap, command=self._toggle_hints)
        self.hb_toggle.pack(anchor="w")
        self.hb_open = False
        hb = ttk.LabelFrame(hb_wrap, text="Nhập khi file khách đặt tên cột khác thường, vd: Composition, Nguyên liệu")
        self.hb = hb
        hb.columnconfigure(1, weight=1)
        hb.columnconfigure(3, weight=1)
        ttk.Label(hb, text="Cột thành phần gọi là:").grid(row=0, column=0, sticky="w", padx=(8, 4), pady=(6, 2))
        ttk.Entry(hb, textvariable=self.ing_hint_var).grid(row=0, column=1, sticky="ew", padx=4, pady=(6, 2))
        ttk.Label(hb, text="Cột hàm lượng gọi là:").grid(row=0, column=2, sticky="w", padx=(10, 4), pady=(6, 2))
        ttk.Entry(hb, textvariable=self.pct_hint_var).grid(row=0, column=3, sticky="ew", padx=4, pady=(6, 2))
        self.rescan_btn = ttk.Button(hb, text="Đọc lại tất cả file", command=self._rescan)
        self.rescan_btn.grid(row=0, column=4, padx=8, pady=(6, 2))
        ttk.Label(hb, text="Từ khóa lấy tên sản phẩm:").grid(row=1, column=0, sticky="w", padx=(8, 4), pady=(2, 2))
        ttk.Entry(hb, textvariable=self.name_hint_var).grid(row=1, column=1, sticky="ew", padx=4, pady=(2, 2))
        ttk.Label(hb, foreground="#888", font=("Segoe UI", 8),
                  text="vd: Description  (nhãn có chữ này; tên nằm sau dấu ':' hoặc ở dòng / ô ngay dưới hoặc bên phải)"
                  ).grid(row=1, column=2, columnspan=3, sticky="w", padx=(10, 4), pady=(2, 2))
        self.hint_note = ttk.Label(hb, foreground="#888", font=("Segoe UI", 8), wraplength=1000, justify="left",
                                   text="Nhiều tên cách nhau dấu phẩy; không phân biệt hoa/thường và dấu. Để trống = app tự nhận (INCI, "
                                        "Ingredient, Thành phần... và %, Conc, Content, w/w...; tên sản phẩm: 'Product name', 'Tên sản phẩm'). "
                                        "Chọn một dòng ✖ ở bảng dưới để xem các dòng đầu của file và biết tên cột thực tế.")
        self.hint_note.grid(row=2, column=0, columnspan=5, sticky="w", padx=8, pady=(0, 2))
        ttk.Checkbutton(hb, variable=self.colour_var,
                        text="File PDF có nhiều bảng thành phần: thêm mã màu (Colour / Colorazione) vào tên sản phẩm để phân biệt"
                        ).grid(row=4, column=0, columnspan=5, sticky="w", padx=8, pady=(0, 6))
        self.ocr_note = ttk.Label(hb, font=("Segoe UI", 8), foreground="#0B7A2B" if be.find_tesseract() else "#B45F06",
                                  text=("OCR (đọc PDF dạng ảnh scan): sẵn sàng." if be.find_tesseract() else
                                        "OCR (đọc PDF dạng ảnh scan): chưa cài Tesseract - xem HUONG_DAN.txt."))
        self.ocr_note.grid(row=3, column=0, columnspan=5, sticky="w", padx=8, pady=(0, 6))
        self.scroll.on_width = lambda w: (self.desc_label.config(wraplength=max(400, w - 40)),
                                          self.hint_note.config(wraplength=max(400, w - 60)))
        self.ing_hint_var.trace_add("write", lambda *a: self._hint_changed())
        self.pct_hint_var.trace_add("write", lambda *a: self._hint_changed())
        self.name_hint_var.trace_add("write", lambda *a: self._hint_changed())
        self._update_hint_header()

        tb = ttk.LabelFrame(body, text="2. Bảng thành phần tìm được và kiểm tra ngưỡng (bấm ô ☑ để chọn / bỏ; bấm đúp tên để sửa)")
        tb.pack(fill="both", expand=True, **pad)
        bar = ttk.Frame(tb)
        bar.pack(fill="x", padx=8, pady=(4, 0))
        ttk.Button(bar, text="Chọn tất cả", command=lambda: self._select_all(True)).pack(side="left")
        ttk.Button(bar, text="Bỏ chọn tất cả", command=lambda: self._select_all(False)).pack(side="left", padx=6)
        ttk.Button(bar, text="Chỉ chọn bảng có tổng 100", command=self._select_ok).pack(side="left")
        self.rename_btn = ttk.Button(bar, text="Đổi tên chất hàng loạt…", command=self._open_rename)
        self.rename_btn.pack(side="left", padx=(16, 0))
        self.count_label = ttk.Label(bar, text="")
        self.count_label.pack(side="right")
        ttk.Checkbutton(bar, text="Đánh số Sheet liên tục 1…n (không dùng 1.1, 1.2…)", variable=self.opt_seq,
                        command=self._refresh_names).pack(side="right", padx=(0, 16))

        holder = ttk.Frame(tb)
        holder.pack(fill="both", expand=True, padx=8, pady=6)
        cols = ("chon", "sheet", "file", "ten", "tp", "kt", "ng")
        self.tree = ttk.Treeview(holder, columns=cols, show="headings", height=5, selectmode="browse")
        heads = {"chon": ("☐", 36), "sheet": ("Sheet", 60), "file": ("File nguồn", 220),
                 "ten": ("Tên sản phẩm", 300), "tp": ("Số TP", 55), "kt": ("Tổng hàm lượng", 190), "ng": ("Ngưỡng (Annex)", 230)}
        for c, (h, w) in heads.items():
            self.tree.heading(c, text=h, **({"command": self._toggle_master} if c == "chon" else {}))
            self.tree.column(c, width=w, anchor="center" if c in ("chon", "sheet", "tp") else "w",
                             stretch=c in ("ten", "ng", "file"))
        vs = ttk.Scrollbar(holder, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vs.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vs.pack(side="right", fill="y")
        self.tree.tag_configure("warn", foreground="#B45F06")
        self.tree.tag_configure("err", foreground="#B00020")
        self.tree.tag_configure("bad", foreground="#B00020")
        self.tree.bind("<Button-1>", self._on_click)
        self.tree.bind("<Double-Button-1>", self._on_double)
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        self.panel = reg_view.ThresholdPanel(tb, self.settings, on_change=self._refresh_thresholds,
                                             export_provider=self._export_rows, tree_height=6, detail_height=3)
        self.panel.pack(fill="both", expand=True, padx=8, pady=(0, 6))

        stl = ttk.Style()
        stl.configure("Action.TButton", font=("Segoe UI", 9), padding=(8, 6))

        ob = ttk.LabelFrame(bottom, text="3. Tùy chọn xuất")
        ob.pack(fill="x", padx=10, pady=(4, 8))
        ob.columnconfigure(0, weight=1)                  # tùy chọn (trái) giãn; nút (phải) có bề rộng cố định
        ob.rowconfigure(0, weight=1)
        opts = ttk.Frame(ob)
        opts.grid(row=0, column=0, sticky="nw", padx=(10, 8), pady=(6, 8))
        r1 = ttk.Frame(opts)
        r1.pack(anchor="w")
        ttk.Label(r1, text="Số thứ tự file bắt đầu từ:").pack(side="left")
        ttk.Spinbox(r1, from_=1, to=9999, width=5, textvariable=self.start_var,
                    command=self._refresh_names).pack(side="left", padx=(4, 6))
        self.start_var.trace_add("write", lambda *a: self._refresh_names())
        ttk.Label(r1, foreground="#888", font=("Segoe UI", 8),
                  text="(đổi nếu muốn nối tiếp số thứ tự của file BTP đã có)").pack(side="left")
        r2 = ttk.Frame(opts)
        r2.pack(anchor="w", pady=(8, 0))
        ttk.Checkbutton(r2, text="Chuẩn hóa hàm lượng (bỏ %, đổi . thành ,)", variable=self.opt_norm).pack(side="left", padx=(0, 14))
        ttk.Checkbutton(r2, text="Gộp thành phần trùng tên", variable=self.opt_merge).pack(side="left", padx=(0, 14))
        ttk.Checkbutton(r2, text="Sắp xếp giảm dần theo hàm lượng", variable=self.opt_sort).pack(side="left", padx=(0, 14))
        ttk.Checkbutton(r2, text="Điền ghi chú vào cột E (theo Bảng Ghi chú)", variable=self.opt_notes).pack(side="left")

        ttk.Separator(ob, orient="vertical").grid(row=0, column=1, sticky="ns", pady=8)
        rb = ttk.Frame(ob)                              # khối nút: 1 nút chính (rộng) + 2 nút phụ bằng nhau, cao bằng khối tùy chọn
        rb.grid(row=0, column=2, sticky="ns", padx=(12, 12), pady=(6, 8))
        rb.columnconfigure(0, weight=1, uniform="act")
        rb.columnconfigure(1, weight=1, uniform="act")
        rb.rowconfigure(0, weight=3)
        rb.rowconfigure(1, weight=2)
        self.save_btn = ui_kit.PrimaryButton(rb, text="Xuất file BTP…", command=self.save, font_size=12, state="disabled")
        self.save_btn.grid(row=0, column=0, columnspan=2, sticky="nsew")
        self.use_btn = ttk.Button(rb, text="Nạp BTP này vào app", style="Action.TButton", width=18,
                                  command=self._use, state="disabled")
        self.use_btn.grid(row=1, column=0, sticky="nsew", padx=(0, 3), pady=(6, 0))
        self.open_btn = ttk.Button(rb, text="Mở thư mục", style="Action.TButton", width=18,
                                   command=self._open_folder, state="disabled")
        self.open_btn.grid(row=1, column=1, sticky="nsew", padx=(3, 0), pady=(6, 0))

        lf = ttk.Frame(body)
        lf.pack(fill="x", padx=10, pady=(0, 8))
        self.log = tk.Text(lf, height=4, wrap="word", state="disabled", font=("Consolas", 9))
        ls = ttk.Scrollbar(lf, orient="vertical", command=self.log.yview)
        self.log.configure(yscrollcommand=ls.set)
        self.log.pack(side="left", fill="both", expand=True)
        ls.pack(side="right", fill="y")
        self.log.tag_configure("ok", foreground="#0B7A2B")
        self.log.tag_configure("err", foreground="#B00020")

    # ---------------------------------------------------------------- tiện ích
    def _log(self, text, tag=None):
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n", tag or ())
        self.log.see("end")
        self.log.configure(state="disabled")

    def _set_busy(self, busy):
        self.busy = busy
        st = "disabled" if busy else "normal"
        for b in (self.add_btn, self.add_dir_btn, self.clear_btn, self.rescan_btn):
            b.config(state=st)
        self.config(cursor="watch" if busy else "")
        self._update_buttons()

    def _update_buttons(self):
        any_sel = any(t.selected for t in self.tables)
        self.save_btn.config(state="normal" if (any_sel and not self.busy) else "disabled")

    def _start_no(self):
        try:
            return max(1, int(self.start_var.get()))
        except ValueError:
            return 1

    def _selected_tables(self):
        return [t for t in self.tables if t.selected]

    # ---------------------------------------------------------------- thêm file
    def _pick_files(self):
        ps = filedialog.askopenfilenames(
            parent=self, title="Chọn file dữ liệu khách hàng",
            initialdir=self.settings.get("btp_src_dir") or None, filetypes=FILE_TYPES)
        if ps:
            self.settings["btp_src_dir"] = os.path.dirname(ps[0])
            eng.save_settings(self.settings)
            self.add_paths(list(ps))

    def _pick_folder(self):
        d = filedialog.askdirectory(parent=self, title="Chọn thư mục chứa file khách hàng",
                                    initialdir=self.settings.get("btp_src_dir") or None)
        if not d:
            return
        self.settings["btp_src_dir"] = d
        eng.save_settings(self.settings)
        files = be.find_files(d, recursive=True)
        if not files:
            messagebox.showinfo("Thêm thư mục", "Không thấy file Excel/CSV/Word/PDF nào trong thư mục này.",
                                parent=self)
            return
        self.add_paths(files)

    def add_paths(self, paths, threaded=True):
        new = []
        for p in paths:
            key = os.path.normcase(os.path.abspath(p))
            if key in self.known:
                continue
            self.known.add(key)
            new.append(p)
        if not new:
            return
        self.source_paths.extend(new)
        hints = self._hints()
        self.settings["btp_hint_ing"] = self.ing_hint_var.get().strip()
        self.settings["btp_hint_pct"] = self.pct_hint_var.get().strip()
        self.settings["btp_hint_name"] = self.name_hint_var.get().strip()
        self.settings["btp_add_colour"] = bool(self.colour_var.get())
        eng.save_settings(self.settings)
        self.hint_note.config(foreground="#888")
        self.progress.config(maximum=len(new), value=0)
        self._set_busy(True)
        self.scan_label.config(text="Đang đọc 0/%d file…" % len(new))
        q = queue.Queue()

        def work():
            for i, p in enumerate(new, start=1):
                try:
                    tables, _n = be.read_source(p, hints)
                    q.put(("ok", p, tables))
                except be.ReadError as ex:
                    q.put(("err", p, str(ex), ex.preview))
                except Exception as ex:
                    q.put(("err", p, str(ex), []))
                q.put(("prog", i, len(new)))
            q.put(("done", len(new)))

        if threaded:
            threading.Thread(target=work, daemon=True).start()
            self._poll(q)
        else:
            work()
            while not q.empty():
                if self._handle(q.get_nowait()):
                    break

    def _poll(self, q):
        finished = False
        try:
            while True:
                if self._handle(q.get_nowait()):
                    finished = True
                    break
        except queue.Empty:
            pass
        if not finished:
            self.after(120, lambda: self._poll(q))

    def _handle(self, msg):
        kind = msg[0]
        if kind == "ok":
            if self.settings.get("btp_rename_auto") and self.settings.get("btp_rename_map"):
                be.apply_rename_map(msg[2], self.settings["btp_rename_map"])
            self.tables.extend(msg[2])
            self._log("✔ %s: %d bảng" % (os.path.basename(msg[1]), len(msg[2])), "ok")
        elif kind == "err":
            self.fails.append({"path": msg[1], "reason": msg[2], "preview": msg[3]})
            self._log("✖ %s: %s" % (os.path.basename(msg[1]), msg[2]), "err")
        elif kind == "prog":
            self.progress["value"] = msg[1]
            self.scan_label.config(text="Đang đọc %d/%d file…" % (msg[1], msg[2]))
        elif kind == "done":
            self.scan_label.config(text="Đã đọc xong %d file." % msg[1])
            self._set_busy(False)
            self._refresh_tree()
            if self.fails and not self.hb_open:
                self._toggle_hints(True)                 # có file không đọc ra -> mở sẵn mục Tên cột
            return True
        return False

    def _clear(self):
        if self.tables and not messagebox.askyesno("Xóa hết", "Xóa toàn bộ danh sách bảng đã đọc?", parent=self):
            return
        self.tables, self.fails, self.known, self.source_paths = [], [], set(), []
        self.progress["value"] = 0
        self.scan_label.config(text="")
        self._refresh_tree()

    def _hints(self):
        h = be.ColumnHints.from_text(self.ing_hint_var.get(), self.pct_hint_var.get(), self.name_hint_var.get())
        h.add_colour = bool(self.colour_var.get())
        return h

    def _hint_summary(self):
        ing, pct, nm = self.ing_hint_var.get().strip(), self.pct_hint_var.get().strip(), self.name_hint_var.get().strip()
        parts = []
        if nm:
            parts.append("tên SP: %s" % nm[:30])
        if ing:
            parts.append("thành phần: %s" % ing[:30])
        if pct:
            parts.append("hàm lượng: %s" % pct[:30])
        return (" — đang dùng " + "; ".join(parts)) if parts else " — tự nhận (INCI, Ingredient, % ...)"

    def _update_hint_header(self):
        self.hb_toggle.config(text="%s Tên cột (tuỳ chọn)%s" % ("▾" if self.hb_open else "▸", self._hint_summary()))

    def _toggle_hints(self, open_=None):
        self.hb_open = (not self.hb_open) if open_ is None else bool(open_)
        if self.hb_open:
            self.hb.pack(fill="x", pady=(4, 0))
        else:
            self.hb.pack_forget()
        self._update_hint_header()

    def _hint_changed(self):
        self._update_hint_header()
        if self.tables or self.fails:
            self.hint_note.config(foreground="#B45F06",
                                  text="Đã đổi tên cột - bấm 'Đọc lại tất cả file' để áp dụng cho các file đã thêm "
                                       "(các chỉnh sửa tên sản phẩm đã làm sẽ mất).")

    def _rescan(self):
        if self.busy or not self.source_paths:
            return
        paths = list(self.source_paths)
        self.tables, self.fails, self.known, self.source_paths = [], [], set(), []
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")
        self._refresh_tree()
        self.add_paths(paths)

    # ---------------------------------------------------------------- bảng
    def _refresh_names(self):
        names = {}
        sel = self._selected_tables()
        for t, nm in zip(sel, be.sheet_names_for(sel, self._start_no(), self.opt_seq.get())):
            names[id(t)] = nm
        for i, t in enumerate(self.tables):
            iid = str(i)
            if iid in self.tree.get_children():
                self.tree.set(iid, "sheet", names.get(id(t), "-"))
        self.count_label.config(text="Đã chọn %d / %d bảng" % (len(sel), len(self.tables)))
        self._update_master_box(len(sel))
        self._update_buttons()

    def _update_master_box(self, n_sel):
        """Ô tích ở tiêu đề cột đầu: ☑ khi đã chọn hết, ☐ khi chưa chọn hết."""
        all_on = bool(self.tables) and n_sel == len(self.tables)
        self.tree.heading("chon", text=CHK if all_on else UNCHK)

    def _toggle_master(self):
        """Bấm ô tiêu đề cột đầu: chưa chọn hết -> chọn hết; đã chọn hết -> bỏ chọn hết."""
        if self.busy or not self.tables:
            return
        self._select_all(not all(t.selected for t in self.tables))

    # ------------------------------------------------------------ đổi tên chất hàng loạt
    def _open_rename(self):
        if not self.tables:
            messagebox.showinfo("Đổi tên chất", "Hãy đọc file trước để có danh sách thành phần.", parent=self)
            return
        if self.rename_win is not None and self.rename_win.winfo_exists():
            self.rename_win.lift()
            self.rename_win.focus_force()
            return
        self.rename_win = rename_view.RenameDialog(
            self, self.settings, get_tables=lambda: (self.tables, self._selected_tables()), on_applied=self._after_rename)

    def _after_rename(self):
        sel = self.tree.selection()
        self._refresh_thresholds()
        if sel and sel[0] in self.tree.get_children():
            self.tree.selection_set(sel[0])
            self._on_select()

    def _refresh_tree(self):
        self.tree.delete(*self.tree.get_children())
        for i, t in enumerate(self.tables):
            code, msg = t.status()
            ng, ngtag = reg_view.summary_text(self.panel.check(t.items))
            tag = "bad" if ngtag == "bad" else ("warn" if (code == "warn" or ngtag == "warn") else "")
            self.tree.insert("", "end", iid=str(i), tags=(tag,) if tag else (),
                             values=(CHK if t.selected else UNCHK, "", t.source_file
                                     + ((" [%s]" % t.source_sheet) if t.source_sheet else ""),
                                     t.product, len(t.items), msg, ng))
        for k, f in enumerate(self.fails):
            self.tree.insert("", "end", iid="f%d" % k, tags=("err",),
                             values=("✖", "-", os.path.basename(f["path"]), "(không đọc được)", "", f["reason"], ""))
        self._refresh_names()

    def _refresh_thresholds(self):
        """Tỉ lệ trộn / xác nhận chất lạ đổi -> cập nhật lại cột 'Ngưỡng' của mọi bảng."""
        sel = self.tree.selection()
        self._refresh_tree()
        if sel and sel[0] in self.tree.get_children():
            self.tree.selection_set(sel[0])

    def _export_rows(self):
        """Báo cáo ngưỡng cho các bảng đang chọn."""
        return [{"name": t.product, "source": t.source_file, "rows": t.items} for t in self.tables if t.selected]

    def _set_detail(self, text):
        self.panel.show_message(text)

    def _on_select(self, _e=None):
        sel = self.tree.selection()
        if not sel:
            return
        if sel[0].startswith("f"):
            f = self.fails[int(sel[0][1:])]
            pv = f["preview"]
            guess = be.suggest_header_line(pv)
            lines = ["KHÔNG ĐỌC ĐƯỢC: %s" % f["reason"], "",
                     "Các dòng đầu của file (► = có thể là dòng tiêu đề bảng thành phần). Nhìn tên cột thành phần và "
                     "cột hàm lượng ở đây, nhập vào ô 'Tên cột' phía trên rồi bấm 'Đọc lại tất cả file':", ""]
            lines += [("► " if k == guess else "  ") + ln[:150] for k, ln in enumerate(pv)] or ["(không lấy được nội dung)"]
            self._set_detail("\n".join(lines))
            return
        t = self.tables[int(sel[0])]
        self.panel.show(t.product, t.items)
        if t.notes:
            self.panel._set_detail("Lưu ý: " + "; ".join(t.notes))

    def _on_click(self, e):
        if self.busy or self.tree.identify_region(e.x, e.y) != "cell":
            return None
        if self.tree.identify_column(e.x) != "#1":
            return None
        iid = self.tree.identify_row(e.y)
        if not iid or iid.startswith("f"):
            return None
        t = self.tables[int(iid)]
        t.selected = not t.selected
        self.tree.set(iid, "chon", CHK if t.selected else UNCHK)
        self._refresh_names()
        return "break"

    def _on_double(self, e):
        if self.busy or self.tree.identify_column(e.x) != "#4":
            return
        iid = self.tree.identify_row(e.y)
        if not iid or iid.startswith("f"):
            return
        t = self.tables[int(iid)]
        new = simpledialog.askstring("Sửa tên sản phẩm", "Tên sản phẩm:", initialvalue=t.product, parent=self)
        if new is not None and be.clean_cell(new):
            t.product = be.clean_cell(new)
            self.tree.set(iid, "ten", t.product)
            self._on_select()

    def _select_all(self, on):
        for t in self.tables:
            t.selected = on
        self._refresh_tree()

    def _select_ok(self):
        for t in self.tables:
            t.selected = t.status()[0] == "ok"
        self._refresh_tree()

    # ---------------------------------------------------------------- xuất
    def save(self):
        sel = self._selected_tables()
        if not sel:
            messagebox.showwarning("Chưa chọn bảng", "Hãy tích chọn ít nhất một bảng để xuất.", parent=self)
            return
        bad_thr = [t for t in sel if reg_view.summary_text(self.panel.check(t.items))[1] == "bad"]
        if bad_thr and not messagebox.askyesno(
                "Có chất cấm / vượt ngưỡng",
                "%d bảng đã chọn có chất CẤM, VƯỢT NGƯỠNG hoặc thiếu %% bắt buộc theo Annex ASEAN "
                "(xem cột 'Ngưỡng' và bảng chi tiết).\n\nVẫn xuất file BTP?" % len(bad_thr), parent=self):
            return
        warn = [t for t in sel if t.status()[0] == "warn"]
        if warn and not messagebox.askyesno(
                "Có bảng cần kiểm tra",
                "%d bảng đã chọn có hàm lượng chưa đạt tổng 100 hoặc thiếu hàm lượng "
                "(các sheet đó sẽ được tô hồng ở tab).\n\nVẫn xuất file BTP?" % len(warn), parent=self):
            return
        out = filedialog.asksaveasfilename(
            parent=self, title="Lưu file BTP", defaultextension=".xlsx",
            initialdir=self.settings.get("btp_out_dir") or None,
            initialfile="BTP_%s.xlsx" % date.today().strftime("%Y%m%d"),
            filetypes=[("Excel", "*.xlsx")])
        if not out:
            return
        opts = be.WriteOptions(start=self._start_no(), normalize=self.opt_norm.get(),
                               merge_duplicates=self.opt_merge.get(), sort_desc=self.opt_sort.get(),
                               sequential=self.opt_seq.get(), fill_notes=self.opt_notes.get())
        try:
            result = be.write_btp(self.tables, out, opts)
        except PermissionError:
            messagebox.showerror("Không ghi được", "Không ghi được file (đang mở trong Excel?).", parent=self)
            return
        except Exception as ex:
            messagebox.showerror("Không xuất được", str(ex), parent=self)
            return
        self.saved_path = out
        self.settings["btp_out_dir"] = os.path.dirname(out)
        eng.save_settings(self.settings)
        bad = sum(1 for _n, _t, tot in result if abs(tot - 100) > be.TOTAL_TOL)
        self._log("Đã xuất %d sheet -> %s%s" % (len(result), out, ("  (%d sheet tô hồng do tổng ≠ 100)" % bad) if bad else ""),
                  "ok")
        self.open_btn.config(state="normal")
        self.use_btn.config(state="normal" if self.on_use_btp else "disabled")
        messagebox.showinfo("Hoàn tất", "Đã xuất file BTP với %d sheet.%s" % (
            len(result), "\n%d sheet tổng ≠ 100 (tab màu hồng)." % bad if bad else ""), parent=self)

    def _use(self):
        if self.on_use_btp and self.saved_path:
            self.on_use_btp(self.saved_path)

    def _open_folder(self):
        d = os.path.dirname(self.saved_path)
        if not os.path.isdir(d):
            return
        if sys.platform.startswith("win"):
            os.startfile(d)                                   # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", d])
        else:
            subprocess.Popen(["xdg-open", d])
